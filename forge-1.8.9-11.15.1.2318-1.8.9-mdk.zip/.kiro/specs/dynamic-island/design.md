# 设计文档

## 概述

本设计文档描述了"灵动岛"（Dynamic Island）功能的架构设计。灵动岛是一个固定在屏幕顶部中央的 HUD 元素，类似于苹果设备的灵动岛功能，能够动态展示游戏信息，支持平滑动画和多种显示状态。

核心设计目标：
- 始终固定在屏幕顶部中央
- 流畅的展开/收缩动画
- 支持多种内容类型和显示状态
- 高质量的视觉效果（圆角、阴影、发光）
- 实时显示游戏信息
- 可配置和可扩展

## 架构

### 系统架构图

```mermaid
graph TB
    A[DynamicIsland] --> B[IslandRenderer]
    A --> C[AnimationController]
    A --> D[ContentManager]
    A --> E[IslandConfig]
    
    B --> F[TextureManager]
    B --> G[OpenGLStateManager]
    B --> H[EffectRenderer]
    
    C --> I[EasingFunctions]
    C --> J[StateTransition]
    
    D --> K[TextContent]
    D --> L[IconContent]
    D --> M[PlayerInfoProvider]
    
    H --> N[ShadowEffect]
    H --> O[GlowEffect]
    H --> P[RoundedRectRenderer]
    
    Q[MinecraftForge Events] --> A
    A --> R[RenderGameOverlayEvent]
```

### 核心组件关系

1. **DynamicIsland** - 主控制器，协调所有子系统
2. **IslandRenderer** - 负责渲染灵动岛的视觉效果
3. **AnimationController** - 管理动画状态和过渡
4. **ContentManager** - 管理显示内容和布局
5. **IslandConfig** - 配置管理

## 组件和接口

### 1. DynamicIsland

灵动岛的主类，单例模式。

```java
public class DynamicIsland {
    private static DynamicIsland instance;
    
    private IslandRenderer renderer;
    private AnimationController animationController;
    private ContentManager contentManager;
    private IslandConfig config;
    
    private IslandState currentState;
    private boolean enabled;
    
    // 单例
    public static DynamicIsland getInstance();
    
    // 初始化
    public void initialize();
    
    // 状态管理
    public void setState(IslandState state);
    public IslandState getState();
    public void toggleState();
    
    // 内容管理
    public void setContent(IslandContent content);
    public void addContent(IslandContent content);
    public void clearContent();
    
    // 启用/禁用
    public void setEnabled(boolean enabled);
    public boolean isEnabled();
    public void toggle();
    
    // 配置
    public IslandConfig getConfig();
    
    // 更新和渲染
    public void update();
    
    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Post event);
}
```

### 2. IslandState

灵动岛的显示状态枚举。

```java
public enum IslandState {
    COMPACT(80, 30),      // 收缩状态：80x30 像素
    STANDARD(120, 40),    // 标准状态：120x40 像素
    EXPANDED(200, 60);    // 展开状态：200x60 像素
    
    private final int width;
    private final int height;
    
    IslandState(int width, int height);
    
    public int getWidth();
    public int getHeight();
    public float getAspectRatio();
}
```

### 3. IslandRenderer

负责渲染灵动岛的所有视觉元素。

```java
public class IslandRenderer {
    private ResourceLocation backgroundTexture;
    private EffectRenderer effectRenderer;
    
    private float currentWidth;
    private float currentHeight;
    private float currentAlpha;
    
    public IslandRenderer();
    
    // 渲染主方法
    public void render(ScaledResolution resolution, IslandState state, 
                      List<IslandContent> contents, float animationProgress);
    
    // 渲染背景
    private void renderBackground(float x, float y, float width, float height, float alpha);
    
    // 渲染内容
    private void renderContents(float x, float y, float width, float height, 
                               List<IslandContent> contents);
    
    // 渲染效果
    private void renderEffects(float x, float y, float width, float height);
    
    // 计算位置
    private float calculateX(ScaledResolution resolution, float width);
    private float calculateY(ScaledResolution resolution);
    
    // 纹理管理
    public void loadTextures();
    public void setBackgroundTexture(ResourceLocation texture);
}
```

### 4. AnimationController

管理灵动岛的动画效果。

```java
public class AnimationController {
    private IslandState fromState;
    private IslandState toState;
    private long animationStartTime;
    private long animationDuration;
    private EasingFunction easingFunction;
    private boolean isAnimating;
    
    public AnimationController();
    
    // 动画控制
    public void startTransition(IslandState from, IslandState to, long duration);
    public void update();
    public boolean isAnimating();
    public void stopAnimation();
    
    // 获取当前动画值
    public float getProgress();
    public float getCurrentWidth();
    public float getCurrentHeight();
    public float getCurrentAlpha();
    
    // 缓动函数
    public void setEasingFunction(EasingFunction function);
    
    // 即时切换（无动画）
    public void setStateImmediate(IslandState state);
}

// 缓动函数接口
interface EasingFunction {
    float apply(float t);
}

// 预定义缓动函数
class EasingFunctions {
    public static final EasingFunction LINEAR = t -> t;
    public static final EasingFunction EASE_IN_OUT = t -> {
        return t < 0.5f 
            ? 2 * t * t 
            : -1 + (4 - 2 * t) * t;
    };
    public static final EasingFunction EASE_OUT_CUBIC = t -> {
        float f = t - 1;
        return f * f * f + 1;
    };
    public static final EasingFunction EASE_IN_OUT_BACK = t -> {
        float c1 = 1.70158f;
        float c2 = c1 * 1.525f;
        return t < 0.5f
            ? (float) (Math.pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2
            : (float) (Math.pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2;
    };
}
```

### 5. ContentManager

管理灵动岛中显示的内容。

```java
public class ContentManager {
    private List<IslandContent> contents;
    private PlayerInfoProvider infoProvider;
    
    public ContentManager();
    
    // 内容管理
    public void addContent(IslandContent content);
    public void removeContent(IslandContent content);
    public void clearContents();
    public List<IslandContent> getContents();
    
    // 自动内容更新
    public void updateContents();
    
    // 布局计算
    public void layoutContents(float availableWidth, float availableHeight);
}

// 内容接口
interface IslandContent {
    void render(float x, float y, float maxWidth, float maxHeight);
    float getPreferredWidth();
    float getPreferredHeight();
    int getPriority();
    boolean shouldDisplay();
}

// 文本内容
class TextContent implements IslandContent {
    private String text;
    private int color;
    private boolean shadow;
    private int priority;
    
    public TextContent(String text, int color, int priority);
    
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight);
    
    public void setText(String text);
    public String getText();
}

// 图标内容
class IconContent implements IslandContent {
    private ResourceLocation icon;
    private int size;
    private int priority;
    
    public IconContent(ResourceLocation icon, int size, int priority);
    
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight);
}

// 玩家信息内容
class PlayerInfoContent implements IslandContent {
    private InfoType type;
    private int priority;
    
    public enum InfoType {
        COORDINATES,
        HEALTH,
        HUNGER,
        TIME,
        TARGET
    }
    
    public PlayerInfoContent(InfoType type, int priority);
    
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight);
}
```

### 6. EffectRenderer

渲染视觉效果（阴影、发光、圆角等）。

```java
public class EffectRenderer {
    
    // 渲染圆角矩形
    public void renderRoundedRect(float x, float y, float width, float height, 
                                 float radius, int color);
    
    // 渲染阴影
    public void renderShadow(float x, float y, float width, float height, 
                            float radius, int shadowColor, float shadowSize);
    
    // 渲染发光效果
    public void renderGlow(float x, float y, float width, float height, 
                          float radius, int glowColor, float glowIntensity);
    
    // 渲染渐变背景
    public void renderGradient(float x, float y, float width, float height, 
                              int colorTop, int colorBottom);
    
    // 渲染模糊背景（毛玻璃效果）
    public void renderBlurredBackground(float x, float y, float width, float height, 
                                       float blurRadius);
}
```

### 7. IslandConfig

配置管理类。

```java
public class IslandConfig {
    // 显示设置
    private boolean enabled = true;
    private float offsetX = 0.0f;
    private float offsetY = 10.0f;
    private float scale = 1.0f;
    private float alpha = 0.9f;
    
    // 动画设置
    private long transitionDuration = 400;
    private EasingFunction easingFunction = EasingFunctions.EASE_IN_OUT_BACK;
    
    // 内容设置
    private boolean showCoordinates = true;
    private boolean showHealth = true;
    private boolean showTime = false;
    private boolean showTarget = true;
    
    // 视觉设置
    private boolean enableShadow = true;
    private boolean enableGlow = true;
    private float cornerRadius = 15.0f;
    private int backgroundColor = 0xE0000000;
    
    // 调试设置
    private boolean debugMode = false;
    
    // Getter/Setter
    public boolean isEnabled();
    public void setEnabled(boolean enabled);
    // ... 其他 getter/setter
    
    // 配置持久化
    public void load();
    public void save();
}
```

### 8. PlayerInfoProvider

提供玩家和游戏信息。

```java
public class PlayerInfoProvider {
    private Minecraft mc;
    
    public PlayerInfoProvider();
    
    // 玩家信息
    public String getCoordinates();
    public String getHealth();
    public String getHunger();
    public String getGameTime();
    
    // 目标信息
    public String getTargetInfo();
    public boolean hasTarget();
    
    // 格式化方法
    private String formatCoordinates(double x, double y, double z);
    private String formatHealth(float health, float maxHealth);
    private String formatTime(long worldTime);
}
```

## 数据模型

### 坐标系统

- **屏幕坐标**: 左上角为 (0, 0)
- **灵动岛位置**: 默认在屏幕顶部中央，Y 偏移 10 像素
- **内容布局**: 从左到右，居中对齐

### 状态转换

```
COMPACT <-> STANDARD <-> EXPANDED
   |           |            |
   +------ 动画过渡 -------+
```

### 动画时间轴

```
时间: 0ms -------- 200ms -------- 400ms
状态: 开始 -------- 中间 -------- 结束
进度: 0.0  -------- 0.5  -------- 1.0
```

## 错误处理

### 错误处理策略

1. **纹理加载失败**
   - 使用纯色背景替代
   - 记录警告日志
   - 继续正常渲染

2. **渲染异常**
   - 捕获所有渲染异常
   - 恢复 OpenGL 状态
   - 禁用效果但保持基本显示

3. **内容更新失败**
   - 保留上一次有效内容
   - 记录错误
   - 继续更新其他内容

4. **配置加载失败**
   - 使用默认配置
   - 记录警告
   - 尝试重新保存配置

### 异常类

```java
public class DynamicIslandException extends RuntimeException {
    public DynamicIslandException(String message);
    public DynamicIslandException(String message, Throwable cause);
}

public class IslandRenderException extends DynamicIslandException {
    public IslandRenderException(String message, Throwable cause);
}
```

## 测试策略

### 功能测试

1. **渲染测试**
   - 验证灵动岛在屏幕顶部正确显示
   - 验证不同状态的尺寸正确
   - 验证动画流畅性

2. **内容测试**
   - 验证各种内容类型正确显示
   - 验证内容更新及时
   - 验证布局正确

3. **配置测试**
   - 验证配置保存和加载
   - 验证配置修改生效
   - 验证默认配置正确

### 性能测试

1. **渲染性能**
   - 测量每帧渲染时间
   - 确保不影响游戏 FPS
   - 优化复杂效果

2. **内存使用**
   - 监控纹理内存
   - 检查内存泄漏
   - 优化对象创建

### 视觉测试

创建测试 GUI 验证视觉效果：

```java
public class DynamicIslandTestGui extends GuiScreen {
    // 测试不同状态
    // 测试动画效果
    // 测试内容显示
    // 测试配置选项
}
```

## 性能考虑

### 优化策略

1. **渲染优化**
   - 只在状态改变时重新计算布局
   - 缓存渲染结果
   - 使用批量渲染减少 OpenGL 调用

2. **动画优化**
   - 使用插值避免每帧计算
   - 动画完成后停止更新
   - 使用固定时间步长

3. **内容更新优化**
   - 限制更新频率（如每秒 2 次）
   - 只更新变化的内容
   - 使用脏标记机制

4. **纹理优化**
   - 预加载所有纹理
   - 使用纹理图集
   - 启用 mipmap

## 与现有系统集成

### 与 OpenGL 渲染框架集成

如果 OpenGL 渲染框架已实现，灵动岛可以使用其功能：

```java
// 使用渲染框架的纹理管理
TextureManager textures = RenderingFramework.getInstance().getTextureManager();
ResourceLocation texture = textures.loadTexture("examplemod:textures/gui/ldd.png");

// 使用渲染框架的状态管理
OpenGLStateManager gl = RenderingFramework.getInstance().getStateManager();
gl.pushState();
gl.enableBlend();
gl.setBlendMode(BlendMode.NORMAL);
// ... 渲染
gl.popState();

// 使用渲染框架的辅助方法
RenderHelper.drawTexturedRect(x, y, width, height, texture);
```

### 与现有模块集成

```java
// 与 AutoAttack 集成
if (AutoAttack.getInstance().isEnabled()) {
    EntityLivingBase target = AutoAttack.getInstance().getCurrentTarget();
    if (target != null) {
        content.addContent(new TextContent(target.getName(), 0xFFFFFF, 1));
    }
}

// 与 NotificationSystem 集成
// 当有重要通知时，灵动岛展开显示
NotificationSystem.getInstance().addListener(notification -> {
    if (notification.isImportant()) {
        DynamicIsland.getInstance().setState(IslandState.EXPANDED);
    }
});
```

## 扩展性设计

### 自定义内容类型

开发者可以创建自定义内容：

```java
public class CustomContent implements IslandContent {
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight) {
        // 自定义渲染逻辑
    }
    
    @Override
    public float getPreferredWidth() {
        return 50;
    }
    
    @Override
    public float getPreferredHeight() {
        return 20;
    }
    
    @Override
    public int getPriority() {
        return 5;
    }
    
    @Override
    public boolean shouldDisplay() {
        return true;
    }
}

// 使用
DynamicIsland.getInstance().addContent(new CustomContent());
```

### 自定义动画

```java
// 创建自定义缓动函数
EasingFunction customEasing = t -> {
    // 自定义插值逻辑
    return (float) Math.sin(t * Math.PI / 2);
};

AnimationController controller = new AnimationController();
controller.setEasingFunction(customEasing);
```

## 使用示例

### 基本使用

```java
// 初始化
DynamicIsland island = DynamicIsland.getInstance();
island.initialize();

// 注册到事件总线
MinecraftForge.EVENT_BUS.register(island);

// 设置内容
island.addContent(new PlayerInfoContent(InfoType.COORDINATES, 1));
island.addContent(new PlayerInfoContent(InfoType.HEALTH, 2));

// 切换状态
island.setState(IslandState.EXPANDED);
```

### 配置示例

```java
IslandConfig config = island.getConfig();
config.setOffsetY(20.0f);
config.setScale(1.2f);
config.setAlpha(0.95f);
config.setShowCoordinates(true);
config.setShowHealth(true);
config.save();
```

### 动态内容更新

```java
// 每秒更新一次
new Timer().scheduleAtFixedRate(new TimerTask() {
    @Override
    public void run() {
        island.getContentManager().updateContents();
    }
}, 0, 1000);
```

## 配置文件格式

```json
{
  "enabled": true,
  "offsetX": 0.0,
  "offsetY": 10.0,
  "scale": 1.0,
  "alpha": 0.9,
  "transitionDuration": 400,
  "showCoordinates": true,
  "showHealth": true,
  "showTime": false,
  "showTarget": true,
  "enableShadow": true,
  "enableGlow": true,
  "cornerRadius": 15.0,
  "backgroundColor": -536870912,
  "debugMode": false
}
```

## 调试工具

### 调试覆盖层

```java
public class IslandDebugOverlay {
    public void render() {
        if (!config.isDebugMode()) return;
        
        // 显示当前状态
        // 显示动画进度
        // 显示内容数量
        // 显示渲染时间
        // 显示位置和尺寸
    }
}
```

### 性能监控

```java
public class IslandProfiler {
    private long renderTime;
    private long updateTime;
    private int frameCount;
    
    public void startRender();
    public void endRender();
    public void printStats();
}
```
