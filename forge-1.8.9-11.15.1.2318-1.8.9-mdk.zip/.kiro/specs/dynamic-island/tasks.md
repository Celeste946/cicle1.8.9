# 实现计划

- [x] 1. 创建核心类和数据结构


  - 创建 `DynamicIsland` 主类，实现单例模式
  - 创建 `IslandState` 枚举，定义三种状态（COMPACT、STANDARD、EXPANDED）及其尺寸
  - 创建 `IslandConfig` 配置类，包含所有配置选项和默认值
  - 创建 `DynamicIslandException` 和 `IslandRenderException` 异常类
  - 在 `DynamicIsland` 中添加基本的 getter/setter 方法
  - _需求: 1.1, 4.1, 4.2, 4.3, 6.1_

- [x] 2. 实现 AnimationController 动画系统


  - [ ] 2.1 实现动画控制器核心功能
    - 创建 `AnimationController` 类
    - 实现 `startTransition` 方法，记录起始和目标状态
    - 实现 `update` 方法，计算当前动画进度
    - 实现 `getProgress` 方法，返回 0.0 到 1.0 的进度值
    - 实现 `getCurrentWidth` 和 `getCurrentHeight` 方法，基于进度插值计算当前尺寸
    - 实现 `stopAnimation` 和 `setStateImmediate` 方法


    - _需求: 2.1, 2.2, 2.4, 2.5_

  - [ ] 2.2 实现缓动函数系统
    - 创建 `EasingFunction` 接口
    - 创建 `EasingFunctions` 工具类
    - 实现 LINEAR 缓动函数
    - 实现 EASE_IN_OUT 缓动函数
    - 实现 EASE_OUT_CUBIC 缓动函数
    - 实现 EASE_IN_OUT_BACK 缓动函数（带回弹效果）


    - 在 `AnimationController` 中应用缓动函数到进度计算
    - _需求: 2.3_

- [ ] 3. 实现 EffectRenderer 视觉效果渲染器
  - [x] 3.1 实现圆角矩形渲染

    - 创建 `EffectRenderer` 类
    - 实现 `renderRoundedRect` 方法，使用 OpenGL 绘制圆角矩形
    - 使用 `Tessellator` 和 `WorldRenderer` 进行顶点绘制
    - 使用三角扇形或多边形近似圆角
    - _需求: 5.2_


  - [ ] 3.2 实现阴影效果
    - 实现 `renderShadow` 方法
    - 绘制多层半透明圆角矩形，模拟阴影扩散
    - 使用渐变透明度，从中心到边缘逐渐透明

    - _需求: 5.3_

  - [ ] 3.3 实现发光效果
    - 实现 `renderGlow` 方法
    - 在主体周围绘制发光层
    - 支持可调节的发光强度和颜色


    - _需求: 5.4_

  - [ ] 3.4 实现渐变背景
    - 实现 `renderGradient` 方法
    - 支持垂直渐变（从上到下）

    - 使用颜色插值实现平滑过渡
    - _需求: 5.1_

- [ ] 4. 实现 IslandRenderer 主渲染器
  - [ ] 4.1 实现基础渲染功能
    - 创建 `IslandRenderer` 类
    - 实现 `loadTextures` 方法，加载 ldd.png 纹理

    - 实现 `calculateX` 和 `calculateY` 方法，计算灵动岛在屏幕上的位置（顶部中央）
    - 实现 `render` 主方法，协调所有渲染步骤
    - _需求: 1.1, 1.3, 5.5_

  - [ ] 4.2 实现背景渲染
    - 实现 `renderBackground` 方法

    - 首先渲染阴影效果（如果启用）
    - 渲染圆角矩形背景，使用配置的背景颜色和透明度
    - 如果纹理加载成功，渲染纹理作为背景
    - 渲染发光效果（如果启用）
    - _需求: 1.3, 5.1, 5.2, 5.3, 5.4_

  - [x] 4.3 实现内容渲染


    - 实现 `renderContents` 方法
    - 遍历所有内容元素，调用其 render 方法
    - 根据内容优先级排序
    - 处理内容溢出（裁剪或省略）
    - _需求: 3.1, 3.2, 3.3_

  - [x] 4.4 添加渲染错误处理


    - 在 `render` 方法中添加 try-catch 块
    - 捕获渲染异常并记录日志
    - 在异常时恢复 OpenGL 状态
    - 纹理加载失败时使用纯色背景
    - _需求: 8.1, 8.2, 8.3_



- [ ] 5. 实现内容系统
  - [ ] 5.1 实现内容接口和基础类
    - 创建 `IslandContent` 接口
    - 创建 `TextContent` 类，实现文本内容渲染

    - 创建 `IconContent` 类，实现图标内容渲染
    - 每个内容类实现 `render`、`getPreferredWidth`、`getPreferredHeight`、`getPriority`、`shouldDisplay` 方法
    - _需求: 3.1, 3.2_

  - [ ] 5.2 实现 PlayerInfoProvider 信息提供者
    - 创建 `PlayerInfoProvider` 类
    - 实现 `getCoordinates` 方法，返回格式化的玩家坐标
    - 实现 `getHealth` 方法，返回格式化的生命值

    - 实现 `getHunger` 方法，返回格式化的饥饿度
    - 实现 `getGameTime` 方法，返回格式化的游戏时间
    - 实现 `getTargetInfo` 方法，返回当前攻击目标信息（如果有）
    - _需求: 7.1, 7.2, 7.3, 7.4_


  - [ ] 5.3 实现 PlayerInfoContent 玩家信息内容
    - 创建 `PlayerInfoContent` 类
    - 创建 `InfoType` 枚举（COORDINATES、HEALTH、HUNGER、TIME、TARGET）
    - 在 `render` 方法中根据类型调用 `PlayerInfoProvider` 获取信息
    - 渲染格式化的文本和图标
    - _需求: 7.1, 7.2, 7.3, 7.4, 7.5_

  - [x] 5.4 实现 ContentManager 内容管理器

    - 创建 `ContentManager` 类
    - 实现 `addContent`、`removeContent`、`clearContents` 方法
    - 实现 `updateContents` 方法，更新所有动态内容
    - 实现 `layoutContents` 方法，计算内容布局
    - 根据优先级排序内容
    - _需求: 3.1, 3.2, 3.3, 3.4, 7.5_


- [ ] 6. 实现配置系统
  - [ ] 6.1 实现配置管理
    - 在 `IslandConfig` 中实现所有配置项的 getter/setter
    - 实现配置验证（如缩放范围 0.5-2.0，透明度 0.0-1.0）
    - 添加配置变更监听器机制
    - _需求: 6.1, 6.2, 6.3, 6.4_


  - [-] 6.2 实现配置持久化

    - 实现 `load` 方法，从 JSON 文件加载配置
    - 实现 `save` 方法，保存配置到 JSON 文件
    - 配置文件路径：`.minecraft/config/examplemod/dynamic_island.json`
    - 使用 Gson 库进行 JSON 序列化/反序列化
    - 加载失败时使用默认配置

    - _需求: 6.5_

- [ ] 7. 集成到游戏渲染循环
  - [ ] 7.1 实现事件监听
    - 在 `DynamicIsland` 中实现 `onRenderGameOverlay` 方法
    - 订阅 `RenderGameOverlayEvent.Post` 事件

    - 检查事件类型为 `ElementType.ALL`
    - 检查游戏状态（玩家、世界是否存在）
    - 检查是否打开了 GUI（打开时不渲染）
    - _需求: 1.1, 1.2, 1.4_


  - [ ] 7.2 实现主渲染流程
    - 在事件处理器中调用 `update` 方法更新动画
    - 调用 `ContentManager.updateContents` 更新内容
    - 调用 `IslandRenderer.render` 渲染灵动岛
    - 保存和恢复 OpenGL 状态
    - _需求: 1.2, 1.5_


  - [ ] 7.3 注册到 ExampleMod
    - 在 `DynamicIsland` 中实现 `initialize` 方法
    - 在 `ExampleMod.init` 中调用 `DynamicIsland.getInstance().initialize()`
    - 注册 `DynamicIsland` 到 `MinecraftForge.EVENT_BUS`

    - 加载配置文件
    - 加载纹理资源
    - _需求: 1.4_

- [x] 8. 实现状态管理和交互

  - [ ] 8.1 实现状态切换逻辑
    - 在 `DynamicIsland` 中实现 `setState` 方法
    - 调用 `AnimationController.startTransition` 开始动画
    - 实现 `toggleState` 方法，在状态间循环切换
    - 根据内容数量自动调整状态
    - _需求: 4.1, 4.2, 4.3, 4.4_

  - [x] 8.2 实现启用/禁用功能

    - 实现 `setEnabled` 和 `toggle` 方法
    - 禁用时不渲染灵动岛
    - 启用时恢复上次状态
    - _需求: 6.1_


  - [ ] 8.3 添加键盘快捷键
    - 在 `ExampleMod` 中注册切换灵动岛的按键
    - 按键按下时切换启用/禁用状态
    - 或切换显示状态

    - _需求: 4.5_

- [ ] 9. 实现高级功能和优化
  - [ ] 9.1 实现自动状态切换
    - 根据内容数量自动选择合适的状态
    - 内容少时使用 COMPACT，内容多时使用 EXPANDED
    - 实现智能状态选择算法
    - _需求: 4.4_

  - [ ] 9.2 实现内容优先级和过滤
    - 在 `ContentManager` 中根据优先级排序内容
    - 空间不足时隐藏低优先级内容
    - 实现内容淡入淡出动画
    - _需求: 3.3, 3.4_

  - [ ] 9.3 性能优化
    - 限制内容更新频率（每秒 2 次）
    - 缓存渲染结果，状态不变时复用
    - 使用脏标记，只在需要时重新渲染
    - 优化 OpenGL 调用，减少状态切换
    - _需求: 7.5_

- [ ] 10. 创建测试和示例
  - [ ] 10.1 创建基础示例
    - 在初始化时添加默认内容（坐标、生命值）
    - 设置默认状态为 STANDARD
    - 验证灵动岛正确显示在屏幕顶部
    - _需求: 1.1, 7.1, 7.3_

  - [ ] 10.2 创建动画演示
    - 创建测试方法，循环切换所有状态
    - 验证动画流畅性
    - 测试不同缓动函数的效果
    - _需求: 2.1, 2.2, 2.3_

  - [x] 10.3 创建配置 GUI

    - 创建 `DynamicIslandConfigGui` 类
    - 添加滑块调整位置、缩放、透明度
    - 添加开关控制各种效果
    - 添加按钮切换状态
    - 实时预览配置效果
    - _需求: 6.1, 6.2, 6.3, 6.4_



  - [ ] 10.4 创建调试工具
    - 创建 `IslandDebugOverlay` 类
    - 显示当前状态、动画进度、内容数量
    - 显示渲染时间和性能数据
    - 创建 `IslandProfiler` 性能分析器
    - _需求: 8.5_


- [ ] 11. 与现有模块集成
  - [ ] 11.1 与 AutoAttack 集成
    - 当 AutoAttack 启用且有目标时，显示目标信息
    - 在灵动岛中显示目标名称和生命值


    - 目标改变时更新显示
    - _需求: 7.4_

  - [x] 11.2 与 NotificationSystem 集成

    - 当有重要通知时，灵动岛自动展开
    - 在灵动岛中显示通知内容
    - 通知消失后恢复原状态
    - _需求: 3.4_

  - [x] 11.3 与 OpenGL 渲染框架集成（如果已实现）

    - 使用 `TextureManager` 加载纹理
    - 使用 `OpenGLStateManager` 管理状态
    - 使用 `RenderHelper` 辅助渲染
    - _需求: 1.3, 5.1, 5.5_



- [ ] 12. 文档和完善
  - [ ] 12.1 添加代码注释
    - 为所有公共 API 添加 Javadoc 注释
    - 添加使用示例注释
    - 说明关键算法和设计决策
    - _需求: 所有_

  - [ ] 12.2 创建使用文档
    - 编写快速开始指南
    - 编写配置说明
    - 编写自定义内容开发指南
    - 添加常见问题解答
    - _需求: 所有_
