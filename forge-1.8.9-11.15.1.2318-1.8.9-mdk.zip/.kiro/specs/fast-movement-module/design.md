# 设计文档

## 概述

本设计文档描述如何实现快速移动功能模块，包括移动逻辑、速度计算和 GUI 集成。

## 架构

```
FastMovement (单例模式)
├── 状态管理: enabled (boolean)
├── 速度常量: SPEED = 0.4 (每 tick 0.4 格 = 每秒 8 格)
└── 事件处理: onPlayerTick()

ExampleGui
└── 工具面板
    └── 快速移动按钮 (切换开关)
```

## 组件和接口

### 1. FastMovement 类

**职责:**
- 管理快速移动功能的启用/禁用状态
- 在每个 tick 应用移动速度
- 响应玩家输入（WASD、跳跃、潜行）

**关键方法:**
```java
public class FastMovement {
    private static FastMovement instance;
    private boolean enabled = false;
    private static final double SPEED = 0.4; // 每 tick 0.4 格 = 每秒 8 格
    
    public static FastMovement getInstance();
    public void toggle();
    public boolean isEnabled();
    public void onPlayerTick(EntityPlayerSP player);
}
```

**移动逻辑:**
```java
// 计算移动方向
double motionX = 0, motionY = 0, motionZ = 0;

// 前后移动（W/S）
if (forward) motionZ -= SPEED * cos(yaw);
if (backward) motionZ += SPEED * cos(yaw);

// 左右移动（A/D）
if (left) motionX -= SPEED * sin(yaw);
if (right) motionX += SPEED * sin(yaw);

// 上下移动（Space/Shift）
if (jump) motionY += SPEED;
if (sneak) motionY -= SPEED;

// 应用速度
player.motionX = motionX;
player.motionY = motionY;
player.motionZ = motionZ;
```

### 2. 事件处理器

**使用 Forge 事件系统:**
```java
@SubscribeEvent
public void onClientTick(TickEvent.ClientTickEvent event) {
    if (event.phase == TickEvent.Phase.START) {
        EntityPlayerSP player = Minecraft.getMinecraft().thePlayer;
        if (player != null && FastMovement.getInstance().isEnabled()) {
            FastMovement.getInstance().onPlayerTick(player);
        }
    }
}
```

### 3. GUI 集成

**修改 ExampleGui:**
- 在"工具"分类面板中添加"快速移动"按钮
- 按钮点击时调用 `FastMovement.getInstance().toggle()`
- 显示当前状态（启用显示绿色，禁用显示灰色）

**按钮文本格式:**
```
快速移动: [开启]
快速移动: [关闭]
```

## 数据模型

### 速度计算

```
Minecraft tick rate: 20 ticks/秒
目标速度: 8 格/秒
每 tick 速度: 8 / 20 = 0.4 格/tick
```

### 方向计算

```java
// 玩家朝向角度（弧度）
float yaw = player.rotationYaw * (float)Math.PI / 180.0f;

// 前进方向向量
double forwardX = -Math.sin(yaw);
double forwardZ = Math.cos(yaw);

// 右侧方向向量
double rightX = Math.cos(yaw);
double rightZ = Math.sin(yaw);
```

## 错误处理

### 1. 空指针检查
```java
if (player == null || mc.theWorld == null) return;
```

### 2. 游戏暂停检查
```java
if (mc.isGamePaused()) return;
```

### 3. GUI 打开时禁用
```java
if (mc.currentScreen != null) return;
```

## 测试策略

### 手动测试
1. 启动游戏，打开 GUI
2. 点击"快速移动"按钮启用功能
3. 测试各方向移动：
   - W: 前进
   - S: 后退
   - A: 左移
   - D: 右移
   - Space: 上升
   - Shift: 下降
4. 测试组合移动（W+A, W+D 等）
5. 验证速度约为每秒 8 格
6. 关闭功能，验证恢复正常速度

## 性能考虑

- 使用单例模式避免重复创建对象
- 仅在功能启用时执行计算
- 使用简单的三角函数计算，性能开销极小
- 每 tick 执行一次，符合 Minecraft 标准

## 安全性

- 仅客户端功能，不影响服务器
- 不修改游戏核心代码
- 可随时禁用
- 不会导致游戏崩溃
