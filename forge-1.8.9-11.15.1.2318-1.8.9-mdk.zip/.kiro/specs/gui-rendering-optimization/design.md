# 设计文档

## 概述

本设计文档描述了如何修复 ExampleGui 中的自定义字体渲染问题和优化 Tessellator 渲染性能。主要解决方案包括：简化字体渲染逻辑、确保 Tessellator 正确使用、清理冗余代码。

## 架构

### 当前架构问题

1. **字体渲染**: 使用了不适用于 Minecraft 1.8.9 的反射代码尝试获取自定义字体
2. **代码冗余**: 存在未使用的导入（Minecraft, RenderManager）
3. **Tessellator 使用**: 已实现但需要验证正确性

### 优化后架构

```
ExampleGui
├── 字体渲染: 直接使用 fontRendererObj（默认字体渲染器）
├── 背景渲染: Tessellator + WorldRenderer（批量渲染）
└── 面板渲染: CategoryPanel 使用 Tessellator 绘制背景
```

## 组件和接口

### 1. 字体渲染组件

**问题分析:**
- Minecraft 1.8.9 的 FontRenderer 不支持通过反射动态加载自定义字体
- 自定义字体需要通过资源包（Resource Pack）机制加载
- 当前的 `getCustomFontRenderer()` 方法使用了不存在的 API

**解决方案:**
```java
// 简化方案：直接使用默认字体渲染器
private void drawCustomFontString(String text, int x, int y, int color) {
    fontRendererObj.drawStringWithShadow(text, x, y, color);
}
```

**如果需要真正的自定义字体:**
- 方案 A: 使用资源包替换默认字体（修改 `assets/minecraft/textures/font/ascii.png`）
- 方案 B: 使用第三方库如 TrueTypeFont（需要额外依赖）
- 方案 C: 保持使用默认字体，通过颜色和样式区分

### 2. Tessellator 渲染优化

**当前实现分析:**

```java
// drawTransparentBackground() - 正确实现
Tessellator tessellator = Tessellator.getInstance();
WorldRenderer worldRenderer = tessellator.getWorldRenderer();
worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
// 添加顶点...
tessellator.draw();
```

**优化点:**
1. 确保颜色分量转换正确（0-255 → 0.0-1.0）
2. 确保 OpenGL 状态正确管理
3. 确保顶点顺序正确（逆时针）

**CategoryPanel 的 drawPanelBackground() 方法:**
- 已使用 Tessellator
- 使用 `addQuad()` 辅助方法构建四边形
- 需要验证颜色转换逻辑

### 3. OpenGL 状态管理

**关键状态:**
```java
GlStateManager.enableBlend();                                    // 启用混合
GlStateManager.disableTexture2D();                              // 禁用纹理（绘制纯色）
GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
// ... 渲染 ...
GlStateManager.enableTexture2D();                               // 恢复纹理
GlStateManager.disableBlend();                                  // 禁用混合
```

## 数据模型

### 颜色数据转换

```java
// ARGB 整数 → RGBA 浮点数
int color = 0xAABBCCDD;  // AA=alpha, BB=red, CC=green, DD=blue
float a = (color >> 24 & 0xFF) / 255.0f;
float r = (color >> 16 & 0xFF) / 255.0f;
float g = (color >> 8 & 0xFF) / 255.0f;
float b = (color & 0xFF) / 255.0f;
```

### 顶点数据格式

使用 `DefaultVertexFormats.POSITION_COLOR`:
```java
worldRenderer.pos(x, y, z).color(r, g, b, a).endVertex();
```

## 错误处理

### 1. 字体渲染失败
- **策略**: 移除复杂的反射代码，直接使用 `fontRendererObj`
- **回退**: 如果 `fontRendererObj` 为 null（极少情况），跳过文本渲染

### 2. Tessellator 渲染异常
- **预防**: 确保 `begin()` 和 `draw()` 成对调用
- **状态恢复**: 使用 try-finally 或 GlStateManager.pushMatrix/popMatrix

### 3. 纹理加载失败
- **当前处理**: 已有 try-catch，回退到 DEFAULT_TEXTURE
- **保持现状**: 这部分实现正确

## 测试策略

### 单元测试
- 不适用（GUI 渲染需要 Minecraft 环境）

### 集成测试
1. **字体渲染测试**
   - 启动游戏，打开 GUI
   - 验证所有文本正确显示
   - 验证中文字符正确渲染

2. **Tessellator 渲染测试**
   - 验证背景半透明效果
   - 验证面板背景颜色正确
   - 验证无渲染错误或闪烁

3. **性能测试**
   - 使用 F3 调试界面监控 FPS
   - 对比优化前后的渲染性能

### 手动测试步骤
1. 编译模组
2. 启动 Minecraft 1.8.9 + Forge
3. 触发 ExampleGui 显示（通过命令或按键）
4. 验证：
   - 文本清晰可读
   - 背景半透明
   - 面板动画流畅
   - 无控制台错误

## 实现优先级

1. **高优先级**: 修复字体渲染（移除反射代码）
2. **高优先级**: 清理未使用的导入
3. **中优先级**: 验证 Tessellator 实现正确性
4. **低优先级**: 性能微调

## 技术约束

- Minecraft 版本: 1.8.9
- Forge 版本: 11.15.1.2318
- Java 版本: 8
- OpenGL 版本: 2.1+（Minecraft 要求）

## 性能考虑

### Tessellator 优势
- 批量提交顶点数据，减少 OpenGL 调用
- 比 `drawRect()` 更高效（drawRect 内部也使用 Tessellator）

### 当前实现评估
- `drawTransparentBackground()`: ✓ 已优化
- `CategoryPanel.drawPanelBackground()`: ✓ 已优化
- `drawTitleBar()`: 使用 `drawRect()`，可接受（小矩形）
- `Button.draw()`: 使用 `drawRect()`，可接受（小矩形）

**结论**: 当前 Tessellator 使用已经合理，主要问题在字体渲染。
