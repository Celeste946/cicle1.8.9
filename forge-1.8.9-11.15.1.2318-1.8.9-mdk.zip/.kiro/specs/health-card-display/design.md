# 设计文档

## 概述

血量卡片显示系统是一个基于事件驱动的渲染模块，用于在 Minecraft 实体头顶显示可视化的血量状态卡片。系统采用单例模式设计，通过监听 Forge 的实体渲染事件来实现实时的血量卡片渲染。该系统与现有的 AutoAttack 模块集成，只在攻击目标时显示卡片，避免屏幕信息过载。

## 架构

### 系统组件关系

```mermaid
graph TD
    A[ExampleMod] -->|注册| B[HealthCardRenderer]
    B -->|监听| C[RenderLivingEvent.Specials.Post]
    B -->|查询状态| D[AutoAttack]
    B -->|渲染| E[Minecraft Renderer]
    D -->|提供| F[攻击范围]
    D -->|提供| G[启用状态]
    C -->|触发| B
    E -->|使用| H[纹理管理器]
    E -->|使用| I[字体渲染器]
```

### 设计模式

1. **单例模式**: HealthCardRenderer 使用单例模式确保全局只有一个实例，便于状态管理和事件注册
2. **事件驱动**: 通过 Forge 事件总线监听实体渲染事件，实现非侵入式的渲染扩展
3. **策略模式**: 血量档位映射采用策略模式，根据血量百分比选择对应的纹理资源

## 组件和接口

### HealthCardRenderer 类

**职责**: 
- 管理血量卡片的渲染逻辑
- 维护血量档位到纹理的映射关系
- 与 AutoAttack 模块协作判断渲染目标

**公共接口**:

```java
public class HealthCardRenderer {
    // 获取单例实例
    public static HealthCardRenderer getInstance()
    
    // 获取启用状态
    public boolean isEnabled()
    
    // 设置启用状态
    public void setEnabled(boolean enabled)
    
    // 事件处理方法（由 Forge 调用）
    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Specials.Post<EntityLivingBase> event)
}
```

**私有方法**:

```java
// 检查实体是否为当前攻击目标
private boolean isCurrentTarget(EntityLivingBase entity)

// 根据血量百分比获取对应的卡片纹理
private ResourceLocation getHealthCardTexture(float healthPercent)

// 执行卡片渲染
private void renderHealthCard(EntityLivingBase entity, double x, double y, double z, RenderManager renderManager)
```

### 与 ExampleMod 的集成

ExampleMod 需要在初始化阶段注册 HealthCardRenderer：

```java
@Mod.EventHandler
public void init(FMLInitializationEvent event) {
    // ... 其他注册代码 ...
    
    // 注册血量卡片渲染器
    MinecraftForge.EVENT_BUS.register(HealthCardRenderer.getInstance());
    System.out.println("[ExampleMod] 血量卡片渲染器已注册");
}
```

## 数据模型

### 血量档位映射

系统使用静态 HashMap 存储血量档位到纹理资源的映射：

```java
private static final Map<Integer, ResourceLocation> HEALTH_CARDS = new HashMap<>();

static {
    HEALTH_CARDS.put(0, new ResourceLocation("examplemod", "textures/hbcard/HB0.png"));
    HEALTH_CARDS.put(10, new ResourceLocation("examplemod", "textures/hbcard/HB10.png"));
    HEALTH_CARDS.put(20, new ResourceLocation("examplemod", "textures/hbcard/HB20.png"));
    HEALTH_CARDS.put(30, new ResourceLocation("examplemod", "textures/hbcard/HB30.png"));
    HEALTH_CARDS.put(50, new ResourceLocation("examplemod", "textures/hbcard/HB50.png"));
    HEALTH_CARDS.put(70, new ResourceLocation("examplemod", "textures/hbcard/HB70.png"));
    HEALTH_CARDS.put(80, new ResourceLocation("examplemod", "textures/hbcard/HB80.png"));
    HEALTH_CARDS.put(90, new ResourceLocation("examplemod", "textures/hbcard/HB90.png"));
    HEALTH_CARDS.put(100, new ResourceLocation("examplemod", "textures/hbcard/HB100.png"));
}
```

**档位选择逻辑**:
- 0% ≤ 血量 ≤ 0%: HB0.png
- 1% ≤ 血量 ≤ 10%: HB10.png
- 11% ≤ 血量 ≤ 20%: HB20.png
- 21% ≤ 血量 ≤ 30%: HB30.png
- 31% ≤ 血量 ≤ 50%: HB50.png
- 51% ≤ 血量 ≤ 70%: HB70.png
- 71% ≤ 血量 ≤ 80%: HB80.png
- 81% ≤ 血量 ≤ 90%: HB90.png
- 91% ≤ 血量 ≤ 100%: HB100.png

### 渲染参数

```java
private static final float CARD_WIDTH = 64.0f;   // 卡片宽度（像素）
private static final float CARD_HEIGHT = 64.0f;  // 卡片高度（像素）
private static final float VERTICAL_OFFSET = 0.8f; // 卡片相对实体头顶的垂直偏移
private static final float SCALE = 0.016666668f * 0.5f; // 渲染缩放系数
```

## 渲染流程

### 事件处理流程

```mermaid
sequenceDiagram
    participant Forge as Forge Event Bus
    participant HCR as HealthCardRenderer
    participant AA as AutoAttack
    participant MC as Minecraft Renderer
    
    Forge->>HCR: RenderLivingEvent.Specials.Post
    HCR->>HCR: 检查 enabled 状态
    alt enabled == false
        HCR-->>Forge: 返回（不渲染）
    end
    HCR->>AA: isEnabled()
    AA-->>HCR: 返回启用状态
    alt AutoAttack 未启用
        HCR-->>Forge: 返回（不渲染）
    end
    HCR->>AA: getAttackRange()
    AA-->>HCR: 返回攻击范围
    HCR->>HCR: 计算实体距离
    alt 实体不在范围内
        HCR-->>Forge: 返回（不渲染）
    end
    HCR->>HCR: 计算血量百分比
    HCR->>HCR: 选择对应纹理
    HCR->>MC: 渲染卡片和文本
    MC-->>HCR: 渲染完成
    HCR-->>Forge: 事件处理完成
```

### 渲染步骤

1. **坐标变换**
   - 移动到实体头顶上方（y + entity.height + 0.8f）
   - 应用视角旋转使卡片面向玩家
   - 应用缩放变换

2. **OpenGL 状态设置**
   ```java
   GlStateManager.disableLighting();      // 禁用光照
   GlStateManager.depthMask(false);       // 禁用深度写入
   GlStateManager.disableDepth();         // 禁用深度测试
   GlStateManager.enableBlend();          // 启用混合
   GlStateManager.tryBlendFuncSeparate(   // 设置混合函数
       GL11.GL_SRC_ALPHA, 
       GL11.GL_ONE_MINUS_SRC_ALPHA, 
       1, 0
   );
   ```

3. **纹理渲染**
   - 绑定对应血量档位的纹理
   - 使用 Tessellator 绘制四边形
   - 卡片居中显示（-CARD_WIDTH/2, -CARD_HEIGHT/2）

4. **文本渲染**
   - 格式化血量文本："当前血量/最大血量"（保留一位小数）
   - 计算文本宽度实现居中
   - 在卡片下方绘制带阴影的白色文本

5. **状态恢复**
   ```java
   GlStateManager.enableDepth();
   GlStateManager.depthMask(true);
   GlStateManager.enableLighting();
   GlStateManager.disableBlend();
   GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
   ```

## 与现有系统的集成

### AutoAttack 模块依赖

HealthCardRenderer 依赖 AutoAttack 模块提供以下信息：

1. **启用状态**: 通过 `AutoAttack.getInstance().isEnabled()` 判断是否应该显示卡片
2. **攻击范围**: 通过 `AutoAttack.getInstance().getAttackRange()` 获取当前攻击范围设置
3. **目标过滤**: 只对在攻击范围内的实体显示卡片

### 与其他渲染器的协同

系统与现有的渲染器（HitCircleRenderer、NameTagRenderer）采用相同的架构模式：

- 单例模式管理实例
- 事件驱动的渲染触发
- 独立的启用/禁用控制
- 相似的 OpenGL 状态管理流程

这种一致性确保了代码的可维护性和扩展性。

## 错误处理

### 空值检查

```java
// 检查实体有效性
if (entity == null || !entity.isEntityAlive()) return;

// 检查 Minecraft 实例
Minecraft mc = Minecraft.getMinecraft();
if (mc.thePlayer == null) return;

// 检查 RenderManager
if (renderManager == null) return;
```

### 纹理加载失败

如果纹理文件不存在，Minecraft 会使用默认的缺失纹理（紫黑格子），不会导致崩溃。建议在资源包中确保所有纹理文件存在。

### 渲染异常

所有 OpenGL 状态修改都包裹在 `pushMatrix()` 和 `popMatrix()` 之间，确保即使发生异常也不会影响其他渲染。

## 性能考虑

### 优化策略

1. **早期返回**: 在事件处理开始时进行多层过滤，避免不必要的计算
   - 检查 enabled 状态
   - 检查 AutoAttack 启用状态
   - 检查实体距离

2. **静态资源**: 纹理映射使用静态初始化，避免重复创建对象

3. **最小化状态切换**: 将所有 OpenGL 状态设置集中在一起，减少状态切换开销

4. **单例模式**: 避免重复创建渲染器实例

### 性能影响评估

- **CPU**: 每帧对范围内的实体进行距离计算和血量检查，影响较小
- **GPU**: 每个目标渲染一个四边形和一行文本，对于少量目标（<10）影响可忽略
- **内存**: 静态纹理映射占用约 9 个 ResourceLocation 对象，内存占用极小

## 测试策略

### 功能测试

1. **基本渲染测试**
   - 启用 AutoAttack 并接近实体
   - 验证卡片是否显示在实体头顶
   - 验证卡片是否面向玩家

2. **血量档位测试**
   - 攻击实体使其血量降低
   - 验证卡片纹理是否随血量变化正确切换
   - 测试所有 9 个血量档位

3. **文本显示测试**
   - 验证血量数值格式正确（一位小数）
   - 验证文本居中对齐
   - 验证文本阴影效果

4. **开关控制测试**
   - 通过 GUI 禁用功能，验证卡片不再显示
   - 重新启用功能，验证卡片恢复显示

5. **范围过滤测试**
   - 调整 AutoAttack 攻击范围
   - 验证只有范围内的实体显示卡片
   - 验证超出范围的实体不显示卡片

### 集成测试

1. **与 AutoAttack 集成**
   - 禁用 AutoAttack，验证卡片不显示
   - 启用 AutoAttack，验证卡片正常显示

2. **与其他渲染器共存**
   - 同时启用 HealthCardRenderer、HitCircleRenderer、NameTagRenderer
   - 验证各渲染器互不干扰
   - 验证渲染顺序正确

### 性能测试

1. **多目标场景**
   - 在范围内放置多个实体（5-10 个）
   - 监控帧率变化
   - 验证性能影响在可接受范围内

2. **长时间运行**
   - 持续运行 30 分钟
   - 验证无内存泄漏
   - 验证渲染稳定性

## 未来扩展

### 可能的增强功能

1. **动画效果**: 卡片切换时添加淡入淡出动画
2. **自定义样式**: 允许玩家自定义卡片颜色和样式
3. **距离淡出**: 根据距离调整卡片透明度
4. **多语言支持**: 支持不同语言的血量文本显示
5. **配置文件**: 将卡片大小、位置等参数移至配置文件

### 扩展点

- `getHealthCardTexture()` 方法可以扩展为支持自定义档位映射
- 渲染参数可以提取为配置类，支持运行时调整
- 可以添加事件回调接口，允许其他模块监听卡片显示事件
