# 需求文档

## 简介

血量卡片显示系统是一个为 Minecraft 实体提供可视化血量反馈的功能。当玩家攻击目标时，系统会在目标实体头顶显示对应血量档位的卡片图片，让玩家能够直观地了解目标的当前血量状态。

## 术语表

- **HealthCardRenderer**: 血量卡片渲染器，负责在实体头顶渲染血量卡片的系统组件
- **EntityLivingBase**: Minecraft 中所有生物实体的基类
- **AutoAttack**: 自动攻击模块，用于判断当前攻击目标
- **RenderLivingEvent**: Minecraft Forge 提供的实体渲染事件
- **血量档位**: 根据血量百分比划分的不同等级（0%, 10%, 20%, 30%, 50%, 70%, 80%, 90%, 100%）
- **卡片纹理**: 存储在 textures/hbcard/ 目录下的血量卡片图片资源

## 需求

### 需求 1

**用户故事:** 作为玩家，我希望在攻击目标时能看到目标头顶显示的血量卡片，以便直观了解目标的血量状态

#### 验收标准

1. WHEN 玩家攻击范围内存在目标实体，THE HealthCardRenderer SHALL 在目标实体头顶上方 0.8 个方块单位处渲染血量卡片
2. WHILE 目标实体在攻击范围内，THE HealthCardRenderer SHALL 持续更新并显示与当前血量百分比对应的卡片纹理
3. WHEN 目标实体血量变化时，THE HealthCardRenderer SHALL 根据新的血量百分比选择对应档位的卡片纹理进行渲染
4. THE HealthCardRenderer SHALL 使卡片始终面向玩家视角，确保卡片可见性

### 需求 2

**用户故事:** 作为玩家，我希望血量卡片能根据不同的血量百分比显示不同的图片，以便快速判断目标的危险程度

#### 验收标准

1. WHEN 目标实体血量百分比小于等于 0%，THE HealthCardRenderer SHALL 渲染 HB0.png 卡片纹理
2. WHEN 目标实体血量百分比在 1% 到 10% 之间，THE HealthCardRenderer SHALL 渲染 HB10.png 卡片纹理
3. WHEN 目标实体血量百分比在 11% 到 20% 之间，THE HealthCardRenderer SHALL 渲染 HB20.png 卡片纹理
4. WHEN 目标实体血量百分比在 21% 到 30% 之间，THE HealthCardRenderer SHALL 渲染 HB30.png 卡片纹理
5. WHEN 目标实体血量百分比在 31% 到 50% 之间，THE HealthCardRenderer SHALL 渲染 HB50.png 卡片纹理
6. WHEN 目标实体血量百分比在 51% 到 70% 之间，THE HealthCardRenderer SHALL 渲染 HB70.png 卡片纹理
7. WHEN 目标实体血量百分比在 71% 到 80% 之间，THE HealthCardRenderer SHALL 渲染 HB80.png 卡片纹理
8. WHEN 目标实体血量百分比在 81% 到 90% 之间，THE HealthCardRenderer SHALL 渲染 HB90.png 卡片纹理
9. WHEN 目标实体血量百分比在 91% 到 100% 之间，THE HealthCardRenderer SHALL 渲染 HB100.png 卡片纹理

### 需求 3

**用户故事:** 作为玩家，我希望在血量卡片下方看到精确的数值显示，以便了解目标的确切血量

#### 验收标准

1. THE HealthCardRenderer SHALL 在卡片下方居中位置渲染血量文本
2. THE HealthCardRenderer SHALL 以 "当前血量/最大血量" 格式显示血量数值，保留一位小数
3. THE HealthCardRenderer SHALL 为血量文本添加阴影效果，确保在各种背景下的可读性
4. THE HealthCardRenderer SHALL 使用白色（0xFFFFFF）作为血量文本的颜色

### 需求 4

**用户故事:** 作为玩家，我希望能够通过 GUI 开关血量卡片显示功能，以便根据需要控制显示效果

#### 验收标准

1. THE HealthCardRenderer SHALL 提供 setEnabled 方法接受布尔值参数以启用或禁用血量卡片渲染
2. THE HealthCardRenderer SHALL 提供 isEnabled 方法返回当前启用状态
3. WHEN 血量卡片功能被禁用，THE HealthCardRenderer SHALL 不渲染任何血量卡片
4. THE HealthCardRenderer SHALL 默认启用血量卡片显示功能

### 需求 5

**用户故事:** 作为开发者，我希望血量卡片渲染器能正确注册到事件总线，以便系统能够响应实体渲染事件

#### 验收标准

1. THE ExampleMod SHALL 在初始化阶段将 HealthCardRenderer 实例注册到 MinecraftForge.EVENT_BUS
2. THE HealthCardRenderer SHALL 使用单例模式，通过 getInstance 方法提供全局访问点
3. WHEN HealthCardRenderer 注册成功，THE ExampleMod SHALL 在控制台输出确认信息
4. THE HealthCardRenderer SHALL 订阅 RenderLivingEvent.Specials.Post 事件以执行渲染逻辑

### 需求 6

**用户故事:** 作为玩家，我希望血量卡片只在攻击目标时显示，避免屏幕上出现过多干扰信息

#### 验收标准

1. WHEN AutoAttack 模块未启用，THE HealthCardRenderer SHALL 不渲染任何血量卡片
2. WHEN 实体距离玩家超过 AutoAttack 设置的攻击范围，THE HealthCardRenderer SHALL 不渲染该实体的血量卡片
3. WHEN 实体在 AutoAttack 攻击范围内且 AutoAttack 已启用，THE HealthCardRenderer SHALL 渲染该实体的血量卡片
4. THE HealthCardRenderer SHALL 通过 AutoAttack.getInstance().getAttackRange() 获取当前攻击范围设置
