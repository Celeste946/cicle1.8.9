# 实现计划

- [x] 1. 在 ExampleMod 中注册 HealthCardRenderer





  - 在 ExampleMod.init() 方法中将 HealthCardRenderer 实例注册到 MinecraftForge.EVENT_BUS
  - 添加控制台输出确认注册成功
  - 确保注册代码位于其他渲染器注册代码之后，保持代码组织一致性
  - _需求: 5.1, 5.3_

- [x] 2. 验证 HealthCardRenderer 核心功能





- [x] 2.1 验证事件监听和目标过滤逻辑


  - 确认 onRenderLiving 方法正确订阅 RenderLivingEvent.Specials.Post 事件
  - 验证 isCurrentTarget 方法正确检查 AutoAttack 启用状态和攻击范围
  - 确认只有在 AutoAttack 启用且实体在范围内时才渲染卡片
  - _需求: 5.4, 6.1, 6.2, 6.3, 6.4_

- [x] 2.2 验证血量档位映射逻辑

  - 确认 getHealthCardTexture 方法正确实现 9 个血量档位的映射
  - 验证边界条件（0%, 10%, 20%, 30%, 50%, 70%, 80%, 90%, 100%）
  - 确认纹理路径正确指向 textures/hbcard/ 目录下的对应文件
  - _需求: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9_


- [x] 2.3 验证卡片渲染实现

  - 确认 renderHealthCard 方法正确计算实体头顶位置（y + entity.height + 0.8f）
  - 验证卡片面向玩家的旋转变换正确应用
  - 确认卡片居中渲染（-CARD_WIDTH/2, -CARD_HEIGHT/2）
  - 验证 OpenGL 状态设置和恢复正确（光照、深度、混合）
  - _需求: 1.1, 1.2, 1.3, 1.4_

- [x] 2.4 验证血量文本显示

  - 确认血量文本格式正确（"当前血量/最大血量"，保留一位小数）
  - 验证文本居中对齐（-textWidth / 2.0f）
  - 确认文本位置在卡片下方（CARD_HEIGHT / 2.0f + 5）
  - 验证文本使用白色（0xFFFFFF）和阴影效果
  - _需求: 3.1, 3.2, 3.3, 3.4_

- [x] 2.5 验证启用/禁用控制

  - 确认 enabled 字段默认值为 true
  - 验证 isEnabled() 和 setEnabled() 方法正确实现
  - 确认禁用时 onRenderLiving 方法提前返回，不执行渲染
  - _需求: 4.1, 4.2, 4.3, 4.4_

- [ ] 3. 在游戏中测试血量卡片显示
  - 启动 Minecraft 并加载 mod
  - 启用 AutoAttack 功能
  - 接近实体并验证卡片显示在实体头顶
  - 攻击实体使血量降低，验证卡片纹理随血量变化正确切换
  - 测试不同血量档位的卡片显示
  - 调整 AutoAttack 攻击范围，验证范围过滤功能
  - 禁用 AutoAttack，验证卡片不再显示
  - _需求: 1.1, 1.2, 1.3, 2.1-2.9, 3.1-3.4, 6.1, 6.2, 6.3_
