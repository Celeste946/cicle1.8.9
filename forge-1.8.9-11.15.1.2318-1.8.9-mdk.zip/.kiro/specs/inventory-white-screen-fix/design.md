# 背包白屏问题修复 - 设计文档

## 概述

背包白屏问题是由于自定义渲染器在 GUI 打开时没有正确处理 OpenGL 状态导致的。主要问题包括：

1. **纹理绑定未清理**: 某些渲染器（如 `NameTagRenderer`）绑定了自定义纹理但未在 GUI 渲染前解除绑定
2. **OpenGL 状态污染**: 渲染器修改了混合模式、深度测试等状态，但在某些情况下未完全恢复
3. **渲染事件时机**: 部分渲染器在不应该渲染的时候仍在执行渲染逻辑

## 架构

### 问题根源分析

通过代码审查，发现以下潜在问题：

1. **NameTagRenderer**: 
   - 绑定了 `LOGO_TEXTURE` 纹理
   - 虽然有状态恢复代码，但可能在某些边缘情况下未正确执行
   - 需要确保在 GUI 打开时完全跳过渲染

2. **HitCircleRenderer**:
   - 修改了深度测试、光照、纹理等多个 OpenGL 状态
   - 在 `RenderWorldLastEvent` 中渲染，理论上不应影响 GUI
   - 但需要确保状态恢复的完整性

3. **CustomSwingAnimation**:
   - 修改了手部渲染的变换矩阵
   - 在 GUI 打开时不应该执行

4. **HealthCardRenderer** 和 **NotificationSystem**:
   - 已经有 `mc.currentScreen != null` 检查
   - 但可能在检查之前已经修改了某些状态

### 解决方案架构

采用**防御性渲染**策略：

```
┌─────────────────────────────────────────┐
│         渲染事件触发                      │
└─────────────┬───────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────┐
│   检查 GUI 状态 (mc.currentScreen)       │
│   - 如果 GUI 打开，立即返回               │
│   - 不执行任何 OpenGL 操作               │
└─────────────┬───────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────┐
│   执行渲染逻辑                           │
│   - 使用 try-finally 确保状态恢复        │
│   - pushMatrix/popMatrix 配对            │
│   - 显式恢复所有修改的状态               │
└─────────────────────────────────────────┘
```

## 组件和接口

### 1. NameTagRenderer 修复

**问题**: 纹理绑定可能未清理

**解决方案**:
- 在方法开始处检查 GUI 状态
- 使用 try-finally 确保纹理解绑
- 在渲染结束后显式调用 `GlStateManager.bindTexture(0)` 解除纹理绑定

### 2. HitCircleRenderer 修复

**问题**: 复杂的 OpenGL 状态修改

**解决方案**:
- 在 `onRenderWorld` 开始处检查 GUI 状态
- 使用 try-finally 包裹所有渲染代码
- 确保所有状态修改都有对应的恢复操作

### 3. CustomSwingAnimation 修复

**问题**: 在 GUI 打开时不应该修改手部渲染

**解决方案**:
- 在 `onRenderHand` 开始处检查 GUI 状态
- 如果 GUI 打开，直接返回不执行任何变换

### 4. HealthCardRenderer 和 NotificationSystem 增强

**问题**: 虽然有检查，但可能不够早

**解决方案**:
- 将 GUI 检查移到方法最开始
- 确保在任何 OpenGL 操作之前就返回

### 5. ExampleGui 渲染优化

**问题**: GUI 自身的渲染可能有问题

**解决方案**:
- 确保 `drawScreen` 方法正确调用 `drawDefaultBackground()`
- 使用 try-catch 包裹着色器效果，失败时回退到默认背景
- 确保所有自定义渲染都正确恢复 OpenGL 状态

## 数据模型

无需修改数据模型，仅需修改渲染逻辑。

## 错误处理

### 渲染异常处理

所有渲染器都应该使用以下模式：

```java
@SubscribeEvent
public void onRender(Event event) {
    // 1. 尽早检查 GUI 状态
    Minecraft mc = Minecraft.getMinecraft();
    if (mc.currentScreen != null) {
        return; // 不执行任何操作
    }
    
    // 2. 使用 try-finally 确保状态恢复
    GlStateManager.pushMatrix();
    try {
        // 渲染逻辑
    } catch (Exception e) {
        // 记录错误但不崩溃
        System.err.println("渲染错误: " + e.getMessage());
    } finally {
        // 确保状态恢复
        GlStateManager.popMatrix();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
}
```

### 纹理绑定清理

对于绑定自定义纹理的渲染器：

```java
try {
    mc.getTextureManager().bindTexture(CUSTOM_TEXTURE);
    // 渲染逻辑
} finally {
    // 解除纹理绑定，恢复到默认状态
    GlStateManager.bindTexture(0);
}
```

## 测试策略

### 单元测试

不适用 - 这是渲染问题，需要在游戏中测试。

### 集成测试

1. **基本背包测试**:
   - 打开背包（E 键）
   - 验证背包界面正常显示
   - 验证可以看到物品栏

2. **其他 GUI 测试**:
   - 打开自定义 GUI（R 键）
   - 验证 GUI 正常显示
   - 验证所有按钮和控件可见

3. **背包行走测试**:
   - 打开背包
   - 尝试移动（WASD 键）
   - 验证可以移动且背包仍然正常显示

4. **渲染器组合测试**:
   - 启用所有功能（自动攻击、血量卡片等）
   - 打开背包
   - 验证没有白屏
   - 关闭背包
   - 验证所有渲染器恢复正常工作

5. **边缘情况测试**:
   - 在攻击动画进行中打开背包
   - 在受到攻击时打开背包
   - 在第三人称视角下打开背包

### 性能测试

- 验证修复后的渲染性能没有明显下降
- 使用 F3 查看 FPS，确保稳定

## 实现优先级

1. **高优先级**: NameTagRenderer - 最可能的罪魁祸首（纹理绑定）
2. **高优先级**: CustomSwingAnimation - 在 GUI 打开时应该完全禁用
3. **中优先级**: HitCircleRenderer - 状态恢复增强
4. **低优先级**: HealthCardRenderer 和 NotificationSystem - 已有检查，仅需优化

## 回滚计划

如果修复导致其他问题：

1. 保留原始文件的备份
2. 可以逐个渲染器回滚
3. 使用 Git 版本控制追踪更改

## 技术债务

- 考虑创建一个统一的渲染器基类，封装 GUI 检查和状态管理逻辑
- 考虑使用渲染器管理器统一控制所有自定义渲染器
- 添加调试模式，可以单独开关每个渲染器
