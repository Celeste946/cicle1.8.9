# 设计文档

## 概述

本设计文档描述了一个高级渲染框架的架构，该框架结合 Minecraft 1.8.9 Forge 的渲染系统与 OpenGL 底层接口，提供纹理管理、OpenGL 状态管理和可扩展的渲染管道功能。

框架的核心目标是：
- 简化纹理加载和管理流程
- 提供类型安全的 OpenGL 状态管理
- 支持可组合的渲染管道
- 与现有的 Minecraft Forge 事件系统无缝集成
- 提供高性能的渲染操作

## 架构

### 系统架构图

```mermaid
graph TB
    A[RenderingFramework] --> B[TextureManager]
    A --> C[OpenGLStateManager]
    A --> D[RenderPipeline]
    
    B --> E[TextureCache]
    B --> F[TextureLoader]
    
    C --> G[StateStack]
    C --> H[BlendMode]
    
    D --> I[RenderStage]
    D --> J[ConditionalStage]
    
    K[MinecraftForge Events] --> A
    A --> L[Custom Renderers]
    
    L --> M[HealthCardRenderer]
    L --> N[HitCircleRenderer]
    L --> O[NameTagRenderer]
```

### 核心组件关系

1. **RenderingFramework** - 框架的主入口点，协调所有子系统
2. **TextureManager** - 管理纹理的加载、缓存和绑定
3. **OpenGLStateManager** - 封装 OpenGL 状态操作，提供状态栈
4. **RenderPipeline** - 管理渲染阶段的执行顺序

## 组件和接口

### 1. RenderingFramework

框架的主类，负责初始化和协调所有渲染组件。

```java
public class RenderingFramework {
    private static RenderingFramework instance;
    private TextureManager textureManager;
    private OpenGLStateManager stateManager;
    private List<RenderPipeline> pipelines;
    private boolean debugMode;
    
    // 单例模式
    public static RenderingFramework getInstance();
    
    // 初始化框架
    public void initialize();
    
    // 注册渲染管道
    public void registerPipeline(String name, RenderPipeline pipeline, int priority);
    public void unregisterPipeline(String name);
    
    // 获取子系统
    public TextureManager getTextureManager();
    public OpenGLStateManager getStateManager();
    
    // 调试模式
    public void setDebugMode(boolean enabled);
    public boolean isDebugMode();
    
    // 事件处理
    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Post event);
}
```

### 2. TextureManager

管理纹理资源的加载、缓存和绑定。

```java
public class TextureManager {
    private Map<ResourceLocation, CachedTexture> textureCache;
    private ResourceLocation defaultTexture;
    private Minecraft mc;
    
    // 纹理加载
    public ResourceLocation loadTexture(String path);
    public ResourceLocation loadTexture(ResourceLocation location);
    
    // 纹理绑定
    public void bindTexture(ResourceLocation location);
    public void unbindTexture();
    
    // 缓存管理
    public boolean isTextureCached(ResourceLocation location);
    public void clearCache();
    public void removeFromCache(ResourceLocation location);
    
    // 默认纹理
    public ResourceLocation getDefaultTexture();
    public void setDefaultTexture(ResourceLocation location);
    
    // 纹理信息
    public int getTextureWidth(ResourceLocation location);
    public int getTextureHeight(ResourceLocation location);
}

// 缓存的纹理数据
class CachedTexture {
    private ResourceLocation location;
    private int width;
    private int height;
    private long lastAccessTime;
    private boolean isLoaded;
}
```

### 3. OpenGLStateManager

封装 OpenGL 状态操作，提供状态保存和恢复功能。

```java
public class OpenGLStateManager {
    private Stack<GLState> stateStack;
    
    // 状态保存和恢复
    public void pushState();
    public void popState();
    public void saveState(GLState state);
    public void restoreState(GLState state);
    
    // 混合模式
    public void enableBlend();
    public void disableBlend();
    public void setBlendMode(BlendMode mode);
    public void setBlendFunc(int srcFactor, int dstFactor);
    
    // 深度测试
    public void enableDepthTest();
    public void disableDepthTest();
    
    // 纹理
    public void enableTexture2D();
    public void disableTexture2D();
    
    // 光照
    public void enableLighting();
    public void disableLighting();
    
    // 颜色
    public void setColor(float r, float g, float b, float a);
    public void resetColor();
    
    // 矩阵变换
    public void pushMatrix();
    public void popMatrix();
    public void translate(float x, float y, float z);
    public void rotate(float angle, float x, float y, float z);
    public void scale(float x, float y, float z);
    
    // 剪裁
    public void enableScissor(int x, int y, int width, int height);
    public void disableScissor();
}

// OpenGL 状态快照
class GLState {
    boolean blendEnabled;
    int blendSrcFactor;
    int blendDstFactor;
    boolean depthTestEnabled;
    boolean texture2DEnabled;
    boolean lightingEnabled;
    float[] color;
    // ... 其他状态
}

// 预定义混合模式
enum BlendMode {
    NORMAL(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA),
    ADDITIVE(GL11.GL_SRC_ALPHA, GL11.GL_ONE),
    MULTIPLY(GL11.GL_DST_COLOR, GL11.GL_ZERO),
    SCREEN(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_COLOR);
    
    private int srcFactor;
    private int dstFactor;
    
    BlendMode(int src, int dst);
    public int getSrcFactor();
    public int getDstFactor();
}
```

### 4. RenderPipeline

管理渲染阶段的执行。

```java
public class RenderPipeline {
    private String name;
    private List<RenderStage> stages;
    private boolean enabled;
    
    public RenderPipeline(String name);
    
    // 阶段管理
    public void addStage(RenderStage stage);
    public void addStage(int index, RenderStage stage);
    public void removeStage(RenderStage stage);
    public void clearStages();
    
    // 执行管道
    public void execute(RenderContext context);
    
    // 启用/禁用
    public void setEnabled(boolean enabled);
    public boolean isEnabled();
    
    // 获取信息
    public String getName();
    public List<RenderStage> getStages();
}

// 渲染阶段接口
interface RenderStage {
    void render(RenderContext context);
    boolean shouldRender(RenderContext context);
    String getName();
}

// 渲染上下文
class RenderContext {
    private ScaledResolution resolution;
    private float partialTicks;
    private RenderGameOverlayEvent.ElementType eventType;
    private Map<String, Object> data;
    
    public ScaledResolution getResolution();
    public float getPartialTicks();
    public RenderGameOverlayEvent.ElementType getEventType();
    
    // 数据存储（用于阶段间传递数据）
    public void setData(String key, Object value);
    public Object getData(String key);
    public <T> T getData(String key, Class<T> type);
}

// 条件渲染阶段
class ConditionalRenderStage implements RenderStage {
    private RenderStage innerStage;
    private Predicate<RenderContext> condition;
    
    public ConditionalRenderStage(RenderStage stage, Predicate<RenderContext> condition);
    
    @Override
    public void render(RenderContext context);
    
    @Override
    public boolean shouldRender(RenderContext context);
}
```

### 5. RenderHelper

提供常用的渲染辅助方法。

```java
public class RenderHelper {
    // 纹理渲染
    public static void drawTexturedRect(float x, float y, float width, float height, 
                                       ResourceLocation texture);
    public static void drawTexturedRect(float x, float y, float width, float height,
                                       ResourceLocation texture, float u, float v, 
                                       float uWidth, float vHeight);
    public static void drawTexturedRectWithRotation(float x, float y, float width, float height,
                                                    ResourceLocation texture, float rotation);
    
    // 颜色渲染
    public static void drawColoredRect(float x, float y, float width, float height, int color);
    public static void drawGradientRect(float x, float y, float width, float height,
                                       int colorTop, int colorBottom);
    public static void drawGradientRectHorizontal(float x, float y, float width, float height,
                                                 int colorLeft, int colorRight);
    
    // 形状渲染
    public static void drawCircle(float x, float y, float radius, int segments, int color);
    public static void drawRing(float x, float y, float innerRadius, float outerRadius,
                               int segments, int color);
    public static void drawArc(float x, float y, float radius, float startAngle, float endAngle,
                              int segments, int color);
    
    // 边框和线条
    public static void drawBorder(float x, float y, float width, float height,
                                 float thickness, int color);
    public static void drawLine(float x1, float y1, float x2, float y2,
                               float thickness, int color);
    
    // 高级效果
    public static void drawTexturedRectWithColor(float x, float y, float width, float height,
                                                ResourceLocation texture, int color);
    public static void drawBlurredRect(float x, float y, float width, float height,
                                      int color, float blurRadius);
    
    // 颜色工具
    public static int rgba(int r, int g, int b, int a);
    public static int[] extractRGBA(int color);
    public static int interpolateColor(int color1, int color2, float ratio);
}
```

## 数据模型

### ResourceLocation

使用 Minecraft 的 `ResourceLocation` 类来标识纹理资源：

```java
// 示例
ResourceLocation lddTexture = new ResourceLocation("examplemod", "textures/gui/ldd.png");
```

### 纹理坐标系统

- 屏幕坐标：左上角为 (0, 0)
- UV 坐标：左上角为 (0, 0)，右下角为 (1, 1)
- 纹理坐标可以使用像素或归一化坐标

## 错误处理

### 错误处理策略

1. **纹理加载失败**
   - 记录警告日志
   - 返回默认纹理（Minecraft 的缺失纹理）
   - 不中断渲染流程

2. **OpenGL 错误**
   - 使用 try-catch 捕获异常
   - 记录错误堆栈
   - 恢复 OpenGL 状态
   - 在调试模式下显示错误信息

3. **渲染管道错误**
   - 捕获单个阶段的异常
   - 记录错误但继续执行后续阶段
   - 提供错误回调机制

### 日志系统

```java
public class RenderLogger {
    private static final Logger LOGGER = LogManager.getLogger("RenderingFramework");
    
    public static void info(String message);
    public static void warn(String message);
    public static void error(String message, Throwable throwable);
    public static void debug(String message);
}
```

### 异常类

```java
public class RenderException extends RuntimeException {
    public RenderException(String message);
    public RenderException(String message, Throwable cause);
}

public class TextureLoadException extends RenderException {
    private ResourceLocation location;
    public TextureLoadException(ResourceLocation location, String message);
}

public class OpenGLStateException extends RenderException {
    public OpenGLStateException(String message);
}
```

## 测试策略

### 单元测试

1. **TextureManager 测试**
   - 测试纹理加载和缓存
   - 测试无效路径处理
   - 测试缓存清理

2. **OpenGLStateManager 测试**
   - 测试状态保存和恢复
   - 测试状态栈操作
   - 测试混合模式设置

3. **RenderPipeline 测试**
   - 测试阶段添加和移除
   - 测试执行顺序
   - 测试条件渲染

### 集成测试

1. **完整渲染流程测试**
   - 创建测试渲染管道
   - 加载测试纹理
   - 验证渲染输出

2. **性能测试**
   - 测试纹理缓存性能
   - 测试渲染管道执行时间
   - 测试内存使用

### 视觉验证测试

创建专门的测试 GUI 来验证渲染效果：

```java
public class RenderingFrameworkTestGui extends GuiScreen {
    // 测试各种渲染功能
    // - 纹理渲染
    // - 颜色混合
    // - 变换效果
    // - 渲染管道
}
```

## 性能考虑

### 优化策略

1. **纹理缓存**
   - 避免重复加载相同纹理
   - 使用 LRU 缓存策略
   - 定期清理未使用的纹理

2. **状态批处理**
   - 减少 OpenGL 状态切换
   - 批量处理相同状态的渲染操作
   - 使用状态排序

3. **渲染管道优化**
   - 延迟执行不必要的阶段
   - 使用条件渲染减少开销
   - 缓存渲染结果

4. **内存管理**
   - 及时释放不再使用的资源
   - 使用对象池减少 GC 压力
   - 监控内存使用

### 性能监控

```java
public class RenderProfiler {
    private Map<String, Long> timings;
    
    public void startSection(String name);
    public void endSection(String name);
    public void printReport();
}
```

## 与现有系统集成

### 与现有渲染器集成

框架设计为与现有的渲染器（如 `HealthCardRenderer`、`HitCircleRenderer`）兼容：

1. **迁移现有渲染器**
   - 将现有渲染逻辑封装为 `RenderStage`
   - 使用 `TextureManager` 替代直接纹理操作
   - 使用 `OpenGLStateManager` 管理状态

2. **保持向后兼容**
   - 现有渲染器可以继续独立工作
   - 逐步迁移到新框架
   - 提供适配器模式支持旧代码

### 事件系统集成

```java
// 在 ExampleMod 中注册框架
@Mod.EventHandler
public void init(FMLInitializationEvent event) {
    RenderingFramework framework = RenderingFramework.getInstance();
    framework.initialize();
    MinecraftForge.EVENT_BUS.register(framework);
    
    // 注册渲染管道
    framework.registerPipeline("main", createMainPipeline(), 0);
}
```

## 扩展性设计

### 自定义渲染阶段

开发者可以轻松创建自定义渲染阶段：

```java
public class CustomEffectStage implements RenderStage {
    @Override
    public void render(RenderContext context) {
        RenderingFramework framework = RenderingFramework.getInstance();
        TextureManager textures = framework.getTextureManager();
        OpenGLStateManager gl = framework.getStateManager();
        
        // 自定义渲染逻辑
        gl.pushState();
        gl.enableBlend();
        gl.setBlendMode(BlendMode.ADDITIVE);
        
        ResourceLocation texture = textures.loadTexture("examplemod:textures/gui/ldd.png");
        textures.bindTexture(texture);
        
        RenderHelper.drawTexturedRect(100, 100, 200, 200, texture);
        
        gl.popState();
    }
    
    @Override
    public boolean shouldRender(RenderContext context) {
        return true;
    }
    
    @Override
    public String getName() {
        return "CustomEffect";
    }
}
```

### 插件系统

框架支持插件扩展：

```java
public interface RenderPlugin {
    void onFrameworkInit(RenderingFramework framework);
    void onFrameworkShutdown(RenderingFramework framework);
    String getPluginName();
    String getPluginVersion();
}

// 在 RenderingFramework 中
public void registerPlugin(RenderPlugin plugin);
public void unregisterPlugin(String pluginName);
```

## 使用示例

### 基本纹理渲染

```java
RenderingFramework framework = RenderingFramework.getInstance();
TextureManager textures = framework.getTextureManager();
OpenGLStateManager gl = framework.getStateManager();

// 加载纹理
ResourceLocation lddTexture = textures.loadTexture("examplemod:textures/gui/ldd.png");

// 渲染
gl.pushState();
gl.enableBlend();
gl.setBlendMode(BlendMode.NORMAL);

textures.bindTexture(lddTexture);
RenderHelper.drawTexturedRect(100, 100, 256, 256, lddTexture);

gl.popState();
```

### 创建自定义渲染管道

```java
RenderPipeline pipeline = new RenderPipeline("custom");

// 添加背景阶段
pipeline.addStage(new RenderStage() {
    @Override
    public void render(RenderContext context) {
        RenderHelper.drawColoredRect(0, 0, 
            context.getResolution().getScaledWidth(),
            context.getResolution().getScaledHeight(),
            0x80000000);
    }
    
    @Override
    public boolean shouldRender(RenderContext context) {
        return true;
    }
    
    @Override
    public String getName() {
        return "Background";
    }
});

// 添加纹理阶段
pipeline.addStage(new CustomEffectStage());

// 注册管道
framework.registerPipeline("custom", pipeline, 10);
```

### 高级效果示例

```java
// 旋转纹理渲染
gl.pushMatrix();
gl.translate(centerX, centerY, 0);
gl.rotate(angle, 0, 0, 1);
gl.translate(-centerX, -centerY, 0);

RenderHelper.drawTexturedRect(x, y, width, height, texture);

gl.popMatrix();

// 带颜色叠加的纹理
RenderHelper.drawTexturedRectWithColor(x, y, width, height, texture, 0xFFFF0000);

// 渐变背景
RenderHelper.drawGradientRect(0, 0, width, height, 0xFF000000, 0xFF0000FF);
```

## 配置系统

### 配置文件

```java
public class RenderConfig {
    // 纹理设置
    public static int maxCacheSize = 100;
    public static boolean enableMipmaps = true;
    
    // 性能设置
    public static boolean enableProfiling = false;
    public static boolean enableDebugMode = false;
    
    // 渲染设置
    public static boolean enableAntialiasing = true;
    public static int msaaSamples = 4;
    
    public static void load();
    public static void save();
}
```

## 调试工具

### 调试覆盖层

```java
public class RenderDebugOverlay {
    public void render(ScaledResolution resolution) {
        // 显示 FPS
        // 显示纹理缓存信息
        // 显示渲染管道状态
        // 显示 OpenGL 状态
    }
}
```

### 性能分析

```java
// 启用性能分析
RenderConfig.enableProfiling = true;

// 获取报告
RenderProfiler profiler = framework.getProfiler();
profiler.printReport();
```
