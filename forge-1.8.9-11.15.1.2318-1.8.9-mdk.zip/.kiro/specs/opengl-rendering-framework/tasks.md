# 实现计划

- [ ] 1. 创建核心框架类和基础接口
  - 创建 `RenderingFramework` 主类，实现单例模式和初始化逻辑
  - 创建 `RenderStage` 接口，定义渲染阶段的基本契约
  - 创建 `RenderContext` 类，用于在渲染阶段间传递数据
  - 创建 `RenderLogger` 工具类，提供统一的日志记录
  - 在 `ExampleMod` 中注册 `RenderingFramework` 到 Forge 事件总线
  - _需求: 1.1, 4.1, 4.4_

- [ ] 2. 实现 TextureManager 纹理管理系统
  - [ ] 2.1 实现纹理加载和缓存核心功能
    - 创建 `TextureManager` 类，实现纹理加载方法
    - 创建 `CachedTexture` 数据类，存储纹理元数据
    - 实现纹理缓存 Map，使用 `ResourceLocation` 作为键
    - 实现纹理绑定和解绑方法
    - 实现默认纹理机制，处理加载失败情况
    - _需求: 1.1, 1.2, 1.3, 1.4_

  - [ ] 2.2 实现纹理缓存管理功能
    - 实现缓存查询方法 `isTextureCached`
    - 实现缓存清理方法 `clearCache` 和 `removeFromCache`
    - 实现纹理信息查询方法（宽度、高度）
    - 添加纹理访问时间跟踪，支持 LRU 缓存策略
    - _需求: 1.3, 1.5_

  - [ ]* 2.3 添加纹理加载错误处理和日志
    - 创建 `TextureLoadException` 异常类
    - 在纹理加载失败时记录警告并返回默认纹理
    - 添加调试模式下的详细日志输出
    - _需求: 1.2, 6.1_

- [ ] 3. 实现 OpenGLStateManager 状态管理系统
  - [ ] 3.1 实现 OpenGL 状态封装和基本操作
    - 创建 `OpenGLStateManager` 类
    - 创建 `GLState` 数据类，存储 OpenGL 状态快照
    - 实现混合模式控制方法（enable/disable/setBlendFunc）
    - 实现深度测试控制方法
    - 实现纹理和光照控制方法
    - 实现颜色设置方法
    - _需求: 2.1, 2.2, 2.4_

  - [ ] 3.2 实现状态栈和保存/恢复机制
    - 创建状态栈 `Stack<GLState>`
    - 实现 `pushState` 和 `popState` 方法
    - 实现 `saveState` 和 `restoreState` 方法
    - 确保状态恢复的正确性和完整性
    - _需求: 2.3, 2.4_

  - [ ] 3.3 实现矩阵变换方法
    - 实现 `pushMatrix` 和 `popMatrix` 方法
    - 实现 `translate`、`rotate`、`scale` 方法
    - 封装 `GlStateManager` 的矩阵操作
    - _需求: 2.5_

  - [ ] 3.4 实现混合模式枚举和预设
    - 创建 `BlendMode` 枚举类
    - 定义常用混合模式（NORMAL、ADDITIVE、MULTIPLY、SCREEN）
    - 实现 `setBlendMode` 方法，应用预设混合模式
    - _需求: 2.2_

  - [ ]* 3.5 添加 OpenGL 错误处理
    - 创建 `OpenGLStateException` 异常类
    - 在状态操作中添加 try-catch 错误捕获
    - 在错误发生时恢复 OpenGL 状态
    - 记录错误日志和堆栈信息
    - _需求: 6.2, 6.4_

- [ ] 4. 实现 RenderPipeline 渲染管道系统
  - [ ] 4.1 实现渲染管道核心功能
    - 创建 `RenderPipeline` 类
    - 实现渲染阶段列表管理（add/remove/clear）
    - 实现 `execute` 方法，按顺序执行所有阶段
    - 实现启用/禁用功能
    - _需求: 3.1, 3.2, 3.4_

  - [ ] 4.2 实现条件渲染阶段
    - 创建 `ConditionalRenderStage` 类
    - 实现条件判断逻辑 `shouldRender`
    - 在管道执行时检查条件
    - _需求: 3.5_

  - [ ]* 4.3 添加渲染管道错误处理
    - 在 `execute` 方法中捕获单个阶段的异常
    - 记录错误但继续执行后续阶段
    - 在异常发生时恢复 OpenGL 状态
    - _需求: 3.3, 6.4_

- [ ] 5. 实现 RenderHelper 渲染辅助工具
  - [ ] 5.1 实现基础纹理渲染方法
    - 创建 `RenderHelper` 工具类
    - 实现 `drawTexturedRect` 方法（基础版本）
    - 实现带 UV 坐标的 `drawTexturedRect` 重载方法
    - 实现带旋转的 `drawTexturedRectWithRotation` 方法
    - 使用 `Tessellator` 和 `WorldRenderer` 进行渲染
    - _需求: 5.1, 5.2, 5.5_

  - [ ] 5.2 实现颜色和形状渲染方法
    - 实现 `drawColoredRect` 方法
    - 实现 `drawGradientRect` 方法（垂直渐变）
    - 实现 `drawGradientRectHorizontal` 方法（水平渐变）
    - 实现 `drawCircle` 和 `drawRing` 方法
    - 实现 `drawBorder` 和 `drawLine` 方法
    - _需求: 5.3_

  - [ ] 5.3 实现高级渲染效果
    - 实现 `drawTexturedRectWithColor` 方法（纹理着色）
    - 实现颜色工具方法（rgba、extractRGBA、interpolateColor）
    - 确保所有方法正确处理透明度和混合模式
    - _需求: 5.3, 5.4_

- [ ] 6. 集成框架到 Forge 事件系统
  - [ ] 6.1 实现事件监听和管道调度
    - 在 `RenderingFramework` 中实现 `onRenderGameOverlay` 事件处理器
    - 实现管道注册和注销方法（带优先级）
    - 按优先级顺序执行注册的管道
    - 创建 `RenderContext` 并传递给管道
    - _需求: 4.1, 4.2, 4.3, 4.5_

  - [ ] 6.2 实现框架初始化和注册
    - 在 `RenderingFramework` 中实现 `initialize` 方法
    - 初始化 `TextureManager` 和 `OpenGLStateManager`
    - 在 `ExampleMod.init` 中调用框架初始化
    - 注册框架到 `MinecraftForge.EVENT_BUS`
    - _需求: 4.1, 4.4_

- [ ] 7. 创建示例渲染管道和测试
  - [ ] 7.1 创建 ldd.png 纹理渲染示例
    - 创建示例渲染阶段 `LddTextureStage`
    - 使用 `TextureManager` 加载 `ldd.png` 纹理
    - 使用 `RenderHelper` 渲染纹理到屏幕
    - 应用旋转、缩放等变换效果
    - 创建示例渲染管道并注册到框架
    - _需求: 1.1, 5.1, 5.5_

  - [ ] 7.2 创建高级视觉效果示例
    - 创建渐变背景渲染阶段
    - 创建带混合模式的纹理叠加效果
    - 创建动画效果（使用时间参数）
    - 演示条件渲染功能
    - _需求: 5.3, 5.4, 3.5_

  - [ ]* 7.3 创建调试和验证工具
    - 创建 `RenderDebugOverlay` 类，显示框架状态
    - 实现调试模式切换功能
    - 添加性能分析器 `RenderProfiler`
    - 创建测试 GUI `RenderingFrameworkTestGui`
    - _需求: 6.5_

- [ ] 8. 迁移现有渲染器到新框架（可选）
  - [ ] 8.1 创建渲染器适配器
    - 创建 `LegacyRendererAdapter` 类，将现有渲染器包装为 `RenderStage`
    - 提供适配器工厂方法
    - 确保向后兼容性
    - _需求: 4.1_

  - [ ]* 8.2 迁移 HealthCardRenderer
    - 将 `HealthCardRenderer` 的渲染逻辑提取为 `RenderStage`
    - 使用 `TextureManager` 和 `OpenGLStateManager` 替代直接调用
    - 保持原有功能不变
    - _需求: 5.1, 5.3_

- [ ] 9. 文档和配置
  - [ ]* 9.1 创建配置系统
    - 创建 `RenderConfig` 类
    - 实现配置加载和保存方法
    - 添加纹理缓存大小、性能选项等配置项
    - _需求: 1.3_

  - [ ]* 9.2 添加使用文档和注释
    - 为所有公共 API 添加 Javadoc 注释
    - 创建使用示例代码
    - 添加常见问题解答
    - _需求: 所有_
