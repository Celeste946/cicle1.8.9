package com.example.examplemod;

/**
 * 动画控制器 - 管理灵动岛的动画效果
 */
public class AnimationController {
    private IslandState fromState;
    private IslandState toState;
    private long animationStartTime;
    private long animationDuration;
    private EasingFunction easingFunction;
    private boolean isAnimating;
    
    private float currentWidth;
    private float currentHeight;
    
    public AnimationController() {
        this.isAnimating = false;
        this.easingFunction = EasingFunctions.EASE_IN_OUT_BACK;
        this.animationDuration = 400;
    }
    
    /**
     * 开始状态转换动画
     */
    public void startTransition(IslandState from, IslandState to, long duration) {
        if (from == null || to == null) {
            return;
        }
        
        this.fromState = from;
        this.toState = to;
        this.animationDuration = duration;
        this.animationStartTime = System.currentTimeMillis();
        this.isAnimating = true;
        
        this.currentWidth = from.getWidth();
        this.currentHeight = from.getHeight();
    }
    
    /**
     * 更新动画状态
     */
    public void update() {
        if (!isAnimating) {
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - animationStartTime;
        
        if (elapsed >= animationDuration) {
            // 动画完成
            isAnimating = false;
            currentWidth = toState.getWidth();
            currentHeight = toState.getHeight();
        } else {
            // 计算进度
            float progress = (float) elapsed / (float) animationDuration;
            float easedProgress = easingFunction.apply(progress);
            
            // 插值计算当前尺寸
            currentWidth = lerp(fromState.getWidth(), toState.getWidth(), easedProgress);
            currentHeight = lerp(fromState.getHeight(), toState.getHeight(), easedProgress);
        }
    }
    
    /**
     * 线性插值
     */
    private float lerp(float start, float end, float t) {
        return start + (end - start) * t;
    }
    
    /**
     * 获取动画进度 (0.0 到 1.0)
     */
    public float getProgress() {
        if (!isAnimating) {
            return 1.0f;
        }
        
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - animationStartTime;
        float progress = (float) elapsed / (float) animationDuration;
        
        return Math.min(progress, 1.0f);
    }
    
    /**
     * 获取当前宽度
     */
    public float getCurrentWidth() {
        return currentWidth;
    }
    
    /**
     * 获取当前高度
     */
    public float getCurrentHeight() {
        return currentHeight;
    }
    
    /**
     * 获取当前透明度（可用于淡入淡出效果）
     */
    public float getCurrentAlpha() {
        return 1.0f; // 默认完全不透明，可以根据需要扩展
    }
    
    /**
     * 是否正在动画中
     */
    public boolean isAnimating() {
        return isAnimating;
    }
    
    /**
     * 停止动画
     */
    public void stopAnimation() {
        isAnimating = false;
        if (toState != null) {
            currentWidth = toState.getWidth();
            currentHeight = toState.getHeight();
        }
    }
    
    /**
     * 设置缓动函数
     */
    public void setEasingFunction(EasingFunction function) {
        if (function != null) {
            this.easingFunction = function;
        }
    }
    
    /**
     * 即时切换状态（无动画）
     */
    public void setStateImmediate(IslandState state) {
        if (state == null) {
            return;
        }
        
        this.fromState = state;
        this.toState = state;
        this.currentWidth = state.getWidth();
        this.currentHeight = state.getHeight();
        this.isAnimating = false;
    }
}
