package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumParticleTypes;

import java.util.ArrayList;
import java.util.List;

/**
 * 自动攻击功能模块
 * 自动攻击范围内的目标，支持可调节的攻击范围和 CPS
 */
public class AutoAttack {
    private static AutoAttack instance;
    private boolean enabled = false;
    
    // 攻击设置
    private float attackRange = 4.0f; // 默认攻击范围 4 格
    private int cps = 14; // 默认 CPS (每秒点击次数)
    private long lastAttackTime = 0;
    
    // 当前目标列表（支持多目标）
    private List<EntityLivingBase> currentTargets = new ArrayList<>();
    private int currentTargetIndex = 0;
    
    // 多目标攻击设置
    private int maxTargets = 10; // 最大同时攻击目标数
    
    // 显示受攻击白圈
    private boolean showHitCircle = true; // 默认开启
    
    // 多人模式设置
    private boolean attackPlayers = true; // 是否攻击其他玩家（默认攻击）
    
    // 平滑旋转相关
    private float rotationSpeed = 0.3f; // 旋转速度 (0.1 - 1.0, 越大越快)
    
    private AutoAttack() {
        // 私有构造函数，单例模式
    }
    
    /**
     * 获取单例实例
     */
    public static AutoAttack getInstance() {
        if (instance == null) {
            instance = new AutoAttack();
        }
        return instance;
    }
    
    /**
     * 切换自动攻击功能
     */
    public void toggle() {
        enabled = !enabled;
        if (!enabled) {
            currentTargets.clear();
            currentTargetIndex = 0;
        }
        System.out.println("[AutoAttack] 自动攻击已" + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 检查功能是否启用
     */
    public boolean isEnabled() {
        return enabled;
    }
    
    /**
     * 设置功能状态
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (!enabled) {
            currentTargets.clear();
            currentTargetIndex = 0;
        }
    }
    
    /**
     * 获取攻击范围
     */
    public float getAttackRange() {
        return attackRange;
    }
    
    /**
     * 设置攻击范围
     */
    public void setAttackRange(float range) {
        this.attackRange = Math.max(1.0f, Math.min(range, 10.0f)); // 限制在 1-10 格
    }
    
    /**
     * 获取 CPS
     */
    public int getCPS() {
        return cps;
    }
    
    /**
     * 设置 CPS
     */
    public void setCPS(int cps) {
        this.cps = Math.max(1, Math.min(cps, 20)); // 限制在 1-20
    }
    
    /**
     * 获取是否显示受攻击白圈
     */
    public boolean isShowHitCircle() {
        return showHitCircle;
    }
    
    /**
     * 设置是否显示受攻击白圈
     */
    public void setShowHitCircle(boolean showHitCircle) {
        this.showHitCircle = showHitCircle;
    }
    
    /**
     * 获取是否攻击其他玩家
     */
    public boolean isAttackPlayers() {
        return attackPlayers;
    }
    
    /**
     * 设置是否攻击其他玩家
     */
    public void setAttackPlayers(boolean attackPlayers) {
        this.attackPlayers = attackPlayers;
    }
    
    /**
     * 每个 tick 应用自动攻击逻辑（支持多目标）
     */
    public void onPlayerTick(EntityPlayerSP player) {
        if (player == null) return;
        
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.isGamePaused() || mc.currentScreen != null) {
            return;
        }
        
        // 查找范围内的所有目标
        currentTargets = findTargetsInRange(player);
        
        if (!currentTargets.isEmpty()) {
            // 获取当前要攻击的目标（轮流攻击）
            EntityLivingBase target = currentTargets.get(currentTargetIndex % currentTargets.size());
            
            if (target != null && target.isEntityAlive()) {
                // 让玩家朝向当前目标
                faceEntity(player, target);
                
                // 检查是否可以攻击（基于 CPS）
                long currentTime = System.currentTimeMillis();
                long attackInterval = 1000 / cps; // 计算攻击间隔
                
                if (currentTime - lastAttackTime >= attackInterval) {
                    // 执行攻击
                    attackEntity(player, target);
                    lastAttackTime = currentTime;
                    
                    // 切换到下一个目标
                    currentTargetIndex++;
                    if (currentTargetIndex >= currentTargets.size()) {
                        currentTargetIndex = 0;
                    }
                }
            }
        } else {
            // 没有目标时，重置索引
            currentTargetIndex = 0;
        }
    }
    

    
    /**
     * 查找范围内的所有可攻击目标（支持多目标）
     */
    private List<EntityLivingBase> findTargetsInRange(EntityPlayerSP player) {
        List<Entity> entities = player.worldObj.loadedEntityList;
        List<EntityLivingBase> targets = new ArrayList<>();
        
        for (Entity entity : entities) {
            // 只攻击生物实体
            if (!(entity instanceof EntityLivingBase)) continue;
            if (entity == player) continue;
            if (!entity.isEntityAlive()) continue;
            
            EntityLivingBase living = (EntityLivingBase) entity;
            
            // 根据设置决定是否跳过其他玩家
            if (living instanceof EntityPlayer && !attackPlayers) continue;
            
            // 计算距离
            double distance = player.getDistanceToEntity(living);
            
            if (distance <= attackRange) {
                targets.add(living);
            }
            
            // 限制最大目标数
            if (targets.size() >= maxTargets) {
                break;
            }
        }
        
        // 按距离排序（最近的优先）
        targets.sort((a, b) -> {
            double distA = player.getDistanceToEntity(a);
            double distB = player.getDistanceToEntity(b);
            return Double.compare(distA, distB);
        });
        
        return targets;
    }
    
    /**
     * 让玩家身体朝向目标实体（平滑旋转，不改变视角）
     */
    private void faceEntity(EntityPlayerSP player, EntityLivingBase target) {
        // 计算目标位置（预测目标移动）
        double deltaX = target.posX - player.posX;
        double deltaZ = target.posZ - player.posZ;
        
        // 计算目标朝向的 yaw（只改变水平方向）
        float newTargetYaw = (float) (Math.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0f;
        
        // 获取当前身体朝向
        float currentYaw = player.renderYawOffset;
        
        // 计算到新目标的角度差
        float yawDiff = newTargetYaw - currentYaw;
        
        // 标准化角度差到 -180 到 180 范围
        while (yawDiff > 180.0f) yawDiff -= 360.0f;
        while (yawDiff < -180.0f) yawDiff += 360.0f;
        
        // 平滑插值到目标角度
        float smoothYaw = currentYaw + yawDiff * rotationSpeed;
        
        // 标准化最终角度
        while (smoothYaw > 180.0f) smoothYaw -= 360.0f;
        while (smoothYaw < -180.0f) smoothYaw += 360.0f;
        
        // 应用平滑后的朝向
        // renderYawOffset 控制身体朝向
        // rotationYawHead 控制头部朝向
        player.renderYawOffset = smoothYaw;
        player.rotationYawHead = smoothYaw;
        
        // 同时更新 prevRotationYaw 以保持平滑
        player.prevRotationYaw = player.rotationYaw;
        player.prevRotationPitch = player.rotationPitch;
        
        // 不修改 player.rotationYaw 和 player.rotationPitch，保持玩家视角不变
    }
    
    /**
     * 获取旋转速度
     */
    public float getRotationSpeed() {
        return rotationSpeed;
    }
    
    /**
     * 设置旋转速度
     */
    public void setRotationSpeed(float speed) {
        this.rotationSpeed = Math.max(0.1f, Math.min(speed, 1.0f));
    }
    
    /**
     * 攻击目标实体（带流畅动画和粒子效果）
     */
    private void attackEntity(EntityPlayerSP player, EntityLivingBase target) {
        Minecraft mc = Minecraft.getMinecraft();
        
        // 执行攻击
        mc.playerController.attackEntity(player, target);
        
        // 只在没有挥手动画进行时才触发新动画，避免打断
        if (!player.isSwingInProgress) {
            player.swingItem();
        }
        
        // 添加明显的粒子效果
        spawnAttackParticles(target);
        
        // 记录受攻击实体，显示白圈
        HitCircleRenderer.getInstance().onEntityHit(target);
    }
    
    /**
     * 在目标周围生成旋转的女巫魔法粒子效果
     */
    private void spawnAttackParticles(EntityLivingBase target) {
        if (target == null || target.worldObj == null) return;
        
        double centerX = target.posX;
        double centerY = target.posY + target.height / 2.0; // 目标中心高度
        double centerZ = target.posZ;
        
        double radius = 0.7; // 旋转半径
        
        // 使用时间创建旋转效果
        long time = System.currentTimeMillis();
        double rotationSpeed = 0.008; // 旋转速度
        double baseAngle = time * rotationSpeed;
        
        // 创建两层旋转的女巫魔法粒子（紫色螺旋）
        for (int layer = 0; layer < 2; layer++) {
            double layerHeight = centerY + (layer - 0.5) * 0.5; // 两层：中下、中上
            double layerRadius = radius;
            
            // 每层 6 个粒子，总共 12 个
            for (int i = 0; i < 6; i++) {
                // 计算旋转角度，两层反向旋转
                double angle = baseAngle * (layer == 0 ? 1 : -1) + (i * 2 * Math.PI / 6);
                
                // 计算粒子位置（圆形轨迹）
                double particleX = centerX + Math.cos(angle) * layerRadius;
                double particleZ = centerZ + Math.sin(angle) * layerRadius;
                
                // 计算切线方向的速度（使粒子沿圆周运动）
                double velocityX = -Math.sin(angle) * 0.03 * (layer == 0 ? 1 : -1);
                double velocityZ = Math.cos(angle) * 0.03 * (layer == 0 ? 1 : -1);
                
                // 生成女巫魔法粒子（紫色）
                target.worldObj.spawnParticle(EnumParticleTypes.SPELL_WITCH, 
                    particleX, layerHeight, particleZ, 
                    velocityX, 0, velocityZ);
            }
        }
        
        // 添加少量向上螺旋的魔法粒子（5个）
        for (int i = 0; i < 5; i++) {
            double angle = baseAngle + (i * 2 * Math.PI / 5);
            double spiralRadius = radius * 0.6;
            double particleX = centerX + Math.cos(angle) * spiralRadius;
            double particleZ = centerZ + Math.sin(angle) * spiralRadius;
            double particleY = target.posY + (i * target.height / 5);
            
            target.worldObj.spawnParticle(EnumParticleTypes.SPELL_WITCH, 
                particleX, particleY, particleZ, 
                0, 0.03, 0);
        }
    }
}
