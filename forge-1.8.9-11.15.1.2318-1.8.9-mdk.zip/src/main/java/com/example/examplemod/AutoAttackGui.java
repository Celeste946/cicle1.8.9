package com.example.examplemod;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ChatComponentText;
import java.awt.Color;
import java.io.IOException;

/**
 * 自动攻击设置界面
 */
public class AutoAttackGui extends GuiScreen {
    private GuiSlider rangeSlider;
    private GuiSlider cpsSlider;
    private GuiSlider rotationSpeedSlider;
    private GuiTextureButton toggleButton;
    private GuiTextureButton backButton;
    private GuiIconButton hitCircleButton;
    private GuiIconButton attackPlayersButton;
    
    private static final int BACKGROUND_ALPHA = 200;
    
    @Override
    public void initGui() {
        super.initGui();
        
        int centerX = width / 2;
        int startY = height / 4;
        
        // 创建滑块
        rangeSlider = new GuiSlider("攻击范围", AutoAttack.getInstance().getAttackRange(), 1.0f, 10.0f);
        cpsSlider = new GuiSlider("CPS", AutoAttack.getInstance().getCPS(), 1.0f, 20.0f);
        rotationSpeedSlider = new GuiSlider("旋转速度", AutoAttack.getInstance().getRotationSpeed(), 0.1f, 1.0f);
        
        // 创建按钮（使用自定义纹理）
        toggleButton = new GuiTextureButton(0, centerX - 75, startY + 105, 150, 20, 
            AutoAttack.getInstance().isEnabled() ? "禁用自动攻击" : "启用自动攻击");
        
        // 创建显示白圈的图标按钮
        hitCircleButton = new GuiIconButton(2, centerX - 75, startY + 130, 150, 20, 
            "显示受攻击白圈", AutoAttack.getInstance().isShowHitCircle());
        
        // 创建攻击玩家的图标按钮
        attackPlayersButton = new GuiIconButton(3, centerX - 75, startY + 155, 150, 20, 
            "攻击其他玩家", AutoAttack.getInstance().isAttackPlayers());
        
        backButton = new GuiTextureButton(1, centerX - 75, startY + 180, 150, 20, "返回");
        
        buttonList.add(toggleButton);
        buttonList.add(hitCircleButton);
        buttonList.add(attackPlayersButton);
        buttonList.add(backButton);
    }
    
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int centerX = width / 2;
        int startY = height / 4;
        int panelWidth = 200;
        int panelHeight = 235;
        int cornerRadius = 8; // 圆角半径
        
        // 绘制简单的半透明背景
        drawRect(0, 0, width, height, new Color(0, 0, 0, 120).getRGB());
        
        // 绘制圆角阴影
        GuiShaderEffects.drawRoundedShadow(centerX - panelWidth / 2, startY - 20, 
                panelWidth, panelHeight, cornerRadius, 0x60000000);
        
        // 绘制圆角面板背景
        GuiShaderEffects.drawRoundedRect(centerX - panelWidth / 2, startY - 20, 
                panelWidth, panelHeight, cornerRadius, new Color(30, 30, 35, BACKGROUND_ALPHA).getRGB());
        
        // 绘制标题
        String title = "§l自动攻击设置";
        drawCenteredString(fontRendererObj, title, centerX, startY - 10, 0xFFFFFF);
        
        // 绘制滑块
        rangeSlider.draw(this, centerX - 90, startY + 10, 180, mouseX, mouseY);
        cpsSlider.draw(this, centerX - 90, startY + 35, 180, mouseX, mouseY);
        rotationSpeedSlider.draw(this, centerX - 90, startY + 60, 180, mouseX, mouseY);
        
        // 绘制状态信息（带脉冲效果）
        String status = "状态: " + (AutoAttack.getInstance().isEnabled() ? "§a启用" : "§c禁用");
        drawCenteredString(fontRendererObj, status, centerX, startY + 85, 0xFFFFFF);
        
        // 绘制脉冲效果（如果启用）
        if (AutoAttack.getInstance().isEnabled()) {
            long time = System.currentTimeMillis();
            GuiShaderEffects.drawPulseEffect(centerX - 30, startY + 83, 60, 10, 0x4000FF00, time);
        }
        
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
    
    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        
        int centerX = width / 2;
        int startY = height / 4;
        
        // 处理滑块点击
        rangeSlider.mouseClicked(centerX - 90, startY + 10, 180, mouseX, mouseY);
        cpsSlider.mouseClicked(centerX - 90, startY + 35, 180, mouseX, mouseY);
        rotationSpeedSlider.mouseClicked(centerX - 90, startY + 60, 180, mouseX, mouseY);
    }
    
    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        
        // 更新设置
        if (rangeSlider.isDragging()) {
            AutoAttack.getInstance().setAttackRange(rangeSlider.getCurrentValue());
        }
        if (cpsSlider.isDragging()) {
            AutoAttack.getInstance().setCPS((int) cpsSlider.getCurrentValue());
        }
        if (rotationSpeedSlider.isDragging()) {
            AutoAttack.getInstance().setRotationSpeed(rotationSpeedSlider.getCurrentValue());
        }
        
        rangeSlider.mouseReleased();
        cpsSlider.mouseReleased();
        rotationSpeedSlider.mouseReleased();
    }
    
    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
        
        int centerX = width / 2;
        
        // 处理滑块拖动
        rangeSlider.mouseDragged(centerX - 90, 180, mouseX);
        cpsSlider.mouseDragged(centerX - 90, 180, mouseX);
        rotationSpeedSlider.mouseDragged(centerX - 90, 180, mouseX);
        
        // 实时更新设置
        AutoAttack.getInstance().setAttackRange(rangeSlider.getCurrentValue());
        AutoAttack.getInstance().setCPS((int) cpsSlider.getCurrentValue());
        AutoAttack.getInstance().setRotationSpeed(rotationSpeedSlider.getCurrentValue());
    }
    
    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 0) {
            // 切换自动攻击
            AutoAttack.getInstance().toggle();
            button.displayString = AutoAttack.getInstance().isEnabled() ? "禁用自动攻击" : "启用自动攻击";
            
            if (mc.thePlayer != null) {
                String status = AutoAttack.getInstance().isEnabled() ? "已启用" : "已禁用";
                mc.thePlayer.addChatMessage(new ChatComponentText("§a自动攻击 " + status));
            }
        } else if (button.id == 1) {
            // 返回主界面
            mc.displayGuiScreen(new ExampleGui());
        } else if (button.id == 2) {
            // 切换显示受攻击白圈
            hitCircleButton.toggle();
            AutoAttack.getInstance().setShowHitCircle(hitCircleButton.getState());
            
            if (mc.thePlayer != null) {
                String status = hitCircleButton.getState() ? "已启用" : "已禁用";
                mc.thePlayer.addChatMessage(new ChatComponentText("§a显示受攻击白圈 " + status));
            }
        } else if (button.id == 3) {
            // 切换攻击其他玩家
            attackPlayersButton.toggle();
            AutoAttack.getInstance().setAttackPlayers(attackPlayersButton.getState());
            
            if (mc.thePlayer != null) {
                String status = attackPlayersButton.getState() ? "已启用" : "已禁用";
                mc.thePlayer.addChatMessage(new ChatComponentText("§a攻击其他玩家 " + status));
            }
        }
    }
    
    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
