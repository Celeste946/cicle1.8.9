package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

/**
 * 自动疾跑功能模块
 * 自动让玩家保持疾跑状态
 */
public class AutoSprint {
    private static AutoSprint instance;
    private boolean enabled = false;
    
    private AutoSprint() {
        // 私有构造函数，单例模式
    }
    
    /**
     * 获取单例实例
     */
    public static AutoSprint getInstance() {
        if (instance == null) {
            instance = new AutoSprint();
        }
        return instance;
    }
    
    /**
     * 切换自动疾跑功能
     */
    public void toggle() {
        enabled = !enabled;
        System.out.println("[AutoSprint] 自动疾跑已" + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 检查功能是否启用
     */
    public boolean isEnabled() {
        return enabled;
    }
    
    /**
     * 设置功能状态
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    /**
     * 每个 tick 应用自动疾跑逻辑
     */
    public void onPlayerTick(EntityPlayerSP player) {
        if (player == null) return;
        
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.isGamePaused() || mc.currentScreen != null) {
            return;
        }
        
        // 检查玩家是否在移动
        boolean isMoving = player.moveForward != 0 || player.moveStrafing != 0;
        
        // 如果玩家在移动且不在潜行，自动设置疾跑状态
        if (isMoving && !player.isSneaking()) {
            player.setSprinting(true);
        }
    }
}
