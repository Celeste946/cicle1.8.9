package com.example.examplemod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 内容管理器 - 管理灵动岛中显示的内容
 */
public class ContentManager {
    private List<IslandContent> contents;
    private PlayerInfoProvider infoProvider;
    
    public ContentManager() {
        this.contents = new ArrayList<>();
        this.infoProvider = new PlayerInfoProvider();
    }
    
    /**
     * 添加内容
     */
    public void addContent(IslandContent content) {
        if (content != null && !contents.contains(content)) {
            contents.add(content);
            sortContents();
        }
    }
    
    /**
     * 移除内容
     */
    public void removeContent(IslandContent content) {
        contents.remove(content);
    }
    
    /**
     * 清空所有内容
     */
    public void clearContents() {
        contents.clear();
    }
    
    /**
     * 获取所有内容
     */
    public List<IslandContent> getContents() {
        return contents;
    }
    
    /**
     * 更新内容
     */
    public void updateContents() {
        // 更新所有动态内容
        // 这里可以添加定期更新逻辑
    }
    
    /**
     * 计算内容布局
     */
    public void layoutContents(float availableWidth, float availableHeight) {
        // 根据可用空间布局内容
        // 这里可以实现更复杂的布局算法
    }
    
    /**
     * 根据优先级排序内容
     */
    private void sortContents() {
        contents.sort(Comparator.comparingInt(IslandContent::getPriority));
    }
    
    /**
     * 获取信息提供者
     */
    public PlayerInfoProvider getInfoProvider() {
        return infoProvider;
    }
}
