package com.example.examplemod;

import net.minecraft.client.Minecraft;

import java.awt.*;
import java.io.InputStream;

/**
 * 优化的字体渲染系统
 * 使用异步加载避免白屏问题
 */
public class CustomFont {
    private static CustomFont instance;
    private Font customFont;
    private boolean isLoaded = false;
    private boolean isLoading = false;
    
    private static final String FONT_PATH = "/assets/examplemod/textures/font/sfregular.ttf";
    private static final float DEFAULT_FONT_SIZE = 18.0f;
    
    private CustomFont() {
        // 私有构造函数，单例模式
    }
    
    public static CustomFont getInstance() {
        if (instance == null) {
            instance = new CustomFont();
        }
        return instance;
    }
    
    /**
     * 异步加载字体
     */
    public void loadFontAsync() {
        if (isLoaded || isLoading) return;
        
        isLoading = true;
        
        // 在新线程中加载字体，避免阻塞主线程
        new Thread(() -> {
            try {
                InputStream fontStream = CustomFont.class.getResourceAsStream(FONT_PATH);
                if (fontStream != null) {
                    Font baseFont = Font.createFont(Font.TRUETYPE_FONT, fontStream);
                    customFont = baseFont.deriveFont(DEFAULT_FONT_SIZE);
                    isLoaded = true;
                    System.out.println("[CustomFont] 自定义字体加载成功");
                } else {
                    System.err.println("[CustomFont] 找不到字体文件: " + FONT_PATH);
                }
            } catch (Exception e) {
                System.err.println("[CustomFont] 字体加载失败: " + e.getMessage());
            } finally {
                isLoading = false;
            }
        }, "FontLoader").start();
    }
    
    /**
     * 检查字体是否已加载
     */
    public boolean isLoaded() {
        return isLoaded;
    }
    
    /**
     * 获取自定义字体
     */
    public Font getCustomFont() {
        return customFont;
    }
    
    /**
     * 获取指定大小的字体
     */
    public Font getCustomFont(float size) {
        if (customFont != null) {
            return customFont.deriveFont(size);
        }
        return null;
    }
    
    /**
     * 绘制字符串（使用自定义字体或回退到默认字体）
     */
    public void drawString(String text, int x, int y, int color) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.fontRendererObj != null) {
            mc.fontRendererObj.drawString(text, x, y, color);
        }
    }
    
    /**
     * 绘制带阴影的字符串
     */
    public void drawStringWithShadow(String text, float x, float y, int color) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.fontRendererObj != null) {
            mc.fontRendererObj.drawStringWithShadow(text, x, y, color);
        }
    }
    
    /**
     * 获取字符串宽度
     */
    public int getStringWidth(String text) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.fontRendererObj != null) {
            return mc.fontRendererObj.getStringWidth(text);
        }
        return 0;
    }
    
    /**
     * 获取字体高度
     */
    public int getFontHeight() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.fontRendererObj != null) {
            return mc.fontRendererObj.FONT_HEIGHT;
        }
        return 9;
    }
}
