package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;

/**
 * 自定义字体渲染器 - 适用于 Minecraft 1.8.9
 * 使用自定义字体纹理进行渲染
 */
public class CustomFontRenderer extends FontRenderer {
    private static final ResourceLocation CUSTOM_FONT_TEXTURE = new ResourceLocation("examplemod", "textures/font/custom_font.png");
    private final TextureManager textureManager;
    private boolean useCustomFont = true;

    public CustomFontRenderer(Minecraft mc, IResourceManager resourceManager) {
        super(mc.gameSettings, new ResourceLocation("textures/font/ascii.png"), mc.getTextureManager(), false);
        this.textureManager = mc.getTextureManager();
        
        // 尝试加载自定义字体纹理
        try {
            resourceManager.getResource(CUSTOM_FONT_TEXTURE);
            this.useCustomFont = true;
        } catch (Exception e) {
            System.out.println("[CustomFont] 自定义字体纹理未找到，使用默认字体");
            this.useCustomFont = false;
        }
        
        // 重新加载字形数据
        this.onResourceManagerReload(resourceManager);
    }

    @Override
    protected void bindTexture(ResourceLocation location) {
        if (useCustomFont && location.getResourcePath().contains("custom_font.png")) {
            // 使用自定义字体纹理替换默认字体
            textureManager.bindTexture(CUSTOM_FONT_TEXTURE);
        } else {
            textureManager.bindTexture(location);
        }
    }

    /**
     * 绘制带阴影的字符串（使用自定义字体）
     */
    @Override
    public int drawStringWithShadow(String text, float x, float y, int color) {
        if (useCustomFont) {
            return super.drawStringWithShadow(text, x, y, color);
        } else {
            // 回退到默认渲染
            return super.drawStringWithShadow(text, x, y, color);
        }
    }

    /**
     * 绘制字符串（使用自定义字体）
     */
    @Override
    public int drawString(String text, int x, int y, int color) {
        if (useCustomFont) {
            return super.drawString(text, x, y, color);
        } else {
            return super.drawString(text, x, y, color);
        }
    }

    /**
     * 检查是否成功加载自定义字体
     */
    public boolean isCustomFontLoaded() {
        return useCustomFont;
    }
}
