package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * 自定义挥砍动画
 * 修改第一人称视角的物品挥动动画
 */
public class CustomSwingAnimation {
    private static CustomSwingAnimation instance;
    private boolean enabled = true; // 默认启用自定义动画
    
    private CustomSwingAnimation() {
        // 私有构造函数，单例模式
    }
    
    public static CustomSwingAnimation getInstance() {
        if (instance == null) {
            instance = new CustomSwingAnimation();
        }
        return instance;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    /**
     * 拦截手部渲染事件，应用自定义动画
     */
    @SubscribeEvent
    public void onRenderHand(RenderHandEvent event) {
        // 检查 GUI 状态 - 如果 GUI 打开，立即返回不执行任何变换
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen != null) {
            return;
        }
        
        if (!enabled) return;
        
        if (mc.thePlayer == null) return;
        
        // 检查是否在挥动物品
        if (mc.thePlayer.isSwingInProgress) {
            // 应用自定义动画变换
            applyCustomSwingTransform(mc.thePlayer.getSwingProgress(event.partialTicks));
        }
    }

    
    /**
     * 应用自定义挥砍变换
     */
    private void applyCustomSwingTransform(float swingProgress) {
        // 使用平滑的动画曲线
        float smoothProgress = MathHelper.sin(swingProgress * (float) Math.PI);
        float smoothProgress2 = MathHelper.sin(MathHelper.sqrt_float(swingProgress) * (float) Math.PI);
        
        // 自定义动画：流畅的斜向下挥砍
        // 1. 旋转动画（从右上到左下的弧形挥砍）
        GlStateManager.rotate(-smoothProgress * 50.0f, 1.0f, 0.0f, 0.0f); // X轴旋转（向下）
        GlStateManager.rotate(-smoothProgress2 * 40.0f, 0.0f, 1.0f, 0.0f); // Y轴旋转（向左）
        GlStateManager.rotate(smoothProgress2 * 25.0f, 0.0f, 0.0f, 1.0f);  // Z轴旋转（倾斜）
        
        // 2. 位移动画（向前推进并下压）
        GlStateManager.translate(
            smoothProgress2 * 0.4f,      // 向右移动
            -smoothProgress * 0.3f,       // 向下移动
            -smoothProgress2 * 0.2f       // 向前移动
        );
        
        // 3. 缩放动画（攻击时略微放大，增强冲击感）
        float scale = 1.0f + smoothProgress * 0.15f;
        GlStateManager.scale(scale, scale, scale);
    }
}
