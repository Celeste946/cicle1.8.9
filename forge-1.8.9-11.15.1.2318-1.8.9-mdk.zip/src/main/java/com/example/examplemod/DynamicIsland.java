package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * 灵动岛主类 - 类似苹果灵动岛的 HUD 元素
 * 固定显示在屏幕顶部中央，支持动画和多种显示状态
 */
public class DynamicIsland {
    private static DynamicIsland instance;
    
    private IslandRenderer renderer;
    private AnimationController animationController;
    private ContentManager contentManager;
    private IslandConfig config;
    private IslandDebugOverlay debugOverlay;
    
    private IslandState currentState;
    private boolean enabled;
    private boolean initialized;
    
    /**
     * 私有构造函数，单例模式
     */
    private DynamicIsland() {
        this.config = new IslandConfig();
        this.currentState = IslandState.EXPANDED; // 默认展开状态
        this.enabled = true;
        this.initialized = false;
    }
    
    /**
     * 获取单例实例
     */
    public static DynamicIsland getInstance() {
        if (instance == null) {
            instance = new DynamicIsland();
        }
        return instance;
    }
    
    /**
     * 初始化灵动岛系统
     */
    public void initialize() {
        if (initialized) {
            System.out.println("[DynamicIsland] 已经初始化，跳过");
            return;
        }
        
        System.out.println("[DynamicIsland] 开始初始化...");
        
        try {
            // 加载配置
            config.load();
            
            // 初始化子系统
            this.renderer = new IslandRenderer(config);
            this.animationController = new AnimationController();
            this.contentManager = new ContentManager();
            this.debugOverlay = new IslandDebugOverlay(this);
            
            // 设置渲染器的动画控制器
            renderer.setAnimationController(animationController);
            
            // 加载纹理
            renderer.loadTextures();
            
            // 设置初始状态
            animationController.setStateImmediate(currentState);
            
            this.enabled = config.isEnabled();
            this.initialized = true;
            
            System.out.println("[DynamicIsland] 初始化完成");
        } catch (Exception e) {
            System.err.println("[DynamicIsland] 初始化失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 设置显示状态
     */
    public void setState(IslandState state) {
        if (state == null || state == currentState) {
            return;
        }
        
        IslandState oldState = currentState;
        currentState = state;
        
        if (animationController != null) {
            animationController.startTransition(oldState, state, config.getTransitionDuration());
        }
    }
    
    /**
     * 获取当前状态
     */
    public IslandState getState() {
        return currentState;
    }
    
    /**
     * 切换状态（循环）
     */
    public void toggleState() {
        IslandState[] states = IslandState.values();
        int currentIndex = currentState.ordinal();
        int nextIndex = (currentIndex + 1) % states.length;
        setState(states[nextIndex]);
    }
    
    /**
     * 添加内容
     */
    public void addContent(IslandContent content) {
        if (contentManager != null) {
            contentManager.addContent(content);
        }
    }
    
    /**
     * 清空内容
     */
    public void clearContent() {
        if (contentManager != null) {
            contentManager.clearContents();
        }
    }
    
    /**
     * 设置启用状态
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        config.setEnabled(enabled);
    }
    
    /**
     * 获取启用状态
     */
    public boolean isEnabled() {
        return enabled;
    }
    
    /**
     * 切换启用/禁用
     */
    public void toggle() {
        setEnabled(!enabled);
    }
    
    /**
     * 获取配置
     */
    public IslandConfig getConfig() {
        return config;
    }
    
    /**
     * 获取内容管理器
     */
    public ContentManager getContentManager() {
        return contentManager;
    }
    
    /**
     * 更新动画和内容
     */
    public void update() {
        if (!initialized || !enabled) {
            return;
        }
        
        try {
            // 更新动画
            if (animationController != null) {
                animationController.update();
            }
            
            // 更新内容
            if (contentManager != null) {
                contentManager.updateContents();
            }
        } catch (Exception e) {
            System.err.println("[DynamicIsland] 更新失败: " + e.getMessage());
        }
    }
    
    /**
     * 渲染灵动岛
     */
    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Post event) {
        // 检查是否初始化和启用
        if (!initialized || !enabled) {
            return;
        }
        
        // 只在 ALL 类型时渲染
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }
        
        Minecraft mc = Minecraft.getMinecraft();
        
        // 检查游戏状态
        if (mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
        
        // 打开 GUI 时不渲染
        if (mc.currentScreen != null) {
            return;
        }
        
        try {
            // 更新
            update();
            
            // 渲染
            if (renderer != null && contentManager != null) {
                renderer.render(
                    event.resolution,
                    currentState,
                    contentManager.getContents(),
                    animationController != null ? animationController.getProgress() : 1.0f
                );
            }
            
            // 渲染调试覆盖层
            if (debugOverlay != null && config.isDebugMode()) {
                debugOverlay.render(event.resolution);
            }
        } catch (Exception e) {
            System.err.println("[DynamicIsland] 渲染失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
