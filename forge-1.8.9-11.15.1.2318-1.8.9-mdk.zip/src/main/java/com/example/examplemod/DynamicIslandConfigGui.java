package com.example.examplemod;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

/**
 * 灵动岛配置 GUI
 */
public class DynamicIslandConfigGui extends GuiScreen {
    private DynamicIsland island;
    private IslandConfig config;
    
    private GuiButton shadowButton;
    private GuiButton glowButton;
    private GuiButton coordsButton;
    private GuiButton healthButton;
    private GuiButton timeButton;
    private GuiButton targetButton;
    
    private GuiButton compactButton;
    private GuiButton standardButton;
    private GuiButton expandedButton;
    
    private GuiButton saveButton;
    private GuiButton cancelButton;
    
    public DynamicIslandConfigGui() {
        this.island = DynamicIsland.getInstance();
        this.config = island.getConfig();
    }
    
    @Override
    public void initGui() {
        int centerX = width / 2;
        int startY = 60;
        int spacing = 25;
        
        // 效果开关
        shadowButton = new GuiButton(10, centerX - 150, startY, 145, 20,
            "阴影: " + (config.isEnableShadow() ? "开" : "关"));
        
        glowButton = new GuiButton(11, centerX + 5, startY, 145, 20,
            "发光: " + (config.isEnableGlow() ? "开" : "关"));
        
        // 内容开关
        int contentY = startY + spacing;
        coordsButton = new GuiButton(12, centerX - 150, contentY, 70, 20,
            "坐标: " + (config.isShowCoordinates() ? "开" : "关"));
        
        healthButton = new GuiButton(13, centerX - 75, contentY, 70, 20,
            "生命: " + (config.isShowHealth() ? "开" : "关"));
        
        timeButton = new GuiButton(14, centerX, contentY, 70, 20,
            "时间: " + (config.isShowTime() ? "开" : "关"));
        
        targetButton = new GuiButton(15, centerX + 75, contentY, 70, 20,
            "目标: " + (config.isShowTarget() ? "开" : "关"));
        
        // 状态按钮
        int stateY = contentY + spacing + 10;
        compactButton = new GuiButton(20, centerX - 150, stateY, 95, 20, "收缩");
        standardButton = new GuiButton(21, centerX - 50, stateY, 95, 20, "标准");
        expandedButton = new GuiButton(22, centerX + 50, stateY, 95, 20, "展开");
        
        // 保存和取消按钮
        int bottomY = height - 30;
        saveButton = new GuiButton(30, centerX - 100, bottomY, 95, 20, "保存");
        cancelButton = new GuiButton(31, centerX + 5, bottomY, 95, 20, "取消");
        
        // 添加所有按钮
        buttonList.add(shadowButton);
        buttonList.add(glowButton);
        buttonList.add(coordsButton);
        buttonList.add(healthButton);
        buttonList.add(timeButton);
        buttonList.add(targetButton);
        buttonList.add(compactButton);
        buttonList.add(standardButton);
        buttonList.add(expandedButton);
        buttonList.add(saveButton);
        buttonList.add(cancelButton);
    }
    
    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 10: // 阴影
                config.setEnableShadow(!config.isEnableShadow());
                button.displayString = "阴影: " + (config.isEnableShadow() ? "开" : "关");
                break;
            case 11: // 发光
                config.setEnableGlow(!config.isEnableGlow());
                button.displayString = "发光: " + (config.isEnableGlow() ? "开" : "关");
                break;
            case 12: // 坐标
                config.setShowCoordinates(!config.isShowCoordinates());
                button.displayString = "坐标: " + (config.isShowCoordinates() ? "开" : "关");
                break;
            case 13: // 生命
                config.setShowHealth(!config.isShowHealth());
                button.displayString = "生命: " + (config.isShowHealth() ? "开" : "关");
                break;
            case 14: // 时间
                config.setShowTime(!config.isShowTime());
                button.displayString = "时间: " + (config.isShowTime() ? "开" : "关");
                break;
            case 15: // 目标
                config.setShowTarget(!config.isShowTarget());
                button.displayString = "目标: " + (config.isShowTarget() ? "开" : "关");
                break;
            case 20: // 收缩
                island.setState(IslandState.COMPACT);
                break;
            case 21: // 标准
                island.setState(IslandState.STANDARD);
                break;
            case 22: // 展开
                island.setState(IslandState.EXPANDED);
                break;
            case 30: // 保存
                config.save();
                mc.displayGuiScreen(null);
                break;
            case 31: // 取消
                mc.displayGuiScreen(null);
                break;
        }
    }
    
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        
        // 标题
        drawCenteredString(fontRendererObj, "灵动岛配置", width / 2, 20, 0xFFFFFF);
        
        // 说明文字
        drawCenteredString(fontRendererObj, "按 I 键切换状态 | 按 O 键打开配置", width / 2, 35, 0xAAAAAA);
        
        // 绘制按钮
        super.drawScreen(mouseX, mouseY, partialTicks);
        
        // 当前状态
        String stateText = "当前状态: " + island.getState().name();
        drawCenteredString(fontRendererObj, stateText, width / 2, height - 50, 0xAAAAAA);
    }
    
    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
