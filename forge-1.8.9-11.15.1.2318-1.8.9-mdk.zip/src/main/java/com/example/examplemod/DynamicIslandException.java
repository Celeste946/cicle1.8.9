package com.example.examplemod;

/**
 * 灵动岛系统的基础异常类
 */
public class DynamicIslandException extends RuntimeException {
    public DynamicIslandException(String message) {
        super(message);
    }
    
    public DynamicIslandException(String message, Throwable cause) {
        super(message, cause);
    }
}
