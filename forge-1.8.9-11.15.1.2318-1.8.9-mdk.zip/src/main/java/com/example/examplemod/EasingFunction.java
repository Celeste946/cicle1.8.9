package com.example.examplemod;

/**
 * 缓动函数接口
 * 用于动画插值计算
 */
public interface EasingFunction {
    /**
     * 应用缓动函数
     * @param t 时间进度 (0.0 到 1.0)
     * @return 缓动后的值 (通常也是 0.0 到 1.0)
     */
    float apply(float t);
}
