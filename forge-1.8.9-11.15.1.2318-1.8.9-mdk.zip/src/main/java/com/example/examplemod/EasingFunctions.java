package com.example.examplemod;

/**
 * 预定义的缓动函数集合
 * 提供多种动画插值效果
 */
public class EasingFunctions {
    
    /**
     * 线性缓动 - 匀速运动
     */
    public static final EasingFunction LINEAR = new EasingFunction() {
        @Override
        public float apply(float t) {
            return t;
        }
    };
    
    /**
     * 缓入缓出 - 开始和结束时缓慢，中间快速
     */
    public static final EasingFunction EASE_IN_OUT = new EasingFunction() {
        @Override
        public float apply(float t) {
            return t < 0.5f 
                ? 2 * t * t 
                : -1 + (4 - 2 * t) * t;
        }
    };
    
    /**
     * 三次方缓出 - 快速开始，缓慢结束
     */
    public static final EasingFunction EASE_OUT_CUBIC = new EasingFunction() {
        @Override
        public float apply(float t) {
            float f = t - 1;
            return f * f * f + 1;
        }
    };
    
    /**
     * 回弹缓入缓出 - 带有回弹效果的缓动
     * 类似苹果灵动岛的动画效果
     */
    public static final EasingFunction EASE_IN_OUT_BACK = new EasingFunction() {
        @Override
        public float apply(float t) {
            float c1 = 1.70158f;
            float c2 = c1 * 1.525f;
            
            if (t < 0.5f) {
                return (float) (Math.pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2;
            } else {
                return (float) (Math.pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2;
            }
        }
    };
    
    /**
     * 缓入 - 慢速开始
     */
    public static final EasingFunction EASE_IN = new EasingFunction() {
        @Override
        public float apply(float t) {
            return t * t;
        }
    };
    
    /**
     * 缓出 - 慢速结束
     */
    public static final EasingFunction EASE_OUT = new EasingFunction() {
        @Override
        public float apply(float t) {
            return t * (2 - t);
        }
    };
    
    /**
     * 弹性缓出 - 带有弹性效果
     */
    public static final EasingFunction EASE_OUT_ELASTIC = new EasingFunction() {
        @Override
        public float apply(float t) {
            if (t == 0 || t == 1) {
                return t;
            }
            
            float p = 0.3f;
            return (float) (Math.pow(2, -10 * t) * Math.sin((t - p / 4) * (2 * Math.PI) / p) + 1);
        }
    };
    
    /**
     * 反弹缓出 - 模拟物体落地反弹
     */
    public static final EasingFunction EASE_OUT_BOUNCE = new EasingFunction() {
        @Override
        public float apply(float t) {
            if (t < 1 / 2.75f) {
                return 7.5625f * t * t;
            } else if (t < 2 / 2.75f) {
                t -= 1.5f / 2.75f;
                return 7.5625f * t * t + 0.75f;
            } else if (t < 2.5f / 2.75f) {
                t -= 2.25f / 2.75f;
                return 7.5625f * t * t + 0.9375f;
            } else {
                t -= 2.625f / 2.75f;
                return 7.5625f * t * t + 0.984375f;
            }
        }
    };
}
