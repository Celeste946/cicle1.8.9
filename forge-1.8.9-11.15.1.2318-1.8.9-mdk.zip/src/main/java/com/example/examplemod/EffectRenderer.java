package com.example.examplemod;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/**
 * 视觉效果渲染器
 * 提供圆角矩形、阴影、发光等效果
 */
public class EffectRenderer {
    
    /**
     * 渲染圆角矩形（使用平滑线）
     */
    public void renderRoundedRect(float x, float y, float width, float height, float radius, int color) {
        // 提取颜色分量
        float a = (color >> 24 & 0xFF) / 255.0f;
        float r = (color >> 16 & 0xFF) / 255.0f;
        float g = (color >> 8 & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        
        // 启用平滑和抗锯齿
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glEnable(GL11.GL_POLYGON_SMOOTH);
        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_NICEST);
        
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        
        // 限制圆角半径
        radius = Math.min(radius, Math.min(width, height) / 2);
        
        // 增加圆角分段数以获得更平滑的效果
        int segments = 16;
        
        worldRenderer.begin(GL11.GL_POLYGON, DefaultVertexFormats.POSITION_COLOR);
        
        // 左上角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI + i * (Math.PI / 2) / segments;
            double cx = x + radius + Math.cos(angle) * radius;
            double cy = y + radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 左下角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 1.5 + i * (Math.PI / 2) / segments;
            double cx = x + radius + Math.cos(angle) * radius;
            double cy = y + height - radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 右下角
        for (int i = 0; i <= segments; i++) {
            double angle = i * (Math.PI / 2) / segments;
            double cx = x + width - radius + Math.cos(angle) * radius;
            double cy = y + height - radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 右上角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI / 2 + i * (Math.PI / 2) / segments;
            double cx = x + width - radius + Math.cos(angle) * radius;
            double cy = y + radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        tessellator.draw();
        
        // 恢复状态
        GL11.glDisable(GL11.GL_POLYGON_SMOOTH);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
    
    /**
     * 渲染阴影效果（使用平滑渐变）
     */
    public void renderShadow(float x, float y, float width, float height, float radius, int shadowColor, float shadowSize) {
        float baseAlpha = (shadowColor >> 24 & 0xFF) / 255.0f;
        int baseColor = shadowColor & 0xFFFFFF;
        
        // 启用平滑渲染
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glEnable(GL11.GL_POLYGON_SMOOTH);
        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_NICEST);
        
        // 绘制更柔和的阴影，使用更平滑的渐变
        int layers = (int) shadowSize;
        for (int i = layers; i > 0; i--) {
            // 使用平方根函数使阴影渐变更自然
            float ratio = (float) i / (float) layers;
            float alpha = baseAlpha * (1.0f - (float) Math.sqrt(ratio));
            int layerColor = ((int) (alpha * 255) << 24) | baseColor;
            
            renderRoundedRectInternal(
                x - i * 0.5f,  // 减少阴影扩散
                y - i * 0.5f,
                width + i,
                height + i,
                radius + i * 0.5f,
                layerColor
            );
        }
        
        // 恢复状态
        GL11.glDisable(GL11.GL_POLYGON_SMOOTH);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
    }
    
    /**
     * 内部渲染方法（不改变 OpenGL 平滑状态）
     */
    private void renderRoundedRectInternal(float x, float y, float width, float height, float radius, int color) {
        // 提取颜色分量
        float a = (color >> 24 & 0xFF) / 255.0f;
        float r = (color >> 16 & 0xFF) / 255.0f;
        float g = (color >> 8 & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
        
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        
        // 限制圆角半径
        radius = Math.min(radius, Math.min(width, height) / 2);
        
        // 增加圆角分段数
        int segments = 16;
        
        worldRenderer.begin(GL11.GL_POLYGON, DefaultVertexFormats.POSITION_COLOR);
        
        // 左上角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI + i * (Math.PI / 2) / segments;
            double cx = x + radius + Math.cos(angle) * radius;
            double cy = y + radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 左下角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 1.5 + i * (Math.PI / 2) / segments;
            double cx = x + radius + Math.cos(angle) * radius;
            double cy = y + height - radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 右下角
        for (int i = 0; i <= segments; i++) {
            double angle = i * (Math.PI / 2) / segments;
            double cx = x + width - radius + Math.cos(angle) * radius;
            double cy = y + height - radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 右上角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI / 2 + i * (Math.PI / 2) / segments;
            double cx = x + width - radius + Math.cos(angle) * radius;
            double cy = y + radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        tessellator.draw();
        
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
    
    /**
     * 渲染发光效果（使用平滑渐变）
     */
    public void renderGlow(float x, float y, float width, float height, float radius, int glowColor, float glowIntensity) {
        float baseAlpha = (glowColor >> 24 & 0xFF) / 255.0f * glowIntensity;
        int baseColor = glowColor & 0xFFFFFF;
        
        // 启用平滑渲染
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glEnable(GL11.GL_POLYGON_SMOOTH);
        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_NICEST);
        
        // 绘制多层发光，从内到外逐渐透明
        int layers = 6;
        for (int i = 0; i < layers; i++) {
            float alpha = baseAlpha * (1.0f - i / (float) layers);
            int layerColor = ((int) (alpha * 255) << 24) | baseColor;
            
            renderRoundedRectInternal(
                x - i,
                y - i,
                width + i * 2,
                height + i * 2,
                radius + i,
                layerColor
            );
        }
        
        // 恢复状态
        GL11.glDisable(GL11.GL_POLYGON_SMOOTH);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
    }
    
    /**
     * 九宫格拉伸渲染纹理（避免边角变形）
     * 只拉伸中间区域，保留边角原样
     * @param texture 纹理资源
     * @param x 渲染 X 坐标
     * @param y 渲染 Y 坐标
     * @param width 目标宽度
     * @param height 目标高度
     * @param textureWidth 纹理总宽度（应为 2 的幂次方，如 256）
     * @param textureHeight 纹理总高度（应为 2 的幂次方，如 64）
     * @param cornerSize 边角大小（不拉伸区域，像素单位）
     * @param alpha 透明度
     */
    public void renderNinePatch(ResourceLocation texture, float x, float y, float width, float height, 
                                int textureWidth, int textureHeight, float cornerSize, float alpha) {
        try {
            GlStateManager.enableBlend();
            GlStateManager.enableTexture2D();
            GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
            GlStateManager.color(1.0f, 1.0f, 1.0f, alpha);
            
            net.minecraft.client.Minecraft.getMinecraft().getTextureManager().bindTexture(texture);
            
            Tessellator tessellator = Tessellator.getInstance();
            WorldRenderer worldRenderer = tessellator.getWorldRenderer();
            
            // 计算 UV 坐标（归一化到 0-1）
            float cornerU = cornerSize / (float) textureWidth;
            float cornerV = cornerSize / (float) textureHeight;
            
            // 确保边角大小不超过目标尺寸的一半
            float actualCornerSize = Math.min(cornerSize, Math.min(width / 2, height / 2));
            
            // 九宫格分区（只拉伸中间区域，保留边角）：
            // 左上 | 上 | 右上
            // 左   | 中 | 右
            // 左下 | 下 | 右下
            
            // 左上角（不拉伸）
            drawTexturedQuad(worldRenderer, x, y, actualCornerSize, actualCornerSize, 
                            0, 0, cornerU, cornerV);
            
            // 上边（水平拉伸）
            drawTexturedQuad(worldRenderer, x + actualCornerSize, y, width - actualCornerSize * 2, actualCornerSize,
                            cornerU, 0, 1 - cornerU, cornerV);
            
            // 右上角（不拉伸）
            drawTexturedQuad(worldRenderer, x + width - actualCornerSize, y, actualCornerSize, actualCornerSize,
                            1 - cornerU, 0, 1, cornerV);
            
            // 左边（垂直拉伸）
            drawTexturedQuad(worldRenderer, x, y + actualCornerSize, actualCornerSize, height - actualCornerSize * 2,
                            0, cornerV, cornerU, 1 - cornerV);
            
            // 中间（双向拉伸）
            drawTexturedQuad(worldRenderer, x + actualCornerSize, y + actualCornerSize, 
                            width - actualCornerSize * 2, height - actualCornerSize * 2,
                            cornerU, cornerV, 1 - cornerU, 1 - cornerV);
            
            // 右边（垂直拉伸）
            drawTexturedQuad(worldRenderer, x + width - actualCornerSize, y + actualCornerSize, 
                            actualCornerSize, height - actualCornerSize * 2,
                            1 - cornerU, cornerV, 1, 1 - cornerV);
            
            // 左下角（不拉伸）
            drawTexturedQuad(worldRenderer, x, y + height - actualCornerSize, actualCornerSize, actualCornerSize,
                            0, 1 - cornerV, cornerU, 1);
            
            // 下边（水平拉伸）
            drawTexturedQuad(worldRenderer, x + actualCornerSize, y + height - actualCornerSize, 
                            width - actualCornerSize * 2, actualCornerSize,
                            cornerU, 1 - cornerV, 1 - cornerU, 1);
            
            // 右下角（不拉伸）
            drawTexturedQuad(worldRenderer, x + width - actualCornerSize, y + height - actualCornerSize, 
                            actualCornerSize, actualCornerSize,
                            1 - cornerU, 1 - cornerV, 1, 1);
            
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        } catch (Exception e) {
            System.err.println("[EffectRenderer] 九宫格渲染失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 绘制带纹理的四边形
     */
    private void drawTexturedQuad(WorldRenderer worldRenderer, float x, float y, float width, float height,
                                  float u1, float v1, float u2, float v2) {
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(x, y + height, 0.0).tex(u1, v2).endVertex();
        worldRenderer.pos(x + width, y + height, 0.0).tex(u2, v2).endVertex();
        worldRenderer.pos(x + width, y, 0.0).tex(u2, v1).endVertex();
        worldRenderer.pos(x, y, 0.0).tex(u1, v1).endVertex();
        Tessellator.getInstance().draw();
    }
    
    /**
     * 渲染渐变背景（垂直）
     */
    public void renderGradient(float x, float y, float width, float height, int colorTop, int colorBottom) {
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
        
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        
        // 提取颜色分量
        float topA = (colorTop >> 24 & 0xFF) / 255.0f;
        float topR = (colorTop >> 16 & 0xFF) / 255.0f;
        float topG = (colorTop >> 8 & 0xFF) / 255.0f;
        float topB = (colorTop & 0xFF) / 255.0f;
        
        float bottomA = (colorBottom >> 24 & 0xFF) / 255.0f;
        float bottomR = (colorBottom >> 16 & 0xFF) / 255.0f;
        float bottomG = (colorBottom >> 8 & 0xFF) / 255.0f;
        float bottomB = (colorBottom & 0xFF) / 255.0f;
        
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        worldRenderer.pos(x + width, y, 0.0).color(topR, topG, topB, topA).endVertex();
        worldRenderer.pos(x, y, 0.0).color(topR, topG, topB, topA).endVertex();
        worldRenderer.pos(x, y + height, 0.0).color(bottomR, bottomG, bottomB, bottomA).endVertex();
        worldRenderer.pos(x + width, y + height, 0.0).color(bottomR, bottomG, bottomB, bottomA).endVertex();
        tessellator.draw();
        
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }
}
