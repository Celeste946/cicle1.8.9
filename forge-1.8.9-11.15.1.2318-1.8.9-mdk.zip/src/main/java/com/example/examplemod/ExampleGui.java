package com.example.examplemod;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExampleGui extends GuiScreen {
    // 纹理资源
    private static final ResourceLocation EXPAND_TEXTURE = new ResourceLocation("examplemod", "textures/gui/expand.png");
    private static final ResourceLocation COLLAPSE_TEXTURE = new ResourceLocation("examplemod", "textures/gui/collapse.png");
    private static final ResourceLocation DEFAULT_TEXTURE = new ResourceLocation("textures/gui/widgets.png");

    // GUI核心属性
    private final List<CategoryPanel> categories = new ArrayList<>();
    private int guiX, guiY;
    private boolean isDragging = false;
    private int dragStartX, dragStartY;

    // 样式配置
    private static final int BACKGROUND_ALPHA = 230;
    private static final int PANEL_WIDTH = 120;
    private static final int PANEL_SPACING = 10;
    private static final int TITLE_BAR_HEIGHT = 20;
    private static final float ANIMATION_SPEED = 0.15f;

    public ExampleGui() {
        // 初始化默认位置
        this.guiX = 100;
        this.guiY = 100;

        categories.add(new CategoryPanel("移动", new String[]{"快速移动", "自动疾跑", "无掉落伤害"}));
        categories.add(new CategoryPanel("战斗", new String[]{"自动攻击", "血量卡片"}));
        categories.add(new CategoryPanel("帮助", new String[]{"关于", "教程"}));
    }

    @Override
    public void initGui() {
        super.initGui();
        
        // 计算居中位置
        try {
            ScaledResolution res = new ScaledResolution(mc);
            this.guiX = (res.getScaledWidth() - (PANEL_WIDTH * 3 + PANEL_SPACING * 2)) / 2;
            this.guiY = res.getScaledHeight() / 4;
        } catch (Exception e) {
            System.err.println("[ExampleGui] 无法计算GUI位置: " + e.getMessage());
            this.guiX = 100;
            this.guiY = 100;
        }
        
        // 自定义字体已在 ExampleMod 启动时异步加载
        // 这里不需要额外操作
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (mc == null) return;

        // 保存 OpenGL 状态
        GlStateManager.pushMatrix();
        try {
            // 尝试绘制着色器效果背景
            try {
                // 绘制渐变背景（着色器效果）
                GuiShaderEffects.drawGradientBackground(0, 0, width, height, 0x80000000, 0xC0000020);
                
                // 绘制扫描线效果
                GuiShaderEffects.drawScanlines(0, 0, width, height, 0x10FFFFFF, 4);
            } catch (Exception e) {
                // 如果着色器效果失败，使用简单背景并恢复状态
                System.err.println("[ExampleGui] 着色器效果失败，回退到默认背景: " + e.getMessage());
                // 恢复可能被破坏的状态
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableTexture2D();
                GlStateManager.disableBlend();
                drawDefaultBackground();
            }

            // 绘制所有面板（带动画和发光效果）
            int currentX = guiX;
            for (CategoryPanel panel : categories) {
                try {
                    // 绘制面板阴影
                    GuiShaderEffects.drawBlurredShadow(currentX, guiY, PANEL_WIDTH, 
                        (int) panel.currentHeight, 0x80000000);
                } catch (Exception e) {
                    // 阴影绘制失败，恢复状态并跳过
                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                    GlStateManager.enableTexture2D();
                    GlStateManager.disableBlend();
                }
                
                panel.draw(currentX, guiY, PANEL_WIDTH, mouseX, mouseY, partialTicks);
                currentX += PANEL_WIDTH + PANEL_SPACING;
            }

            super.drawScreen(mouseX, mouseY, partialTicks);
        } finally {
            // 确保恢复 OpenGL 状态
            GlStateManager.popMatrix();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
        }
    }

    // 使用Tessellator绘制半透明背景
    private void drawTransparentBackground() {
        GlStateManager.pushMatrix();
        try {
            Tessellator tessellator = Tessellator.getInstance();
            WorldRenderer worldRenderer = tessellator.getWorldRenderer();
            GlStateManager.enableBlend();
            GlStateManager.disableTexture2D();
            GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

            worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            // 使用正确的颜色格式：RGBA 浮点数 (0.0-1.0)
            worldRenderer.pos(0, height, 0).color(0, 0, 0, 100).endVertex();
            worldRenderer.pos(width, height, 0).color(0, 0, 0, 100).endVertex();
            worldRenderer.pos(width, 0, 0).color(0, 0, 0, 100).endVertex();
            worldRenderer.pos(0, 0, 0).color(0, 0, 0, 100).endVertex();
            tessellator.draw();
        } finally {
            // 确保恢复状态
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.popMatrix();
        }
    }

    // 字体渲染方法 - 使用自定义字体系统
    private void drawCustomFontString(String text, int x, int y, int color) {
        // 使用 CustomFont 系统（如果加载完成则使用自定义字体，否则使用默认字体）
        CustomFont.getInstance().drawStringWithShadow(text, x, y, color);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mc == null) return;

        if (mouseButton == 0) {
            int totalWidth = categories.size() * PANEL_WIDTH + (categories.size() - 1) * PANEL_SPACING;
            if (isPointInRegion(guiX, guiY, totalWidth, TITLE_BAR_HEIGHT, mouseX, mouseY)) {
                isDragging = true;
                dragStartX = mouseX - guiX;
                dragStartY = mouseY - guiY;
                return;
            }
        }

        int currentX = guiX;
        for (CategoryPanel panel : categories) {
            panel.handleClick(currentX, guiY, PANEL_WIDTH, mouseX, mouseY);
            currentX += PANEL_WIDTH + PANEL_SPACING;
        }

        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        isDragging = false;
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        if (isDragging && mc != null) {
            ScaledResolution res = new ScaledResolution(mc);
            int mouseX = Mouse.getX() * res.getScaledWidth() / mc.displayWidth;
            int mouseY = res.getScaledHeight() - Mouse.getY() * res.getScaledHeight() / mc.displayHeight - 1;

            guiX = mouseX - dragStartX;
            guiY = mouseY - dragStartY;
            guiX = Math.max(0, Math.min(guiX, res.getScaledWidth() - 100));
            guiY = Math.max(0, Math.min(guiY, res.getScaledHeight() - 100));
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    protected boolean isPointInRegion(int x, int y, int width, int height, int mouseX, int mouseY) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }

    // 带动画的分类面板
    private class CategoryPanel {
        private final String title;
        private final List<Button> buttons;
        private boolean targetExpanded = true;
        private float currentHeight;

        public CategoryPanel(String title, String[] buttonNames) {
            this.title = title;
            this.buttons = new ArrayList<>();
            for (String name : buttonNames) {
                this.buttons.add(new Button(name));
            }
            this.currentHeight = getTargetHeight();
        }

        private int getTargetHeight() {
            return TITLE_BAR_HEIGHT + (targetExpanded ? buttons.size() * 18 : 0);
        }

        public void draw(int x, int y, int width, int mouseX, int mouseY, float partialTicks) {
            if (mc == null) return;

            // 保存状态
            GlStateManager.pushMatrix();
            try {
                // 动画插值
                int targetHeight = getTargetHeight();
                currentHeight += (targetHeight - currentHeight) * ANIMATION_SPEED * (1 / partialTicks);

                // 绘制面板背景
                drawPanelBackground(x, y, width, (int) currentHeight);

                // 绘制标题栏
                drawTitleBar(x, y, width);

                // 绘制展开/收起按钮
                drawToggleButton(x, y, width);

                // 绘制按钮（动画显示）
                if (currentHeight > TITLE_BAR_HEIGHT + 5) {
                    int buttonY = y + TITLE_BAR_HEIGHT;
                    float visibleButtons = (currentHeight - TITLE_BAR_HEIGHT) / 18;
                    for (int i = 0; i < buttons.size() && i < visibleButtons; i++) {
                        buttons.get(i).draw(x, buttonY, width, mouseX, mouseY);
                        buttonY += 18;
                    }
                }

                // 标题栏悬停高亮
                if (ExampleGui.this.isPointInRegion(x, y, width, TITLE_BAR_HEIGHT, mouseX, mouseY)) {
                    drawRect(x, y, x + width, y + TITLE_BAR_HEIGHT, new Color(255, 255, 255, 30).getRGB());
                }
            } finally {
                // 恢复状态
                GlStateManager.popMatrix();
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            }
        }

        private void drawPanelBackground(int x, int y, int width, int height) {
            GlStateManager.pushMatrix();
            try {
                Tessellator tessellator = Tessellator.getInstance();
                WorldRenderer worldRenderer = tessellator.getWorldRenderer();
                GlStateManager.enableBlend();
                GlStateManager.disableTexture2D();
                GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

                int bgColor = new Color(30, 30, 30, BACKGROUND_ALPHA).getRGB();
                worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
                addQuad(worldRenderer, x, y, x + width, y + height, bgColor);
                tessellator.draw();
            } finally {
                // 确保恢复状态
                GlStateManager.enableTexture2D();
                GlStateManager.disableBlend();
                GlStateManager.popMatrix();
            }
        }

        private void drawTitleBar(int x, int y, int width) {
            drawRect(x, y, x + width, y + TITLE_BAR_HEIGHT, new Color(123, 66, 245).getRGB());
            ExampleGui.this.drawCustomFontString(title, x + 5, y + 6, 0xFFFFFF);
        }

        private void drawToggleButton(int x, int y, int width) {
            TextureManager texManager = mc.getTextureManager();
            GlStateManager.pushMatrix();
            try {
                GlStateManager.enableBlend();
                GlStateManager.enableTexture2D();
                try {
                    texManager.bindTexture(targetExpanded ? COLLAPSE_TEXTURE : EXPAND_TEXTURE);
                } catch (Exception e) {
                    texManager.bindTexture(DEFAULT_TEXTURE);
                }
                drawTexturedModalRect(x + width - 20, y + 2, 0, 0, 16, 16);
            } finally {
                // 确保恢复状态
                GlStateManager.disableBlend();
                GlStateManager.bindTexture(0);
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.popMatrix();
            }
        }

        public void handleClick(int x, int y, int width, int mouseX, int mouseY) {
            if (ExampleGui.this.isPointInRegion(x, y, width, TITLE_BAR_HEIGHT, mouseX, mouseY)) {
                targetExpanded = !targetExpanded;
                return;
            }

            if (targetExpanded) {
                int buttonY = y + TITLE_BAR_HEIGHT;
                for (Button button : buttons) {
                    if (ExampleGui.this.isPointInRegion(x, buttonY, width, 18, mouseX, mouseY)) {
                        button.onClick();
                    }
                    buttonY += 18;
                }
            }
        }

        private void addQuad(WorldRenderer renderer, int x1, int y1, int x2, int y2, int color) {
            float a = (color >> 24 & 0xFF) / 255.0f;
            float r = (color >> 16 & 0xFF) / 255.0f;
            float g = (color >> 8 & 0xFF) / 255.0f;
            float b = (color & 0xFF) / 255.0f;
            renderer.pos(x1, y2, 0).color(r, g, b, a).endVertex();
            renderer.pos(x2, y2, 0).color(r, g, b, a).endVertex();
            renderer.pos(x2, y1, 0).color(r, g, b, a).endVertex();
            renderer.pos(x1, y1, 0).color(r, g, b, a).endVertex();
        }
    }

    // 按钮类
    private class Button {
        private final String name;
        private boolean hovered = false;

        public Button(String name) {
            this.name = name;
        }

        public void draw(int x, int y, int width, int mouseX, int mouseY) {
            hovered = ExampleGui.this.isPointInRegion(x, y, width, 18, mouseX, mouseY);
            
            // 检查功能按钮状态
            boolean isFastMovement = name.equals("快速移动");
            boolean isAutoSprint = name.equals("自动疾跑");
            boolean isNoFallDamage = name.equals("无掉落伤害");
            boolean isAutoAttack = name.equals("自动攻击");
            boolean isHealthCard = name.equals("血量卡片");
            boolean isEnabled = (isFastMovement && FastMovement.getInstance().isEnabled()) ||
                               (isAutoSprint && AutoSprint.getInstance().isEnabled()) ||
                               (isNoFallDamage && NoFallDamage.getInstance().isEnabled()) ||
                               (isAutoAttack && AutoAttack.getInstance().isEnabled()) ||
                               (isHealthCard && HealthCardRenderer.getInstance().isEnabled());
            
            int color;
            if (isEnabled) {
                // 启用状态：绿色背景
                color = new Color(30, 120, 30, BACKGROUND_ALPHA).getRGB();
            } else if (hovered) {
                color = new Color(50, 50, 50, BACKGROUND_ALPHA).getRGB();
            } else {
                color = new Color(40, 40, 40, BACKGROUND_ALPHA).getRGB();
            }
            
            drawRect(x, y, x + width, y + 18, color);
            
            // 显示按钮文本和状态
            String displayText = name;
            if (isFastMovement || isAutoSprint || isNoFallDamage) {
                displayText = name + ": " + (isEnabled ? "[开]" : "[关]");
            } else if (isAutoAttack || isHealthCard) {
                displayText = name + (isEnabled ? ": [开]" : "");
            }
            ExampleGui.this.drawCustomFontString(displayText, x + 5, y + 5, 0xFFFFFF);
        }

        public void onClick() {
            if (mc != null && mc.thePlayer != null) {
                // 快速移动按钮
                if (name.equals("快速移动")) {
                    FastMovement.getInstance().toggle();
                    String status = FastMovement.getInstance().isEnabled() ? "已启用" : "已禁用";
                    mc.thePlayer.addChatMessage(new ChatComponentText("§a快速移动 " + status));
                }
                // 自动疾跑按钮
                else if (name.equals("自动疾跑")) {
                    AutoSprint.getInstance().toggle();
                    String status = AutoSprint.getInstance().isEnabled() ? "已启用" : "已禁用";
                    mc.thePlayer.addChatMessage(new ChatComponentText("§a自动疾跑 " + status));
                }
                // 无掉落伤害按钮
                else if (name.equals("无掉落伤害")) {
                    NoFallDamage.getInstance().toggle();
                    String status = NoFallDamage.getInstance().isEnabled() ? "已启用" : "已禁用";
                    mc.thePlayer.addChatMessage(new ChatComponentText("§a无掉落伤害 " + status));
                }
                // 自动攻击按钮 - 打开设置界面
                else if (name.equals("自动攻击")) {
                    mc.displayGuiScreen(new AutoAttackGui());
                }
                // 血量卡片按钮 - 打开设置界面
                else if (name.equals("血量卡片")) {
                    mc.displayGuiScreen(new HealthCardGui());
                }
                // 其他按钮
                else {
                    mc.thePlayer.addChatMessage(new ChatComponentText("点击了按钮：" + name));
                }
            }
        }
    }
}