package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.input.Keyboard;

@Mod(
        modid = ExampleMod.MODID,
        name = ExampleMod.NAME,
        version = ExampleMod.VERSION,
        clientSideOnly = true
)
public class ExampleMod {
    public static final String MODID = "examplemod";
    public static final String NAME = "Example Mod";
    public static final String VERSION = "1.0";

    public static final KeyBinding openGuiKey = new KeyBinding(
            "key.gui.open",
            Keyboard.KEY_R,
            "category.examplemod"
    );
    
    public static final KeyBinding verifyHealthCardKey = new KeyBinding(
            "key.verify.healthcard",
            Keyboard.KEY_V,
            "category.examplemod"
    );
    
    public static final KeyBinding toggleDynamicIslandKey = new KeyBinding(
            "key.toggle.dynamicisland",
            Keyboard.KEY_I,
            "category.examplemod"
    );
    
    public static final KeyBinding openDynamicIslandConfigKey = new KeyBinding(
            "key.config.dynamicisland",
            Keyboard.KEY_O,
            "category.examplemod"
    );

    @Mod.Instance(MODID)
    public static ExampleMod instance;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ClientRegistry.registerKeyBinding(openGuiKey);
        ClientRegistry.registerKeyBinding(verifyHealthCardKey);
        ClientRegistry.registerKeyBinding(toggleDynamicIslandKey);
        ClientRegistry.registerKeyBinding(openDynamicIslandConfigKey);
        MinecraftForge.EVENT_BUS.register(this);
        
        // 注册移动事件处理器
        MinecraftForge.EVENT_BUS.register(new MovementEventHandler());
        System.out.println("[ExampleMod] 移动事件处理器已注册");
        
        // 注册自定义挥砍动画处理器
        MinecraftForge.EVENT_BUS.register(CustomSwingAnimation.getInstance());
        System.out.println("[ExampleMod] 自定义挥砍动画已注册");
        
        // 注册名称标签渲染器
        MinecraftForge.EVENT_BUS.register(NameTagRenderer.getInstance());
        System.out.println("[ExampleMod] 名称标签渲染器已注册");
        
        // 注册受攻击白圈渲染器
        MinecraftForge.EVENT_BUS.register(HitCircleRenderer.getInstance());
        System.out.println("[ExampleMod] 受攻击白圈渲染器已注册");
        
        // 注册血量卡片渲染器
        MinecraftForge.EVENT_BUS.register(HealthCardRenderer.getInstance());
        System.out.println("[ExampleMod] 血量卡片渲染器已注册");
        
        // 注册背包行走功能（默认启用）
        MinecraftForge.EVENT_BUS.register(InventoryMove.getInstance());
        System.out.println("[ExampleMod] 背包行走功能已注册");
        
        // 注册无掉落伤害功能
        MinecraftForge.EVENT_BUS.register(NoFallDamage.getInstance());
        System.out.println("[ExampleMod] 无掉落伤害功能已注册");
        
        // 注册通知系统
        MinecraftForge.EVENT_BUS.register(NotificationSystem.getInstance());
        System.out.println("[ExampleMod] 通知系统已注册");
        
        // 异步加载自定义字体（不阻塞启动）
        CustomFont.getInstance().loadFontAsync();
        System.out.println("[ExampleMod] 开始异步加载自定义字体");
        
        // 初始化并注册灵动岛
        DynamicIsland dynamicIsland = DynamicIsland.getInstance();
        dynamicIsland.initialize();
        MinecraftForge.EVENT_BUS.register(dynamicIsland);
        System.out.println("[ExampleMod] 灵动岛已注册");
        
        // 添加默认内容到灵动岛 - 显示更多信息
        dynamicIsland.addContent(new TextContent("⚙", 0x4A9EFF, 1)); // 蓝色图标
        dynamicIsland.addContent(new TextContent("Obai", 0xFFFFFF, 2)); // 服务器/模组名
        dynamicIsland.addContent(new TextContent("•", 0x888888, 3)); // 分隔符
        dynamicIsland.addContent(new TextContent("👤", 0xFFFFFF, 4)); // 用户图标
        dynamicIsland.addContent(new PlayerInfoContent(PlayerInfoContent.InfoType.COORDINATES, 5)); // 玩家名/坐标
        dynamicIsland.addContent(new TextContent("•", 0x888888, 6)); // 分隔符
        dynamicIsland.addContent(new TextContent("🔧", 0xFFFFFF, 7)); // FPS图标
        dynamicIsland.addContent(new FPSContent(8)); // FPS显示
        System.out.println("[ExampleMod] 灵动岛默认内容已添加");
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (openGuiKey.isPressed() && Minecraft.getMinecraft() != null && Minecraft.getMinecraft().theWorld != null) {
            Minecraft.getMinecraft().displayGuiScreen(new ExampleGui());
            
            // 不在打开GUI时显示通知，避免渲染冲突导致白屏
            // 通知系统会在GUI关闭后才渲染
        }
        
        if (verifyHealthCardKey.isPressed()) {
            // 运行 HealthCardRenderer 验证
            HealthCardRendererVerification.runAllVerifications();
        }
        
        if (toggleDynamicIslandKey.isPressed()) {
            // 切换灵动岛状态
            DynamicIsland island = DynamicIsland.getInstance();
            island.toggleState();
            System.out.println("[ExampleMod] 灵动岛状态切换到: " + island.getState());
        }
        
        if (openDynamicIslandConfigKey.isPressed() && Minecraft.getMinecraft() != null && Minecraft.getMinecraft().theWorld != null) {
            // 打开灵动岛配置 GUI
            Minecraft.getMinecraft().displayGuiScreen(new DynamicIslandConfigGui());
        }
    }
}