package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

/**
 * FPS 内容 - 显示当前帧率
 */
public class FPSContent implements IslandContent {
    private int priority;
    
    public FPSContent(int priority) {
        this.priority = priority;
    }
    
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fontRenderer = mc.fontRendererObj;
        
        // 获取当前 FPS
        int fps = Minecraft.getDebugFPS();
        String text = fps + " FPS";
        
        // 根据 FPS 设置颜色
        int color;
        if (fps >= 60) {
            color = 0x00FF00; // 绿色 - 流畅
        } else if (fps >= 30) {
            color = 0xFFFF00; // 黄色 - 一般
        } else {
            color = 0xFF0000; // 红色 - 卡顿
        }
        
        fontRenderer.drawStringWithShadow(text, x, y, color);
    }
    
    @Override
    public float getPreferredWidth() {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fontRenderer = mc.fontRendererObj;
        int fps = Minecraft.getDebugFPS();
        return fontRenderer.getStringWidth(fps + " FPS");
    }
    
    @Override
    public float getPreferredHeight() {
        return 8;
    }
    
    @Override
    public int getPriority() {
        return priority;
    }
    
    @Override
    public boolean shouldDisplay() {
        return true;
    }
}
