package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;

/**
 * 快速移动功能模块
 * 允许玩家以每秒 8 格的速度在各个方向移动
 */
public class FastMovement {
    private static FastMovement instance;
    private boolean enabled = false;
    
    // 速度常量：0.4 格/tick = 8 格/秒 (20 ticks/秒)
    private static final double SPEED = 0.8;
    
    private FastMovement() {
        // 私有构造函数，单例模式
    }
    
    /**
     * 获取单例实例
     */
    public static FastMovement getInstance() {
        if (instance == null) {
            instance = new FastMovement();
        }
        return instance;
    }
    
    /**
     * 切换快速移动功能
     */
    public void toggle() {
        enabled = !enabled;
        System.out.println("[FastMovement] 快速移动已" + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 检查功能是否启用
     */
    public boolean isEnabled() {
        return enabled;
    }
    
    /**
     * 设置功能状态
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    /**
     * 每个 tick 应用移动逻辑 - 快节奏跑跳模式
     */
    public void onPlayerTick(EntityPlayerSP player) {
        if (player == null) return;
        
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.isGamePaused() || mc.currentScreen != null) {
            return;
        }
        
        GameSettings settings = mc.gameSettings;
        
        // 获取玩家朝向（转换为弧度）
        float yaw = (float) Math.toRadians(player.rotationYaw);
        
        // 计算水平移动方向
        double moveX = 0;
        double moveZ = 0;
        
        // 前后移动（W/S）
        if (settings.keyBindForward.isKeyDown()) {
            moveX -= Math.sin(yaw) * SPEED;
            moveZ += Math.cos(yaw) * SPEED;
        }
        if (settings.keyBindBack.isKeyDown()) {
            moveX += Math.sin(yaw) * SPEED;
            moveZ -= Math.cos(yaw) * SPEED;
        }
        
        // 左右移动（A/D）
        if (settings.keyBindLeft.isKeyDown()) {
            moveX += Math.cos(yaw) * SPEED;
            moveZ += Math.sin(yaw) * SPEED;
        }
        if (settings.keyBindRight.isKeyDown()) {
            moveX -= Math.cos(yaw) * SPEED;
            moveZ -= Math.sin(yaw) * SPEED;
        }
        
        // 检查是否有水平移动
        boolean isMoving = moveX != 0 || moveZ != 0;
        
        // 应用水平速度
        if (isMoving) {
            player.motionX = moveX;
            player.motionZ = moveZ;
            
            // 自动跳跃 - 移动时在地面自动跳跃
            if (player.onGround) {
                player.motionY = 0.42; // 标准跳跃高度
            }
        }
        
        // 手动跳跃 - 按空格键也可以跳跃
        if (settings.keyBindJump.isKeyDown() && player.onGround && !isMoving) {
            player.motionY = 0.42;
        }
        
        // 保持正常的重力和碰撞
        // 不修改 player.capabilities.isFlying
        // 不修改 player.onGround
    }
}
