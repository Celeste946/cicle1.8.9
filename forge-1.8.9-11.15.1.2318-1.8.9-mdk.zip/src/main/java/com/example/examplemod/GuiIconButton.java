package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

/**
 * 带图标的自定义按钮
 */
public class GuiIconButton extends GuiButton {
    private final ResourceLocation enabledIcon;
    private final ResourceLocation disabledIcon;
    private boolean state;
    
    private static final ResourceLocation ENABLED_TEXTURE = new ResourceLocation("examplemod", "textures/gui/enable.png");
    private static final ResourceLocation DISABLED_TEXTURE = new ResourceLocation("examplemod", "textures/gui/disable.png");
    
    public GuiIconButton(int buttonId, int x, int y, int width, int height, String buttonText, boolean initialState) {
        super(buttonId, x, y, width, height, buttonText);
        this.enabledIcon = ENABLED_TEXTURE;
        this.disabledIcon = DISABLED_TEXTURE;
        this.state = initialState;
    }
    
    public boolean getState() {
        return state;
    }
    
    public void setState(boolean state) {
        this.state = state;
    }
    
    public void toggle() {
        this.state = !this.state;
    }
    
    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (this.visible) {
            // 绘制按钮背景
            this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && 
                          mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
            
            // 绘制按钮底色
            int color = this.hovered ? 0xFF666666 : 0xFF444444;
            drawRect(this.xPosition, this.yPosition, this.xPosition + this.width, 
                    this.yPosition + this.height, color);
            
            // 绘制边框
            drawRect(this.xPosition, this.yPosition, this.xPosition + this.width, 
                    this.yPosition + 1, 0xFF888888);
            drawRect(this.xPosition, this.yPosition + this.height - 1, 
                    this.xPosition + this.width, this.yPosition + this.height, 0xFF888888);
            drawRect(this.xPosition, this.yPosition, this.xPosition + 1, 
                    this.yPosition + this.height, 0xFF888888);
            drawRect(this.xPosition + this.width - 1, this.yPosition, 
                    this.xPosition + this.width, this.yPosition + this.height, 0xFF888888);
            
            // 绘制图标
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            mc.getTextureManager().bindTexture(state ? enabledIcon : disabledIcon);
            
            int iconSize = Math.min(this.width, this.height) - 4;
            int iconX = this.xPosition + 2;
            int iconY = this.yPosition + (this.height - iconSize) / 2;
            
            drawModalRectWithCustomSizedTexture(iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
            
            // 绘制文本
            int textX = iconX + iconSize + 4;
            int textY = this.yPosition + (this.height - 8) / 2;
            int textColor = this.hovered ? 0xFFFFFF : 0xE0E0E0;
            
            mc.fontRendererObj.drawString(this.displayString, textX, textY, textColor);
        }
    }
}
