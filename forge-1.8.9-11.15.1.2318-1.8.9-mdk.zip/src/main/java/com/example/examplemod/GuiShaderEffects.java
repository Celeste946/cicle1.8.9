package com.example.examplemod;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

/**
 * GUI 着色器效果工具类
 * 提供各种视觉增强效果
 */
public class GuiShaderEffects {
    
    /**
     * 绘制渐变背景
     */
    public static void drawGradientBackground(int x, int y, int width, int height, int colorTop, int colorBottom) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
        
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        
        // 提取颜色分量
        float topA = (colorTop >> 24 & 0xFF) / 255.0f;
        float topR = (colorTop >> 16 & 0xFF) / 255.0f;
        float topG = (colorTop >> 8 & 0xFF) / 255.0f;
        float topB = (colorTop & 0xFF) / 255.0f;
        
        float bottomA = (colorBottom >> 24 & 0xFF) / 255.0f;
        float bottomR = (colorBottom >> 16 & 0xFF) / 255.0f;
        float bottomG = (colorBottom >> 8 & 0xFF) / 255.0f;
        float bottomB = (colorBottom & 0xFF) / 255.0f;
        
        worldRenderer.pos(x + width, y, 0.0).color(topR, topG, topB, topA).endVertex();
        worldRenderer.pos(x, y, 0.0).color(topR, topG, topB, topA).endVertex();
        worldRenderer.pos(x, y + height, 0.0).color(bottomR, bottomG, bottomB, bottomA).endVertex();
        worldRenderer.pos(x + width, y + height, 0.0).color(bottomR, bottomG, bottomB, bottomA).endVertex();
        
        tessellator.draw();
        
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }
    
    /**
     * 绘制发光边框
     */
    public static void drawGlowBorder(int x, int y, int width, int height, int color, float glowIntensity) {
        int layers = 3;
        for (int i = 0; i < layers; i++) {
            float alpha = ((color >> 24 & 0xFF) / 255.0f) * glowIntensity * (1.0f - i / (float) layers);
            int glowColor = (int) (alpha * 255) << 24 | (color & 0xFFFFFF);
            
            Gui.drawRect(x - i - 1, y - i - 1, x + width + i + 1, y - i, glowColor);
            Gui.drawRect(x - i - 1, y + height + i, x + width + i + 1, y + height + i + 1, glowColor);
            Gui.drawRect(x - i - 1, y - i, x - i, y + height + i, glowColor);
            Gui.drawRect(x + width + i, y - i, x + width + i + 1, y + height + i, glowColor);
        }
    }
    
    /**
     * 绘制模糊阴影
     */
    public static void drawBlurredShadow(int x, int y, int width, int height, int shadowColor) {
        int shadowSize = 8;
        
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        
        float baseAlpha = (shadowColor >> 24 & 0xFF) / 255.0f;
        float r = (shadowColor >> 16 & 0xFF) / 255.0f;
        float g = (shadowColor >> 8 & 0xFF) / 255.0f;
        float b = (shadowColor & 0xFF) / 255.0f;
        
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        
        // 上边阴影
        for (int i = 0; i < shadowSize; i++) {
            float alpha = baseAlpha * (1.0f - i / (float) shadowSize);
            worldRenderer.pos(x - shadowSize + i, y - shadowSize + i, 0.0).color(r, g, b, alpha).endVertex();
            worldRenderer.pos(x + width + shadowSize - i, y - shadowSize + i, 0.0).color(r, g, b, alpha).endVertex();
            worldRenderer.pos(x + width + shadowSize - i, y - shadowSize + i + 1, 0.0).color(r, g, b, alpha).endVertex();
            worldRenderer.pos(x - shadowSize + i, y - shadowSize + i + 1, 0.0).color(r, g, b, alpha).endVertex();
        }
        
        tessellator.draw();
        
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
    
    /**
     * 绘制脉冲效果
     */
    public static void drawPulseEffect(int x, int y, int width, int height, int color, float time) {
        float pulse = (float) (Math.sin(time * 0.003) * 0.5 + 0.5);
        float alpha = ((color >> 24 & 0xFF) / 255.0f) * pulse;
        int pulseColor = (int) (alpha * 255) << 24 | (color & 0xFFFFFF);
        
        Gui.drawRect(x, y, x + width, y + height, pulseColor);
    }
    
    /**
     * 绘制玻璃效果（半透明带高光）
     */
    public static void drawGlassEffect(int x, int y, int width, int height, int baseColor) {
        // 基础半透明背景
        Gui.drawRect(x, y, x + width, y + height, baseColor);
        
        // 顶部高光
        int highlightColor = 0x40FFFFFF;
        drawGradientBackground(x, y, width, height / 3, highlightColor, 0x00FFFFFF);
        
        // 边框
        int borderColor = 0x80FFFFFF;
        Gui.drawRect(x, y, x + width, y + 1, borderColor);
        Gui.drawRect(x, y, x + 1, y + height, borderColor);
    }
    
    /**
     * 绘制扫描线效果
     */
    public static void drawScanlines(int x, int y, int width, int height, int color, int lineSpacing) {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        
        for (int i = y; i < y + height; i += lineSpacing) {
            Gui.drawRect(x, i, x + width, i + 1, color);
        }
        
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
    
    /**
     * 绘制圆角矩形
     */
    public static void drawRoundedRect(int x, int y, int width, int height, int radius, int color) {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        
        float a = (color >> 24 & 0xFF) / 255.0f;
        float r = (color >> 16 & 0xFF) / 255.0f;
        float g = (color >> 8 & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        
        worldRenderer.begin(GL11.GL_POLYGON, DefaultVertexFormats.POSITION_COLOR);
        
        // 绘制圆角矩形（使用多边形近似圆角）
        int segments = 8; // 每个角的分段数
        
        // 左上角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI + i * (Math.PI / 2) / segments;
            double cx = x + radius + Math.cos(angle) * radius;
            double cy = y + radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 左下角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 1.5 + i * (Math.PI / 2) / segments;
            double cx = x + radius + Math.cos(angle) * radius;
            double cy = y + height - radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 右下角
        for (int i = 0; i <= segments; i++) {
            double angle = i * (Math.PI / 2) / segments;
            double cx = x + width - radius + Math.cos(angle) * radius;
            double cy = y + height - radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        // 右上角
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI / 2 + i * (Math.PI / 2) / segments;
            double cx = x + width - radius + Math.cos(angle) * radius;
            double cy = y + radius + Math.sin(angle) * radius;
            worldRenderer.pos(cx, cy, 0.0).color(r, g, b, a).endVertex();
        }
        
        tessellator.draw();
        
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
    
    /**
     * 绘制圆角矩形阴影
     */
    public static void drawRoundedShadow(int x, int y, int width, int height, int radius, int shadowColor) {
        int shadowSize = 6;
        for (int i = 0; i < shadowSize; i++) {
            float alpha = ((shadowColor >> 24 & 0xFF) / 255.0f) * (1.0f - i / (float) shadowSize);
            int layerColor = (int) (alpha * 255) << 24 | (shadowColor & 0xFFFFFF);
            drawRoundedRect(x - i, y - i, width + i * 2, height + i * 2, radius + i, layerColor);
        }
    }
}
