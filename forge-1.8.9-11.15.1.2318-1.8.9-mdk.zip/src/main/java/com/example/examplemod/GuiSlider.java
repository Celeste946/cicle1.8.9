package com.example.examplemod;

import net.minecraft.client.gui.GuiScreen;
import java.awt.Color;

/**
 * GUI 滑块组件
 */
public class GuiSlider {
    private final String label;
    private float value; // 0.0 - 1.0
    private final float minValue;
    private final float maxValue;
    private boolean dragging = false;
    
    private static final int SLIDER_HEIGHT = 12;
    private static final int BACKGROUND_ALPHA = 230;
    
    public GuiSlider(String label, float currentValue, float minValue, float maxValue) {
        this.label = label;
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.value = (currentValue - minValue) / (maxValue - minValue);
    }
    
    /**
     * 绘制滑块
     */
    public void draw(GuiScreen gui, int x, int y, int width, int mouseX, int mouseY) {
        // 绘制背景
        GuiScreen.drawRect(x, y, x + width, y + SLIDER_HEIGHT, new Color(40, 40, 40, BACKGROUND_ALPHA).getRGB());
        
        // 绘制滑块条
        int sliderWidth = (int) (width * value);
        GuiScreen.drawRect(x, y, x + sliderWidth, y + SLIDER_HEIGHT, new Color(30, 120, 30, BACKGROUND_ALPHA).getRGB());
        
        // 绘制滑块按钮
        int buttonX = x + sliderWidth - 2;
        GuiScreen.drawRect(buttonX, y, buttonX + 4, y + SLIDER_HEIGHT, new Color(200, 200, 200).getRGB());
        
        // 绘制标签和值
        String displayText = label + ": " + String.format("%.1f", getCurrentValue());
        gui.drawString(gui.mc.fontRendererObj, displayText, x + 2, y + 2, 0xFFFFFF);
    }
    
    /**
     * 处理鼠标点击
     */
    public boolean mouseClicked(int x, int y, int width, int mouseX, int mouseY) {
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + SLIDER_HEIGHT) {
            dragging = true;
            updateValue(x, width, mouseX);
            return true;
        }
        return false;
    }
    
    /**
     * 处理鼠标释放
     */
    public void mouseReleased() {
        dragging = false;
    }
    
    /**
     * 处理鼠标拖动
     */
    public void mouseDragged(int x, int width, int mouseX) {
        if (dragging) {
            updateValue(x, width, mouseX);
        }
    }
    
    /**
     * 更新滑块值
     */
    private void updateValue(int x, int width, int mouseX) {
        value = Math.max(0.0f, Math.min(1.0f, (float) (mouseX - x) / width));
    }
    
    /**
     * 获取当前值
     */
    public float getCurrentValue() {
        return minValue + value * (maxValue - minValue);
    }
    
    /**
     * 检查是否正在拖动
     */
    public boolean isDragging() {
        return dragging;
    }
    
    /**
     * 设置当前值
     */
    public void setCurrentValue(float newValue) {
        this.value = (newValue - minValue) / (maxValue - minValue);
        this.value = Math.max(0.0f, Math.min(1.0f, this.value));
    }
    
    /**
     * 获取滑块高度
     */
    public static int getHeight() {
        return SLIDER_HEIGHT;
    }
}
