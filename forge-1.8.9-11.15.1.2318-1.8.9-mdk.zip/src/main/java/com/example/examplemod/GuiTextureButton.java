package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

/**
 * 使用自定义纹理的按钮
 */
public class GuiTextureButton extends GuiButton {
    private static final ResourceLocation BUTTON_TEXTURE = new ResourceLocation("examplemod", "textures/gui/button.png");
    
    public GuiTextureButton(int buttonId, int x, int y, int width, int height, String buttonText) {
        super(buttonId, x, y, width, height, buttonText);
    }
    
    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (this.visible) {
            // 检查鼠标悬停
            this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && 
                          mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
            
            // 启用混合和纹理
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.blendFunc(770, 771);
            
            // 绑定自定义纹理
            mc.getTextureManager().bindTexture(BUTTON_TEXTURE);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            
            // 根据悬停状态选择纹理 V 坐标
            int v = this.hovered ? 20 : 0;
            
            // 绘制按钮（使用标准的 9-patch 方式）
            // 左边部分
            this.drawTexturedModalRect(this.xPosition, this.yPosition, 0, v, 2, 20);
            
            // 中间部分（拉伸）
            this.drawTexturedModalRect(this.xPosition + 2, this.yPosition, 2, v, this.width - 4, 20);
            
            // 右边部分
            this.drawTexturedModalRect(this.xPosition + this.width - 2, this.yPosition, 198, v, 2, 20);
            
            // 绘制文本
            int textColor = this.hovered ? 0xFFFFFF : 0xE0E0E0;
            
            // 文本居中
            int textX = this.xPosition + (this.width - mc.fontRendererObj.getStringWidth(this.displayString)) / 2;
            int textY = this.yPosition + (this.height - 8) / 2;
            
            // 绘制阴影文本
            mc.fontRendererObj.drawStringWithShadow(this.displayString, textX, textY, textColor);
        }
    }
}
