package com.example.examplemod;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ChatComponentText;
import org.lwjgl.input.Mouse;
import java.awt.Color;
import java.io.IOException;

/**
 * 血量卡片设置界面
 */
public class HealthCardGui extends GuiScreen {
    private GuiSlider scaleSlider;
    private GuiTextureButton toggleButton;
    private GuiTextureButton backButton;
    private GuiTextureButton resetButton;
    
    // 拖拽相关
    private boolean isDraggingCard = false;
    private float dragOffsetX = 0;
    private float dragOffsetY = 0;
    
    private static final int BACKGROUND_ALPHA = 200;
    
    @Override
    public void initGui() {
        super.initGui();
        
        int centerX = width / 2;
        int startY = height / 4;
        
        // 创建缩放滑块
        scaleSlider = new GuiSlider("卡片大小", HealthCardRenderer.getInstance().getCardScale(), 0.5f, 2.0f);
        
        // 创建按钮
        toggleButton = new GuiTextureButton(0, centerX - 75, startY + 80, 150, 20, 
            HealthCardRenderer.getInstance().isEnabled() ? "禁用血量卡片" : "启用血量卡片");
        
        resetButton = new GuiTextureButton(2, centerX - 75, startY + 105, 150, 20, "重置位置");
        
        backButton = new GuiTextureButton(1, centerX - 75, startY + 130, 150, 20, "返回");
        
        buttonList.add(toggleButton);
        buttonList.add(resetButton);
        buttonList.add(backButton);
    }
    
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int centerX = width / 2;
        int startY = height / 4;
        int panelWidth = 200;
        int panelHeight = 185;
        int cornerRadius = 8;
        
        // 绘制半透明背景
        drawRect(0, 0, width, height, new Color(0, 0, 0, 120).getRGB());
        
        // 绘制圆角阴影
        GuiShaderEffects.drawRoundedShadow(centerX - panelWidth / 2, startY - 20, 
                panelWidth, panelHeight, cornerRadius, 0x60000000);
        
        // 绘制圆角面板背景
        GuiShaderEffects.drawRoundedRect(centerX - panelWidth / 2, startY - 20, 
                panelWidth, panelHeight, cornerRadius, new Color(30, 30, 35, BACKGROUND_ALPHA).getRGB());
        
        // 绘制标题
        String title = "§l血量卡片设置";
        drawCenteredString(fontRendererObj, title, centerX, startY - 10, 0xFFFFFF);
        
        // 绘制提示信息
        String hint = "§7拖拽卡片预览来调整位置";
        drawCenteredString(fontRendererObj, hint, centerX, startY + 10, 0xAAAAAA);
        
        // 绘制滑块
        scaleSlider.draw(this, centerX - 90, startY + 35, 180, mouseX, mouseY);
        
        // 绘制状态信息
        String status = "状态: " + (HealthCardRenderer.getInstance().isEnabled() ? "§a启用" : "§c禁用");
        drawCenteredString(fontRendererObj, status, centerX, startY + 60, 0xFFFFFF);
        
        // 绘制卡片预览（可拖拽）
        drawCardPreview(mouseX, mouseY);
        
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
    
    /**
     * 绘制可拖拽的卡片预览
     */
    private void drawCardPreview(int mouseX, int mouseY) {
        HealthCardRenderer renderer = HealthCardRenderer.getInstance();
        ScaledResolution resolution = new ScaledResolution(mc);
        
        // 计算卡片位置
        float cardWidth = renderer.getCardWidth();
        float cardHeight = renderer.getCardHeight();
        float cardX = (resolution.getScaledWidth() / 2.0f) + renderer.getCardX() - (cardWidth / 2.0f);
        float cardY = renderer.getCardY();
        
        // 检查鼠标是否悬停在卡片上
        boolean isHovered = mouseX >= cardX && mouseX <= cardX + cardWidth &&
                           mouseY >= cardY && mouseY <= cardY + cardHeight;
        
        // 绘制卡片边框（高亮显示可拖拽区域）
        int borderColor = isDraggingCard ? 0xFF00FF00 : (isHovered ? 0xFFFFFF00 : 0x80FFFFFF);
        drawRect((int)cardX - 2, (int)cardY - 2, 
                (int)(cardX + cardWidth) + 2, (int)(cardY + cardHeight) + 2, borderColor);
        
        // 绘制半透明卡片背景（预览）
        drawRect((int)cardX, (int)cardY, 
                (int)(cardX + cardWidth), (int)(cardY + cardHeight), 
                new Color(123, 66, 245, 150).getRGB());
        
        // 绘制卡片文本
        String previewText = "血量卡片";
        int textWidth = fontRendererObj.getStringWidth(previewText);
        float textX = cardX + (cardWidth - textWidth) / 2.0f;
        float textY = cardY + (cardHeight - 8) / 2.0f;
        fontRendererObj.drawStringWithShadow(previewText, textX, textY, 0xFFFFFF);
        
        // 绘制拖拽提示
        if (isHovered && !isDraggingCard) {
            String dragHint = "§e点击拖拽";
            int hintWidth = fontRendererObj.getStringWidth(dragHint);
            fontRendererObj.drawStringWithShadow(dragHint, 
                cardX + (cardWidth - hintWidth) / 2.0f, 
                cardY + cardHeight + 5, 0xFFFFFF);
        }
    }
    
    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        
        int centerX = width / 2;
        int startY = height / 4;
        
        // 处理滑块点击
        scaleSlider.mouseClicked(centerX - 90, startY + 35, 180, mouseX, mouseY);
        
        // 检查是否点击卡片预览
        if (mouseButton == 0) {
            HealthCardRenderer renderer = HealthCardRenderer.getInstance();
            ScaledResolution resolution = new ScaledResolution(mc);
            
            float cardWidth = renderer.getCardWidth();
            float cardHeight = renderer.getCardHeight();
            float cardX = (resolution.getScaledWidth() / 2.0f) + renderer.getCardX() - (cardWidth / 2.0f);
            float cardY = renderer.getCardY();
            
            if (mouseX >= cardX && mouseX <= cardX + cardWidth &&
                mouseY >= cardY && mouseY <= cardY + cardHeight) {
                isDraggingCard = true;
                dragOffsetX = mouseX - cardX - cardWidth / 2.0f;
                dragOffsetY = mouseY - cardY;
            }
        }
    }
    
    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        
        // 更新设置
        if (scaleSlider.isDragging()) {
            HealthCardRenderer.getInstance().setCardScale(scaleSlider.getCurrentValue());
        }
        
        scaleSlider.mouseReleased();
        isDraggingCard = false;
    }
    
    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        super.mouseClickMove(mouseX, mouseY, clickedMouseButton, timeSinceLastClick);
        
        int centerX = width / 2;
        
        // 处理滑块拖动
        scaleSlider.mouseDragged(centerX - 90, 180, mouseX);
        HealthCardRenderer.getInstance().setCardScale(scaleSlider.getCurrentValue());
        
        // 处理卡片拖动
        if (isDraggingCard) {
            ScaledResolution resolution = new ScaledResolution(mc);
            HealthCardRenderer renderer = HealthCardRenderer.getInstance();
            
            // 计算新位置（相对于屏幕中心）
            float newCardX = (mouseX - dragOffsetX) - (resolution.getScaledWidth() / 2.0f);
            float newCardY = mouseY - dragOffsetY;
            
            renderer.setCardX(newCardX);
            renderer.setCardY(newCardY);
        }
    }
    
    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        
        // 处理鼠标滚轮缩放
        int wheel = Mouse.getEventDWheel();
        if (wheel != 0) {
            HealthCardRenderer renderer = HealthCardRenderer.getInstance();
            float currentScale = renderer.getCardScale();
            float newScale = currentScale + (wheel > 0 ? 0.1f : -0.1f);
            renderer.setCardScale(newScale);
            scaleSlider.setCurrentValue(newScale);
        }
    }
    
    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 0) {
            // 切换血量卡片
            HealthCardRenderer.getInstance().toggle();
            button.displayString = HealthCardRenderer.getInstance().isEnabled() ? "禁用血量卡片" : "启用血量卡片";
            
            if (mc.thePlayer != null) {
                String status = HealthCardRenderer.getInstance().isEnabled() ? "已启用" : "已禁用";
                mc.thePlayer.addChatMessage(new ChatComponentText("§a血量卡片 " + status));
            }
        } else if (button.id == 1) {
            // 返回主界面
            mc.displayGuiScreen(new ExampleGui());
        } else if (button.id == 2) {
            // 重置位置
            HealthCardRenderer.getInstance().setCardX(0);
            HealthCardRenderer.getInstance().setCardY(20.0f);
            HealthCardRenderer.getInstance().setCardScale(1.0f);
            scaleSlider.setCurrentValue(1.0f);
            
            if (mc.thePlayer != null) {
                mc.thePlayer.addChatMessage(new ChatComponentText("§a血量卡片位置已重置"));
            }
        }
    }
    
    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
