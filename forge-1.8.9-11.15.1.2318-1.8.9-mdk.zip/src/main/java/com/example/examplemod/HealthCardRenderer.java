package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * 血量条渲染器
 * 使用 OpenGL 绘制目标的血量条
 */
public class HealthCardRenderer {
    private static HealthCardRenderer instance;
    private boolean enabled = true; // 默认启用
    
    private static final float DEFAULT_BAR_WIDTH = 120.0f;
    private static final float DEFAULT_BAR_HEIGHT = 20.0f;
    
    // 可配置的血条属性
    private float barX = 0; // 相对于屏幕中心的X偏移
    private float barY = 20.0f; // 距离屏幕顶部的Y位置
    private float barScale = 1.0f; // 血条缩放比例 (0.5 - 2.0)
    
    // 当前目标实体（用于在屏幕上显示）
    private EntityLivingBase currentTarget = null;
    
    private HealthCardRenderer() {
        // 私有构造函数，单例模式
    }
    
    public static HealthCardRenderer getInstance() {
        if (instance == null) {
            instance = new HealthCardRenderer();
        }
        return instance;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public void toggle() {
        this.enabled = !this.enabled;
    }
    
    // 位置和大小的 getter/setter
    public float getCardX() {
        return barX;
    }
    
    public void setCardX(float cardX) {
        this.barX = cardX;
    }
    
    public float getCardY() {
        return barY;
    }
    
    public void setCardY(float cardY) {
        this.barY = Math.max(0, cardY);
    }
    
    public float getCardScale() {
        return barScale;
    }
    
    public void setCardScale(float scale) {
        this.barScale = Math.max(0.5f, Math.min(scale, 2.0f));
    }
    
    public float getCardWidth() {
        return DEFAULT_BAR_WIDTH * barScale;
    }
    
    public float getCardHeight() {
        return DEFAULT_BAR_HEIGHT * barScale;
    }
    
    /**
     * 监听游戏覆盖层渲染事件，在屏幕上显示血量条
     */
    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Post event) {
        // 首先检查 GUI 状态，在任何 OpenGL 操作之前返回
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen != null) return;
        
        if (!enabled) return;
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        
        if (mc.thePlayer == null || mc.theWorld == null) return;
        
        // 查找当前攻击目标
        updateCurrentTarget();
        
        // 如果有目标，渲染血量条到屏幕
        if (currentTarget != null && currentTarget.isEntityAlive()) {
            renderHealthBarOnScreen(event.resolution);
        }
    }
    
    /**
     * 更新当前攻击目标
     */
    private void updateCurrentTarget() {
        if (!AutoAttack.getInstance().isEnabled()) {
            currentTarget = null;
            return;
        }
        
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) {
            currentTarget = null;
            return;
        }
        
        // 查找最近的攻击范围内的目标
        EntityLivingBase closestTarget = null;
        double closestDistance = Double.MAX_VALUE;
        
        for (Object obj : mc.theWorld.loadedEntityList) {
            if (!(obj instanceof EntityLivingBase)) continue;
            EntityLivingBase entity = (EntityLivingBase) obj;
            
            if (entity == mc.thePlayer) continue;
            if (!entity.isEntityAlive()) continue;
            
            double distance = mc.thePlayer.getDistanceToEntity(entity);
            if (distance <= AutoAttack.getInstance().getAttackRange() && distance < closestDistance) {
                closestTarget = entity;
                closestDistance = distance;
            }
        }
        
        currentTarget = closestTarget;
    }
    
    /**
     * 根据血量百分比获取血条颜色
     */
    private int getHealthBarColor(float healthPercent) {
        if (healthPercent > 0.5f) {
            // 绿色 -> 黄色 (100% - 50%)
            float ratio = (healthPercent - 0.5f) * 2.0f;
            int red = (int) ((1.0f - ratio) * 255);
            int green = 255;
            return (255 << 24) | (red << 16) | (green << 8) | 0;
        } else {
            // 黄色 -> 红色 (50% - 0%)
            float ratio = healthPercent * 2.0f;
            int red = 255;
            int green = (int) (ratio * 255);
            return (255 << 24) | (red << 16) | (green << 8) | 0;
        }
    }
    
    /**
     * 在屏幕上渲染血量条（2D HUD）
     */
    private void renderHealthBarOnScreen(ScaledResolution resolution) {
        // 计算血量百分比
        float health = currentTarget.getHealth();
        float maxHealth = currentTarget.getMaxHealth();
        float healthPercent = Math.max(0.0f, Math.min(1.0f, health / maxHealth));
        
        // 计算屏幕中心位置
        int screenWidth = resolution.getScaledWidth();
        
        // 使用可配置的位置（相对于屏幕中心）
        float barWidth = getCardWidth();
        float barHeight = getCardHeight();
        float renderX = (screenWidth / 2.0f) + barX - (barWidth / 2.0f);
        float renderY = barY;
        
        // 保存当前状态
        GlStateManager.pushMatrix();
        
        // 设置渲染状态
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.disableTexture2D();
        
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        
        // 绘制背景（黑色半透明）
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addColoredQuad(worldRenderer, renderX - 2, renderY - 2, 
                      renderX + barWidth + 2, renderY + barHeight + 2, 
                      0, 0, 0, 180);
        tessellator.draw();
        
        // 绘制边框（白色）
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addColoredQuad(worldRenderer, renderX - 1, renderY - 1, 
                      renderX + barWidth + 1, renderY + barHeight + 1, 
                      255, 255, 255, 255);
        tessellator.draw();
        
        // 绘制内部背景（深灰色）
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addColoredQuad(worldRenderer, renderX, renderY, 
                      renderX + barWidth, renderY + barHeight, 
                      40, 40, 40, 255);
        tessellator.draw();
        
        // 绘制血量条（根据血量百分比变色）
        float healthBarWidth = barWidth * healthPercent;
        int healthColor = getHealthBarColor(healthPercent);
        int r = (healthColor >> 16) & 0xFF;
        int g = (healthColor >> 8) & 0xFF;
        int b = healthColor & 0xFF;
        
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        addColoredQuad(worldRenderer, renderX, renderY, 
                      renderX + healthBarWidth, renderY + barHeight, 
                      r, g, b, 255);
        tessellator.draw();
        
        // 绘制光泽效果（顶部渐变）
        worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        float glossHeight = barHeight * 0.4f;
        addGradientQuad(worldRenderer, renderX, renderY, 
                       renderX + healthBarWidth, renderY + glossHeight, 
                       255, 255, 255, 60, 255, 255, 255, 0);
        tessellator.draw();
        
        // 恢复纹理
        GlStateManager.enableTexture2D();
        
        // 绘制血量文本（在血条中央）
        FontRenderer fontRenderer = Minecraft.getMinecraft().fontRendererObj;
        String healthText = String.format("%.1f / %.1f", health, maxHealth);
        int textWidth = fontRenderer.getStringWidth(healthText);
        float textX = renderX + (barWidth - textWidth) / 2.0f;
        float textY = renderY + (barHeight - 8) / 2.0f;
        
        fontRenderer.drawStringWithShadow(healthText, textX, textY, 0xFFFFFF);
        
        // 绘制目标名称（在血条上方）
        String targetName = currentTarget.getName();
        int nameWidth = fontRenderer.getStringWidth(targetName);
        float nameX = renderX + (barWidth - nameWidth) / 2.0f;
        float nameY = renderY - 12;
        
        fontRenderer.drawStringWithShadow(targetName, nameX, nameY, 0xFFFFFF);
        
        // 恢复状态
        GlStateManager.enableDepth();
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        
        GlStateManager.popMatrix();
    }
    
    /**
     * 添加纯色四边形
     */
    private void addColoredQuad(WorldRenderer renderer, float x1, float y1, float x2, float y2, 
                                int r, int g, int b, int a) {
        renderer.pos(x1, y2, 0).color(r, g, b, a).endVertex();
        renderer.pos(x2, y2, 0).color(r, g, b, a).endVertex();
        renderer.pos(x2, y1, 0).color(r, g, b, a).endVertex();
        renderer.pos(x1, y1, 0).color(r, g, b, a).endVertex();
    }
    
    /**
     * 添加渐变四边形（从上到下）
     */
    private void addGradientQuad(WorldRenderer renderer, float x1, float y1, float x2, float y2,
                                 int r1, int g1, int b1, int a1, int r2, int g2, int b2, int a2) {
        renderer.pos(x1, y2, 0).color(r2, g2, b2, a2).endVertex();
        renderer.pos(x2, y2, 0).color(r2, g2, b2, a2).endVertex();
        renderer.pos(x2, y1, 0).color(r1, g1, b1, a1).endVertex();
        renderer.pos(x1, y1, 0).color(r1, g1, b1, a1).endVertex();
    }
}
