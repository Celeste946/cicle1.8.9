package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 受攻击白圈渲染器
 * 在受到攻击的实体周围渲染白色圆圈
 */
public class HitCircleRenderer {
    private static HitCircleRenderer instance;
    
    // 存储受攻击实体和攻击时间
    private Map<EntityLivingBase, Long> hitEntities = new HashMap<>();
    private static final long CIRCLE_DURATION = 500; // 圆圈显示时长（毫秒）
    
    private HitCircleRenderer() {
        // 私有构造函数，单例模式
    }
    
    public static HitCircleRenderer getInstance() {
        if (instance == null) {
            instance = new HitCircleRenderer();
        }
        return instance;
    }
    
    /**
     * 记录实体被攻击
     */
    public void onEntityHit(EntityLivingBase entity) {
        if (entity != null && AutoAttack.getInstance().isShowHitCircle()) {
            hitEntities.put(entity, System.currentTimeMillis());
        }
    }
    
    /**
     * 渲染所有受攻击实体的白圈
     */
    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        // 检查 GUI 状态 - 如果 GUI 打开，立即返回
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen != null) {
            return;
        }
        
        if (!AutoAttack.getInstance().isShowHitCircle()) {
            hitEntities.clear();
            return;
        }
        
        if (mc.thePlayer == null || mc.getRenderViewEntity() == null) return;
        
        long currentTime = System.currentTimeMillis();
        RenderManager renderManager = mc.getRenderManager();
        
        // 使用 try-finally 确保状态恢复
        try {
            // 清理过期的实体
            Iterator<Map.Entry<EntityLivingBase, Long>> iterator = hitEntities.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<EntityLivingBase, Long> entry = iterator.next();
                EntityLivingBase entity = entry.getKey();
                long hitTime = entry.getValue();
                
                // 移除过期或死亡的实体
                if (currentTime - hitTime > CIRCLE_DURATION || !entity.isEntityAlive()) {
                    iterator.remove();
                    continue;
                }
                
                // 渲染白圈
                renderHitCircle(entity, event.partialTicks, renderManager, currentTime - hitTime);
            }
        } catch (Exception e) {
            // 记录错误但不崩溃
            System.err.println("HitCircleRenderer 渲染错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 渲染单个实体的白圈
     */
    private void renderHitCircle(EntityLivingBase entity, float partialTicks, RenderManager renderManager, long timeSinceHit) {
        // 计算实体位置
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - renderManager.viewerPosX;
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - renderManager.viewerPosY;
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - renderManager.viewerPosZ;
        
        // 计算透明度（随时间淡出）
        float alpha = 1.0f - (timeSinceHit / (float) CIRCLE_DURATION);
        alpha = Math.max(0.0f, Math.min(1.0f, alpha));
        
        // 计算圆圈大小（随时间扩大）
        float baseRadius = entity.width * 0.8f;
        float expandFactor = 1.0f + (timeSinceHit / (float) CIRCLE_DURATION) * 0.5f;
        float radius = baseRadius * expandFactor;
        
        // 保存状态
        GlStateManager.pushMatrix();
        
        try {
            GlStateManager.translate(x, y + 0.01, z);
            GlStateManager.rotate(-renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate(90.0f, 1.0f, 0.0f, 0.0f);
            
            // 设置渲染状态
            GlStateManager.disableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            
            // 绘制白色圆圈
            Tessellator tessellator = Tessellator.getInstance();
            WorldRenderer worldRenderer = tessellator.getWorldRenderer();
            
            worldRenderer.begin(GL11.GL_LINE_LOOP, DefaultVertexFormats.POSITION_COLOR);
            
            int segments = 64; // 圆圈分段数
            for (int i = 0; i < segments; i++) {
                double angle = 2 * Math.PI * i / segments;
                double circleX = Math.cos(angle) * radius;
                double circleZ = Math.sin(angle) * radius;
                worldRenderer.pos(circleX, circleZ, 0.0).color(1.0f, 1.0f, 1.0f, alpha).endVertex();
            }
            
            tessellator.draw();
            
            // 绘制第二个圆圈（稍大，增强效果）
            worldRenderer.begin(GL11.GL_LINE_LOOP, DefaultVertexFormats.POSITION_COLOR);
            
            float radius2 = radius * 1.1f;
            float alpha2 = alpha * 0.5f;
            for (int i = 0; i < segments; i++) {
                double angle = 2 * Math.PI * i / segments;
                double circleX = Math.cos(angle) * radius2;
                double circleZ = Math.sin(angle) * radius2;
                worldRenderer.pos(circleX, circleZ, 0.0).color(1.0f, 1.0f, 1.0f, alpha2).endVertex();
            }
            
            tessellator.draw();
        } finally {
            // 确保所有 OpenGL 状态都被恢复
            GlStateManager.disableBlend();
            GlStateManager.enableDepth();
            GlStateManager.enableLighting();
            GlStateManager.enableTexture2D();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.popMatrix();
        }
    }
}
