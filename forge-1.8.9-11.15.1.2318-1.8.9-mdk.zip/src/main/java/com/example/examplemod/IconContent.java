package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/**
 * 图标内容 - 在灵动岛中显示图标
 */
public class IconContent implements IslandContent {
    private ResourceLocation icon;
    private int size;
    private int priority;
    
    public IconContent(ResourceLocation icon, int size, int priority) {
        this.icon = icon;
        this.size = size;
        this.priority = priority;
    }
    
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight) {
        if (icon == null) {
            System.err.println("[IconContent] 警告：图标 ResourceLocation 为 null");
            return;
        }
        
        try {
            GlStateManager.enableBlend();
            GlStateManager.enableTexture2D();
            GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            
            // 尝试绑定纹理
            try {
                Minecraft.getMinecraft().getTextureManager().bindTexture(icon);
            } catch (Exception e) {
                System.err.println("[IconContent] 纹理绑定失败 - 路径: " + icon.toString());
                System.err.println("[IconContent] 请检查：");
                System.err.println("  1. 文件路径是否正确（区分大小写）");
                System.err.println("  2. 文件是否存在于 src/main/resources/assets/" + icon.getResourceDomain() + "/textures/");
                System.err.println("  3. 文件名是否包含 .png 扩展名");
                throw e;
            }
            
            Tessellator tessellator = Tessellator.getInstance();
            WorldRenderer worldRenderer = tessellator.getWorldRenderer();
            
            worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
            worldRenderer.pos(x, y + size, 0.0).tex(0, 1).endVertex();
            worldRenderer.pos(x + size, y + size, 0.0).tex(1, 1).endVertex();
            worldRenderer.pos(x + size, y, 0.0).tex(1, 0).endVertex();
            worldRenderer.pos(x, y, 0.0).tex(0, 0).endVertex();
            tessellator.draw();
            
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.disableBlend();
        } catch (Exception e) {
            System.err.println("[IconContent] 渲染失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    @Override
    public float getPreferredWidth() {
        return size;
    }
    
    @Override
    public float getPreferredHeight() {
        return size;
    }
    
    @Override
    public int getPriority() {
        return priority;
    }
    
    @Override
    public boolean shouldDisplay() {
        return icon != null;
    }
    
    public void setIcon(ResourceLocation icon) {
        this.icon = icon;
    }
    
    public ResourceLocation getIcon() {
        return icon;
    }
}
