package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * 背包行走功能
 * 允许玩家在打开背包或其他GUI时继续移动
 * 默认始终启用
 */
public class InventoryMove {
    private static InventoryMove instance;
    
    // 需要处理的移动按键 - 延迟初始化
    private KeyBinding[] movementKeys = null;
    
    private InventoryMove() {
        // 私有构造函数，单例模式
    }
    
    /**
     * 获取移动按键数组（延迟初始化）
     */
    private KeyBinding[] getMovementKeys() {
        if (movementKeys == null) {
            Minecraft mc = Minecraft.getMinecraft();
            movementKeys = new KeyBinding[]{
                mc.gameSettings.keyBindForward,
                mc.gameSettings.keyBindBack,
                mc.gameSettings.keyBindLeft,
                mc.gameSettings.keyBindRight,
                mc.gameSettings.keyBindJump,
                mc.gameSettings.keyBindSprint
            };
        }
        return movementKeys;
    }
    
    /**
     * 获取单例实例
     */
    public static InventoryMove getInstance() {
        if (instance == null) {
            instance = new InventoryMove();
        }
        return instance;
    }
    
    /**
     * 每个 tick 更新按键状态
     */
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;
        
        GuiScreen currentScreen = mc.currentScreen;
        
        // 如果没有打开GUI，不需要处理
        if (currentScreen == null) return;
        
        // 排除聊天界面和暂停菜单（这些界面不应该允许移动）
        if (currentScreen instanceof GuiChat || currentScreen instanceof GuiIngameMenu) {
            return;
        }
        
        // 更新所有移动按键的状态
        for (KeyBinding key : getMovementKeys()) {
            if (key == null) continue;
            
            // 检查按键是否被按下
            boolean isKeyDown = Keyboard.isKeyDown(key.getKeyCode());
            
            // 更新按键状态
            KeyBinding.setKeyBindState(key.getKeyCode(), isKeyDown);
        }
    }
}
