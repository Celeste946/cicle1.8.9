package com.example.examplemod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * 灵动岛配置类
 */
public class IslandConfig {
    // 显示设置
    private boolean enabled = true;
    private float offsetX = 0.0f;
    private float offsetY = 8.0f;  // 稍微靠近顶部
    private float scale = 0.85f;   // 默认缩小到 85%
    private float alpha = 0.92f;   // 稍微提高透明度
    
    // 动画设置
    private long transitionDuration = 400;
    
    // 内容设置
    private boolean showCoordinates = true;
    private boolean showHealth = true;
    private boolean showTime = false;
    private boolean showTarget = true;
    
    // 视觉设置
    private boolean enableShadow = true;
    private boolean enableGlow = false; // 关闭发光效果，更简洁
    private float cornerRadius = 18.0f; // 适配更小尺寸的圆角
    private int backgroundColor = 0xDD000000; // 深色半透明背景（更接近 iOS 风格）
    
    // 调试设置
    private boolean debugMode = false;
    
    // Getter/Setter
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public float getOffsetX() {
        return offsetX;
    }
    
    public void setOffsetX(float offsetX) {
        this.offsetX = offsetX;
    }
    
    public float getOffsetY() {
        return offsetY;
    }
    
    public void setOffsetY(float offsetY) {
        this.offsetY = Math.max(0, offsetY);
    }
    
    public float getScale() {
        return scale;
    }
    
    public void setScale(float scale) {
        this.scale = Math.max(0.5f, Math.min(scale, 2.0f));
    }
    
    public float getAlpha() {
        return alpha;
    }
    
    public void setAlpha(float alpha) {
        this.alpha = Math.max(0.0f, Math.min(alpha, 1.0f));
    }
    
    public long getTransitionDuration() {
        return transitionDuration;
    }
    
    public void setTransitionDuration(long transitionDuration) {
        this.transitionDuration = Math.max(100, transitionDuration);
    }
    
    public boolean isShowCoordinates() {
        return showCoordinates;
    }
    
    public void setShowCoordinates(boolean showCoordinates) {
        this.showCoordinates = showCoordinates;
    }
    
    public boolean isShowHealth() {
        return showHealth;
    }
    
    public void setShowHealth(boolean showHealth) {
        this.showHealth = showHealth;
    }
    
    public boolean isShowTime() {
        return showTime;
    }
    
    public void setShowTime(boolean showTime) {
        this.showTime = showTime;
    }
    
    public boolean isShowTarget() {
        return showTarget;
    }
    
    public void setShowTarget(boolean showTarget) {
        this.showTarget = showTarget;
    }
    
    public boolean isEnableShadow() {
        return enableShadow;
    }
    
    public void setEnableShadow(boolean enableShadow) {
        this.enableShadow = enableShadow;
    }
    
    public boolean isEnableGlow() {
        return enableGlow;
    }
    
    public void setEnableGlow(boolean enableGlow) {
        this.enableGlow = enableGlow;
    }
    
    public float getCornerRadius() {
        return cornerRadius;
    }
    
    public void setCornerRadius(float cornerRadius) {
        this.cornerRadius = Math.max(0, cornerRadius);
    }
    
    public int getBackgroundColor() {
        return backgroundColor;
    }
    
    public void setBackgroundColor(int backgroundColor) {
        this.backgroundColor = backgroundColor;
    }
    
    public boolean isDebugMode() {
        return debugMode;
    }
    
    public void setDebugMode(boolean debugMode) {
        this.debugMode = debugMode;
    }
    
    /**
     * 从文件加载配置
     */
    public void load() {
        File configFile = getConfigFile();
        if (!configFile.exists()) {
            System.out.println("[DynamicIsland] 配置文件不存在，使用默认配置");
            save(); // 保存默认配置
            return;
        }
        
        try (FileReader reader = new FileReader(configFile)) {
            Gson gson = new Gson();
            IslandConfig loaded = gson.fromJson(reader, IslandConfig.class);
            
            // 复制加载的配置
            this.enabled = loaded.enabled;
            this.offsetX = loaded.offsetX;
            this.offsetY = loaded.offsetY;
            this.scale = loaded.scale;
            this.alpha = loaded.alpha;
            this.transitionDuration = loaded.transitionDuration;
            this.showCoordinates = loaded.showCoordinates;
            this.showHealth = loaded.showHealth;
            this.showTime = loaded.showTime;
            this.showTarget = loaded.showTarget;
            this.enableShadow = loaded.enableShadow;
            this.enableGlow = loaded.enableGlow;
            this.cornerRadius = loaded.cornerRadius;
            this.backgroundColor = loaded.backgroundColor;
            this.debugMode = loaded.debugMode;
            
            System.out.println("[DynamicIsland] 配置加载成功");
        } catch (Exception e) {
            System.err.println("[DynamicIsland] 配置加载失败，使用默认配置: " + e.getMessage());
        }
    }
    
    /**
     * 保存配置到文件
     */
    public void save() {
        File configFile = getConfigFile();
        File configDir = configFile.getParentFile();
        
        if (!configDir.exists()) {
            configDir.mkdirs();
        }
        
        try (FileWriter writer = new FileWriter(configFile)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(this, writer);
            System.out.println("[DynamicIsland] 配置保存成功");
        } catch (Exception e) {
            System.err.println("[DynamicIsland] 配置保存失败: " + e.getMessage());
        }
    }
    
    /**
     * 获取配置文件路径
     */
    private File getConfigFile() {
        return new File("config/examplemod/dynamic_island.json");
    }
}
