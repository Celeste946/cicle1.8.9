package com.example.examplemod;

/**
 * 灵动岛内容接口
 * 所有显示在灵动岛中的内容都需要实现此接口
 */
public interface IslandContent {
    /**
     * 渲染内容
     */
    void render(float x, float y, float maxWidth, float maxHeight);
    
    /**
     * 获取首选宽度
     */
    float getPreferredWidth();
    
    /**
     * 获取首选高度
     */
    float getPreferredHeight();
    
    /**
     * 获取优先级（数字越小优先级越高）
     */
    int getPriority();
    
    /**
     * 是否应该显示
     */
    boolean shouldDisplay();
}
