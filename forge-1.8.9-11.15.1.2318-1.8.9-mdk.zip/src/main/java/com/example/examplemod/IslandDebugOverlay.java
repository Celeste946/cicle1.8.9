package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;

/**
 * 灵动岛调试覆盖层
 * 显示调试信息和性能数据
 */
public class IslandDebugOverlay {
    private DynamicIsland island;
    private IslandProfiler profiler;
    
    public IslandDebugOverlay(DynamicIsland island) {
        this.island = island;
        this.profiler = new IslandProfiler();
    }
    
    /**
     * 渲染调试信息
     */
    public void render(ScaledResolution resolution) {
        IslandConfig config = island.getConfig();
        if (!config.isDebugMode()) {
            return;
        }
        
        FontRenderer fontRenderer = Minecraft.getMinecraft().fontRendererObj;
        int x = 10;
        int y = 10;
        int lineHeight = 10;
        int line = 0;
        
        // 标题
        fontRenderer.drawStringWithShadow("§e灵动岛调试信息", x, y + line++ * lineHeight, 0xFFFFFF);
        line++;
        
        // 状态信息
        fontRenderer.drawStringWithShadow("§7状态: §f" + island.getState().name(), x, y + line++ * lineHeight, 0xFFFFFF);
        fontRenderer.drawStringWithShadow("§7启用: §f" + island.isEnabled(), x, y + line++ * lineHeight, 0xFFFFFF);
        
        // 动画信息（简化显示）
        fontRenderer.drawStringWithShadow("§7动画: §f活跃", x, y + line++ * lineHeight, 0xFFFFFF);
        
        // 内容信息
        ContentManager contentManager = island.getContentManager();
        if (contentManager != null) {
            int contentCount = contentManager.getContents().size();
            fontRenderer.drawStringWithShadow("§7内容数量: §f" + contentCount, x, y + line++ * lineHeight, 0xFFFFFF);
        }
        
        // 配置信息
        line++;
        fontRenderer.drawStringWithShadow("§7偏移: §f" + String.format("%.0f, %.0f", config.getOffsetX(), config.getOffsetY()), x, y + line++ * lineHeight, 0xFFFFFF);
        fontRenderer.drawStringWithShadow("§7缩放: §f" + String.format("%.2f", config.getScale()), x, y + line++ * lineHeight, 0xFFFFFF);
        fontRenderer.drawStringWithShadow("§7透明度: §f" + String.format("%.2f", config.getAlpha()), x, y + line++ * lineHeight, 0xFFFFFF);
        
        // 性能信息
        line++;
        fontRenderer.drawStringWithShadow("§7渲染时间: §f" + profiler.getRenderTime() + "ms", x, y + line++ * lineHeight, 0xFFFFFF);
        fontRenderer.drawStringWithShadow("§7更新时间: §f" + profiler.getUpdateTime() + "ms", x, y + line++ * lineHeight, 0xFFFFFF);
        fontRenderer.drawStringWithShadow("§7帧数: §f" + profiler.getFrameCount(), x, y + line++ * lineHeight, 0xFFFFFF);
    }
    
    public IslandProfiler getProfiler() {
        return profiler;
    }
}
