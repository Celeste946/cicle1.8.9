package com.example.examplemod;

/**
 * 灵动岛性能分析器
 * 监控渲染和更新性能
 */
public class IslandProfiler {
    private long renderStartTime;
    private long renderTime;
    private long updateStartTime;
    private long updateTime;
    private int frameCount;
    
    public IslandProfiler() {
        this.renderTime = 0;
        this.updateTime = 0;
        this.frameCount = 0;
    }
    
    /**
     * 开始渲染计时
     */
    public void startRender() {
        renderStartTime = System.nanoTime();
    }
    
    /**
     * 结束渲染计时
     */
    public void endRender() {
        renderTime = (System.nanoTime() - renderStartTime) / 1000000; // 转换为毫秒
        frameCount++;
    }
    
    /**
     * 开始更新计时
     */
    public void startUpdate() {
        updateStartTime = System.nanoTime();
    }
    
    /**
     * 结束更新计时
     */
    public void endUpdate() {
        updateTime = (System.nanoTime() - updateStartTime) / 1000000; // 转换为毫秒
    }
    
    /**
     * 获取渲染时间（毫秒）
     */
    public long getRenderTime() {
        return renderTime;
    }
    
    /**
     * 获取更新时间（毫秒）
     */
    public long getUpdateTime() {
        return updateTime;
    }
    
    /**
     * 获取帧数
     */
    public int getFrameCount() {
        return frameCount;
    }
    
    /**
     * 打印统计信息
     */
    public void printStats() {
        System.out.println("[IslandProfiler] 统计信息:");
        System.out.println("  渲染时间: " + renderTime + "ms");
        System.out.println("  更新时间: " + updateTime + "ms");
        System.out.println("  总帧数: " + frameCount);
    }
    
    /**
     * 重置统计
     */
    public void reset() {
        renderTime = 0;
        updateTime = 0;
        frameCount = 0;
    }
}
