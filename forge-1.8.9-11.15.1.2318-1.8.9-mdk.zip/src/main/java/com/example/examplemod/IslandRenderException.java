package com.example.examplemod;

/**
 * 灵动岛渲染异常类
 */
public class IslandRenderException extends DynamicIslandException {
    public IslandRenderException(String message, Throwable cause) {
        super(message, cause);
    }
}
