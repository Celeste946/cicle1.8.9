package com.example.examplemod;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

import java.util.List;

/**
 * 灵动岛渲染器 - 负责渲染灵动岛的所有视觉元素
 */
public class IslandRenderer {
    private ResourceLocation backgroundTexture;
    private EffectRenderer effectRenderer;
    private IslandConfig config;
    private AnimationController animationController;
    
    private float currentWidth;
    private float currentHeight;
    private float currentAlpha;
    
    private boolean textureLoaded;
    
    public IslandRenderer(IslandConfig config) {
        this.config = config;
        this.effectRenderer = new EffectRenderer();
        this.textureLoaded = false;
        this.currentAlpha = 1.0f;
    }
    
    public void setAnimationController(AnimationController controller) {
        this.animationController = controller;
    }
    
    /**
     * 加载纹理
     */
    public void loadTextures() {
        // 暂时禁用纹理加载，使用纯色背景
        // 纹理加载存在问题，需要进一步调试
        textureLoaded = false;
        System.out.println("[IslandRenderer] 使用纯色圆角矩形背景（纹理已禁用）");
        
        // 如果需要启用纹理，取消下面的注释并注释掉上面的代码
       
        try {
            System.out.println("[IslandRenderer] 开始加载背景纹理...");
            backgroundTexture = new ResourceLocation("examplemod", "gui/ldd.png");
            textureLoaded = TextureValidator.validateTexture(backgroundTexture);
            
            if (textureLoaded) {
                System.out.println("[IslandRenderer] ✓ 纹理加载成功");
            } else {
                System.err.println("[IslandRenderer] ✗ 纹理加载失败，使用纯色背景");
            }
        } catch (Exception e) {
            System.err.println("[IslandRenderer] 纹理加载异常: " + e.getMessage());
            textureLoaded = false;
        }
       
    }
    
    /**
     * 设置背景纹理
     */
    public void setBackgroundTexture(ResourceLocation texture) {
        this.backgroundTexture = texture;
        this.textureLoaded = false;
    }
    
    /**
     * 主渲染方法
     */
    public void render(ScaledResolution resolution, IslandState state, List<IslandContent> contents, float animationProgress) {
        if (!config.isEnabled()) {
            return;
        }
        
        try {
            // 保存 OpenGL 状态
            GlStateManager.pushMatrix();
            
            // 从动画控制器获取当前尺寸
            if (animationController != null) {
                currentWidth = animationController.getCurrentWidth() * config.getScale();
                currentHeight = animationController.getCurrentHeight() * config.getScale();
            } else {
                currentWidth = state.getWidth() * config.getScale();
                currentHeight = state.getHeight() * config.getScale();
            }
            
            currentAlpha = config.getAlpha();
            
            // 计算位置
            float x = calculateX(resolution, currentWidth);
            float y = calculateY(resolution);
            
            // 渲染效果和背景
            renderEffects(x, y, currentWidth, currentHeight);
            renderBackground(x, y, currentWidth, currentHeight, currentAlpha);
            
            // 渲染内容
            if (contents != null && !contents.isEmpty()) {
                renderContents(x, y, currentWidth, currentHeight, contents);
            }
            
            // 恢复 OpenGL 状态
            GlStateManager.popMatrix();
            
        } catch (Exception e) {
            System.err.println("[IslandRenderer] 渲染失败: " + e.getMessage());
            e.printStackTrace();
            // 恢复状态
            GlStateManager.popMatrix();
        }
    }
    
    /**
     * 渲染背景（支持纹理和纯色）
     */
    private void renderBackground(float x, float y, float width, float height, float alpha) {
        // 如果纹理加载成功，使用纹理背景
        if (textureLoaded && backgroundTexture != null) {
            renderTextureBackground(x, y, width, height, alpha);
        } else {
            // 否则使用纯色圆角矩形背景
            renderSolidBackground(x, y, width, height, alpha);
        }
    }
    
    /**
     * 渲染纹理背景（简单拉伸）
     */
    private void renderTextureBackground(float x, float y, float width, float height, float alpha) {
        try {
            // 保存当前状态
            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.enableTexture2D();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            
            // 重置颜色（避免紫色问题）
            GlStateManager.color(1.0f, 1.0f, 1.0f, alpha);
            
            // 绑定纹理
            try {
                net.minecraft.client.Minecraft.getMinecraft().getTextureManager().bindTexture(backgroundTexture);
            } catch (Exception e) {
                System.err.println("[IslandRenderer] 纹理绑定失败: " + backgroundTexture);
                throw e;
            }
            
            // 渲染四边形
            net.minecraft.client.renderer.Tessellator tessellator = net.minecraft.client.renderer.Tessellator.getInstance();
            net.minecraft.client.renderer.WorldRenderer worldRenderer = tessellator.getWorldRenderer();
            
            worldRenderer.begin(7, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION_TEX);
            worldRenderer.pos(x, y + height, 0.0).tex(0.0, 1.0).endVertex();
            worldRenderer.pos(x + width, y + height, 0.0).tex(1.0, 1.0).endVertex();
            worldRenderer.pos(x + width, y, 0.0).tex(1.0, 0.0).endVertex();
            worldRenderer.pos(x, y, 0.0).tex(0.0, 0.0).endVertex();
            tessellator.draw();
            
            // 恢复颜色
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.popMatrix();
            
        } catch (Exception e) {
            System.err.println("[IslandRenderer] 纹理渲染失败，降级到纯色背景");
            System.err.println("[IslandRenderer] 错误: " + e.getMessage());
            e.printStackTrace();
            
            // 恢复状态
            try {
                GlStateManager.popMatrix();
            } catch (Exception ignored) {}
            
            // 标记纹理失败，下次使用纯色
            textureLoaded = false;
            renderSolidBackground(x, y, width, height, alpha);
        }
    }
    
    /**
     * 渲染纯色背景
     */
    private void renderSolidBackground(float x, float y, float width, float height, float alpha) {
        int bgColor = config.getBackgroundColor();
        int alphaValue = (int) (((bgColor >> 24) & 0xFF) * alpha);
        int color = (alphaValue << 24) | (bgColor & 0xFFFFFF);
        effectRenderer.renderRoundedRect(x, y, width, height, config.getCornerRadius(), color);
    }
    
    /**
     * 渲染内容（精确坐标计算，正确图层顺序）
     */
    private void renderContents(float x, float y, float width, float height, List<IslandContent> contents) {
        if (contents == null || contents.isEmpty()) {
            return;
        }
        
        // 计算内容区域（适配更小尺寸）
        float padding = 10.0f;         // 减小内边距
        float iconTextSpacing = 4.0f;  // 图标与文本间距
        float elementSpacing = 6.0f;   // 元素间分隔
        float contentStartX = x + padding;
        float maxContentWidth = width - (padding * 2);
        
        // 第一步：计算所有内容的总宽度并分类
        float totalContentWidth = 0;
        int visibleCount = 0;
        boolean hasIcon = false;
        
        for (IslandContent content : contents) {
            if (content.shouldDisplay()) {
                totalContentWidth += content.getPreferredWidth();
                visibleCount++;
                if (content instanceof IconContent) {
                    hasIcon = true;
                }
            }
        }
        
        // 添加间距（图标和文本之间用较小间距，其他用标准间距）
        if (visibleCount > 1) {
            if (hasIcon) {
                totalContentWidth += iconTextSpacing; // 图标后的间距
                if (visibleCount > 2) {
                    totalContentWidth += elementSpacing * (visibleCount - 2);
                }
            } else {
                totalContentWidth += elementSpacing * (visibleCount - 1);
            }
        }
        
        // 检查是否超出可用空间（仅在调试模式下输出）
        if (config.isDebugMode()) {
            if (totalContentWidth > maxContentWidth) {
                System.err.println("[IslandRenderer] 警告：内容宽度超出可用空间: " + totalContentWidth + " > " + maxContentWidth);
            }
            System.out.println("[IslandRenderer] 内容布局 - 起始X: " + contentStartX + ", 可用宽度: " + maxContentWidth + ", 总内容宽度: " + totalContentWidth);
        }
        
        // 第二步：按图层顺序渲染（先图标，后文本，确保文本在最上层）
        float currentX = contentStartX;
        
        // 先渲染所有图标
        for (IslandContent content : contents) {
            if (content.shouldDisplay() && content instanceof IconContent) {
                try {
                    float prefWidth = content.getPreferredWidth();
                    float prefHeight = content.getPreferredHeight();
                    
                    // 垂直居中
                    float contentY = y + (height - prefHeight) / 2;
                    
                    // 调试输出（仅在调试模式下）
                    if (config.isDebugMode()) {
                        System.out.println("[IslandRenderer] 渲染图标 - X: " + currentX + ", Y: " + contentY + ", 宽度: " + prefWidth);
                    }
                    
                    // 渲染图标
                    GlStateManager.enableTexture2D();
                    content.render(currentX, contentY, prefWidth, prefHeight);
                    
                    // 更新 X 坐标（图标后使用较小间距）
                    currentX += prefWidth + iconTextSpacing;
                } catch (Exception e) {
                    System.err.println("[IslandRenderer] 图标渲染失败: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
        
        // 再渲染所有文本（确保文本在最上层）
        currentX = contentStartX;
        boolean firstText = true;
        
        for (IslandContent content : contents) {
            if (content.shouldDisplay()) {
                try {
                    float prefWidth = content.getPreferredWidth();
                    float prefHeight = content.getPreferredHeight();
                    
                    // 垂直居中
                    float contentY = y + (height - prefHeight) / 2;
                    
                    if (content instanceof IconContent) {
                        // 跳过图标（已经渲染过），但更新坐标
                        currentX += prefWidth + iconTextSpacing;
                        firstText = true; // 图标后的第一个文本
                    } else {
                        // 调试输出（仅在调试模式下）
                        if (config.isDebugMode()) {
                            String contentText = "";
                            if (content instanceof TextContent) {
                                contentText = ((TextContent) content).getText();
                            } else if (content instanceof PlayerInfoContent) {
                                contentText = "PlayerInfo";
                            }
                            System.out.println("[IslandRenderer] 渲染文本 '" + contentText + "' - X: " + currentX + ", Y: " + contentY + ", 宽度: " + prefWidth);
                        }
                        
                        // 渲染文本内容
                        GlStateManager.enableTexture2D();
                        content.render(currentX, contentY, prefWidth, prefHeight);
                        
                        // 更新 X 坐标（文本之间使用标准间距）
                        currentX += prefWidth + (firstText ? iconTextSpacing : elementSpacing);
                        firstText = false;
                    }
                } catch (Exception e) {
                    System.err.println("[IslandRenderer] 文本渲染失败: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }
    
    /**
     * 渲染效果（阴影、发光）
     */
    private void renderEffects(float x, float y, float width, float height) {
        // 渲染轻微阴影 - 减少阴影强度和大小
        if (config.isEnableShadow()) {
            effectRenderer.renderShadow(x, y, width, height, config.getCornerRadius(), 0x40000000, 4.0f);
        }
        
        // 渲染发光
        if (config.isEnableGlow()) {
            effectRenderer.renderGlow(x, y, width, height, config.getCornerRadius(), 0x40FFFFFF, 0.3f);
        }
    }
    
    /**
     * 计算 X 坐标（屏幕中央）
     */
    private float calculateX(ScaledResolution resolution, float width) {
        return (resolution.getScaledWidth() / 2.0f) - (width / 2.0f) + config.getOffsetX();
    }
    
    /**
     * 计算 Y 坐标（屏幕顶部）
     */
    private float calculateY(ScaledResolution resolution) {
        return config.getOffsetY();
    }
}
