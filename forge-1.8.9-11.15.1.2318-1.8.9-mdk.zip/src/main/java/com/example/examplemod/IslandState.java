package com.example.examplemod;

/**
 * 灵动岛的显示状态枚举
 */
public enum IslandState {
    COMPACT(140, 35),     // 收缩状态：140x35 像素（缩小30%）
    STANDARD(200, 40),    // 标准状态：200x40 像素（缩小33%）
    EXPANDED(280, 45);    // 展开状态：280x45 像素（缩小38%）
    
    private final int width;
    private final int height;
    
    IslandState(int width, int height) {
        this.width = width;
        this.height = height;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public float getAspectRatio() {
        return (float) width / (float) height;
    }
}
