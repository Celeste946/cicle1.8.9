package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * 移动事件处理器
 * 监听客户端 Tick 事件并应用快速移动逻辑
 */
public class MovementEventHandler {
    
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        // 仅在 tick 开始阶段处理
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        
        // 获取玩家实体
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP player = mc.thePlayer;
        
        if (player != null) {
            // 应用快速移动逻辑
            if (FastMovement.getInstance().isEnabled()) {
                FastMovement.getInstance().onPlayerTick(player);
            }
            
            // 应用自动疾跑逻辑
            if (AutoSprint.getInstance().isEnabled()) {
                AutoSprint.getInstance().onPlayerTick(player);
            }
            
            // 应用自动攻击逻辑
            if (AutoAttack.getInstance().isEnabled()) {
                AutoAttack.getInstance().onPlayerTick(player);
            }
        }
    }
}
