package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * 名称标签渲染器
 * 在玩家名称标签左边渲染自定义 logo
 */
public class NameTagRenderer {
    private static NameTagRenderer instance;
    private boolean enabled = true; // 默认启用
    
    private static final ResourceLocation LOGO_TEXTURE = new ResourceLocation("examplemod", "textures/gui/logo.png");
    private static final float LOGO_SIZE = 32.0f; // Logo 大小（像素）- 32x32
    private static final float NAME_SCALE = 1.5f; // 名字缩放倍数
    
    private NameTagRenderer() {
        // 私有构造函数，单例模式
    }
    
    public static NameTagRenderer getInstance() {
        if (instance == null) {
            instance = new NameTagRenderer();
        }
        return instance;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    /**
     * 监听实体渲染事件，在名称标签渲染后添加 logo
     */
    @SubscribeEvent
    public void onRenderLiving(RenderLivingEvent.Specials.Post<EntityPlayer> event) {
        if (!enabled) return;
        
        // 只处理玩家实体
        if (!(event.entity instanceof EntityPlayer)) return;
        
        EntityPlayer player = (EntityPlayer) event.entity;
        Minecraft mc = Minecraft.getMinecraft();
        
        // GUI 状态检查 - 如果 GUI 打开，立即返回不执行任何渲染
        if (mc.currentScreen != null) {
            return;
        }
        
        // 只给自己显示 logo，其他玩家不显示
        if (player != mc.thePlayer) return;
        
        // 检查是否应该渲染名称标签
        if (!shouldRenderNameTag(player, mc)) return;
        
        // 渲染 logo
        renderLogo(player, event.x, event.y, event.z, mc.getRenderManager());
    }
    
    /**
     * 检查是否应该渲染名称标签
     */
    private boolean shouldRenderNameTag(EntityPlayer player, Minecraft mc) {
        // 只在第三人称视角渲染
        if (mc.gameSettings.thirdPersonView == 0) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 渲染 logo 和玩家名字
     */
    private void renderLogo(EntityPlayer player, double x, double y, double z, RenderManager renderManager) {
        FontRenderer fontRenderer = renderManager.getFontRenderer();
        String name = player.getDisplayName().getFormattedText();
        
        // 计算名称宽度（考虑缩放）
        int nameWidth = (int) (fontRenderer.getStringWidth(name) * NAME_SCALE);
        
        // 计算总宽度（logo + 间距 + 名字）
        float spacing = 6.0f; // logo 和名字之间的间距
        float totalWidth = LOGO_SIZE + spacing + nameWidth;
        
        // 计算 logo 起始位置（居中显示）
        float logoX = -(totalWidth / 2.0f);
        float logoY = -LOGO_SIZE / 2.0f; // 垂直居中
        
        // 计算名字位置（logo 右边）
        float nameX = logoX + LOGO_SIZE + spacing;
        float nameY = -fontRenderer.FONT_HEIGHT * NAME_SCALE / 2.0f; // 名字垂直居中对齐 logo
        
        // 保存当前状态
        GlStateManager.pushMatrix();
        
        try {
            // 移动到实体头顶位置
            GlStateManager.translate((float) x, (float) y + player.height + 0.5f, (float) z);
            
            // 让内容始终面向玩家
            GL11.glNormal3f(0.0f, 1.0f, 0.0f);
            GlStateManager.rotate(-renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
            GlStateManager.rotate(renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
            
            // 缩放
            float scale = 0.016666668f * 0.6f; // 名称标签的标准缩放
            GlStateManager.scale(-scale, -scale, scale);
            
            // 禁用光照，启用混合
            GlStateManager.disableLighting();
            GlStateManager.depthMask(false);
            GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
            
            // 渲染 logo - 使用 try-finally 确保纹理解绑
            try {
                Minecraft.getMinecraft().getTextureManager().bindTexture(LOGO_TEXTURE);
                Tessellator tessellator = Tessellator.getInstance();
                WorldRenderer worldRenderer = tessellator.getWorldRenderer();
                
                worldRenderer.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
                worldRenderer.pos(logoX, logoY + LOGO_SIZE, 0.0).tex(0.0, 1.0).endVertex();
                worldRenderer.pos(logoX + LOGO_SIZE, logoY + LOGO_SIZE, 0.0).tex(1.0, 1.0).endVertex();
                worldRenderer.pos(logoX + LOGO_SIZE, logoY, 0.0).tex(1.0, 0.0).endVertex();
                worldRenderer.pos(logoX, logoY, 0.0).tex(0.0, 0.0).endVertex();
                tessellator.draw();
            } finally {
                // 显式解除纹理绑定
                GlStateManager.bindTexture(0);
            }
            
            // 渲染玩家名字（在 logo 右边，放大显示）
            GlStateManager.pushMatrix();
            GlStateManager.translate(nameX, nameY, 0.0f);
            GlStateManager.scale(NAME_SCALE, NAME_SCALE, NAME_SCALE);
            
            // 绘制名字（白色，带阴影）
            fontRenderer.drawStringWithShadow(name, 0, 0, 0xFFFFFF);
            
            GlStateManager.popMatrix();
        } finally {
            // 恢复状态
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            
            GlStateManager.popMatrix();
        }
    }
}
