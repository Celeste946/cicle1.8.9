package com.example.examplemod;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * 无掉落伤害功能模块
 * 取消玩家从高处掉落时受到的伤害
 */
public class NoFallDamage {
    private static NoFallDamage instance;
    private boolean enabled = false; // 默认禁用
    
    private NoFallDamage() {
        // 私有构造函数，单例模式
    }
    
    /**
     * 获取单例实例
     */
    public static NoFallDamage getInstance() {
        if (instance == null) {
            instance = new NoFallDamage();
        }
        return instance;
    }
    
    /**
     * 切换无掉落伤害功能
     */
    public void toggle() {
        enabled = !enabled;
        System.out.println("[NoFallDamage] 无掉落伤害已" + (enabled ? "启用" : "禁用"));
    }
    
    /**
     * 检查功能是否启用
     */
    public boolean isEnabled() {
        return enabled;
    }
    
    /**
     * 设置功能状态
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    /**
     * 每个 tick 应用无掉落伤害逻辑
     */
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (!enabled) return;
        
        if (event.player instanceof EntityPlayerSP) {
            EntityPlayerSP player = (EntityPlayerSP) event.player;
            
            // 重置掉落距离，防止掉落伤害
            if (player.fallDistance > 0) {
                player.fallDistance = 0;
            }
        }
    }
}
