package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 通知系统
 * 在屏幕右侧显示带缓动动画的通知面板
 */
public class NotificationSystem {
    private static NotificationSystem instance;
    private final List<Notification> notifications = new ArrayList<>();
    
    private NotificationSystem() {
        // 私有构造函数，单例模式
    }
    
    public static NotificationSystem getInstance() {
        if (instance == null) {
            instance = new NotificationSystem();
        }
        return instance;
    }
    
    /**
     * 添加通知
     */
    public void addNotification(String title, String message, int duration) {
        notifications.add(new Notification(title, message, duration));
    }
    
    /**
     * 渲染所有通知
     */
    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        
        // 如果有GUI打开，不渲染通知（避免冲突）
        // 在任何其他操作之前立即检查并返回
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen != null) return;
        
        if (mc.thePlayer == null) return;
        
        ScaledResolution resolution = event.resolution;
        int screenWidth = resolution.getScaledWidth();
        
        // 更新和渲染所有通知
        Iterator<Notification> iterator = notifications.iterator();
        int yOffset = 10;
        
        while (iterator.hasNext()) {
            Notification notification = iterator.next();
            notification.update();
            
            if (notification.isExpired()) {
                iterator.remove();
            } else {
                try {
                    notification.render(mc, screenWidth, yOffset);
                    yOffset += notification.getHeight() + 10;
                } catch (Exception e) {
                    // 渲染失败，移除这个通知
                    iterator.remove();
                }
            }
        }
    }
    
    /**
     * 通知类
     */
    private static class Notification {
        private final String title;
        private final String message;
        private final long startTime;
        private final int duration; // 毫秒
        
        private float animationProgress = 0.0f; // 0.0 到 1.0
        private boolean isClosing = false;
        
        private static final int PANEL_WIDTH = 250;
        private static final int PANEL_HEIGHT = 60;
        private static final int ANIMATION_DURATION = 300; // 动画持续时间（毫秒）
        
        public Notification(String title, String message, int duration) {
            this.title = title;
            this.message = message;
            this.duration = duration;
            this.startTime = System.currentTimeMillis();
        }
        
        public void update() {
            long currentTime = System.currentTimeMillis();
            long elapsed = currentTime - startTime;
            
            // 开始关闭动画
            if (elapsed >= duration - ANIMATION_DURATION && !isClosing) {
                isClosing = true;
            }
            
            // 更新动画进度
            if (isClosing) {
                // 关闭动画（从1.0到0.0）
                long closeElapsed = elapsed - (duration - ANIMATION_DURATION);
                animationProgress = 1.0f - Math.min(1.0f, closeElapsed / (float) ANIMATION_DURATION);
            } else if (elapsed < ANIMATION_DURATION) {
                // 打开动画（从0.0到1.0）
                animationProgress = Math.min(1.0f, elapsed / (float) ANIMATION_DURATION);
            } else {
                // 完全显示
                animationProgress = 1.0f;
            }
        }
        
        public boolean isExpired() {
            return System.currentTimeMillis() - startTime >= duration;
        }
        
        public int getHeight() {
            return PANEL_HEIGHT;
        }
        
        public void render(Minecraft mc, int screenWidth, int yOffset) {
            // 使用缓动函数（easeOutCubic）
            float easedProgress = easeOutCubic(animationProgress);
            
            // 计算X位置（从右侧滑入）
            int targetX = screenWidth - PANEL_WIDTH - 10;
            int startX = screenWidth + 10;
            int currentX = (int) (startX + (targetX - startX) * easedProgress);
            
            int y = yOffset;
            
            // 保存状态
            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
            GlStateManager.disableDepth();
            GlStateManager.disableLighting();
            GlStateManager.disableTexture2D();
            
            // 绘制阴影
            drawRect(currentX + 2, y + 2, currentX + PANEL_WIDTH + 2, y + PANEL_HEIGHT + 2, 
                    new Color(0, 0, 0, 100).getRGB());
            
            // 绘制面板背景
            drawRect(currentX, y, currentX + PANEL_WIDTH, y + PANEL_HEIGHT, 
                    new Color(30, 30, 35, 230).getRGB());
            
            // 绘制顶部装饰条
            drawRect(currentX, y, currentX + PANEL_WIDTH, y + 3, 
                    new Color(123, 66, 245).getRGB());
            
            // 绘制边框
            drawBorder(currentX, y, PANEL_WIDTH, PANEL_HEIGHT, 
                    new Color(123, 66, 245, 150).getRGB());
            
            GlStateManager.enableTexture2D();
            
            // 绘制文本
            FontRenderer fontRenderer = mc.fontRendererObj;
            
            // 标题（加粗效果）
            String titleText = "§l" + title;
            fontRenderer.drawStringWithShadow(titleText, currentX + 10, y + 10, 0xFFFFFF);
            
            // 消息（多行支持）
            drawWrappedText(fontRenderer, message, currentX + 10, y + 25, 
                    PANEL_WIDTH - 20, 0xCCCCCC);
            
            // 恢复状态
            GlStateManager.enableDepth();
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
        }
        
        /**
         * 缓动函数 - easeOutCubic
         */
        private float easeOutCubic(float t) {
            float f = t - 1.0f;
            return f * f * f + 1.0f;
        }
        
        /**
         * 绘制矩形
         */
        private void drawRect(int left, int top, int right, int bottom, int color) {
            net.minecraft.client.gui.Gui.drawRect(left, top, right, bottom, color);
        }
        
        /**
         * 绘制边框
         */
        private void drawBorder(int x, int y, int width, int height, int color) {
            drawRect(x, y, x + width, y + 1, color); // 顶部
            drawRect(x, y + height - 1, x + width, y + height, color); // 底部
            drawRect(x, y, x + 1, y + height, color); // 左侧
            drawRect(x + width - 1, y, x + width, y + height, color); // 右侧
        }
        
        /**
         * 绘制自动换行文本
         */
        private void drawWrappedText(FontRenderer fontRenderer, String text, 
                                     int x, int y, int maxWidth, int color) {
            String[] words = text.split(" ");
            StringBuilder line = new StringBuilder();
            int currentY = y;
            
            for (String word : words) {
                String testLine = line.length() == 0 ? word : line + " " + word;
                int lineWidth = fontRenderer.getStringWidth(testLine);
                
                if (lineWidth > maxWidth && line.length() > 0) {
                    fontRenderer.drawStringWithShadow(line.toString(), x, currentY, color);
                    line = new StringBuilder(word);
                    currentY += 10;
                } else {
                    line = new StringBuilder(testLine);
                }
            }
            
            if (line.length() > 0) {
                fontRenderer.drawStringWithShadow(line.toString(), x, currentY, color);
            }
        }
    }
}
