package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

/**
 * 玩家信息内容 - 显示玩家的各种信息
 */
public class PlayerInfoContent implements IslandContent {
    private InfoType type;
    private int priority;
    private PlayerInfoProvider infoProvider;
    private int color;
    
    /**
     * 信息类型枚举
     */
    public enum InfoType {
        COORDINATES,  // 坐标
        HEALTH,       // 生命值
        HUNGER,       // 饥饿度
        TIME,         // 游戏时间
        TARGET        // 攻击目标
    }
    
    public PlayerInfoContent(InfoType type, int priority) {
        this.type = type;
        this.priority = priority;
        this.infoProvider = new PlayerInfoProvider();
        // 根据类型设置默认颜色
        this.color = getDefaultColorForType(type);
    }
    
    public PlayerInfoContent(InfoType type, int priority, PlayerInfoProvider provider) {
        this.type = type;
        this.priority = priority;
        this.infoProvider = provider;
        this.color = getDefaultColorForType(type);
    }
    
    /**
     * 根据信息类型获取默认颜色
     */
    private int getDefaultColorForType(InfoType type) {
        switch (type) {
            case COORDINATES:
                return 0x00BFFF; // 亮蓝色（用于用户名）
            case HEALTH:
                return 0xFF5555; // 红色
            case HUNGER:
                return 0xFFAA00; // 橙色
            case TIME:
                return 0xFFFFFF; // 白色
            case TARGET:
                return 0xFF5555; // 红色
            default:
                return 0xFFFFFF; // 默认白色
        }
    }
    
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight) {
        String text = getInfoText();
        if (text == null || text.isEmpty()) {
            return;
        }
        
        FontRenderer fontRenderer = Minecraft.getMinecraft().fontRendererObj;
        // 始终使用带阴影的文本渲染，提升可读性
        fontRenderer.drawStringWithShadow(text, x, y, color);
    }
    
    @Override
    public float getPreferredWidth() {
        String text = getInfoText();
        if (text == null || text.isEmpty()) {
            return 0;
        }
        
        FontRenderer fontRenderer = Minecraft.getMinecraft().fontRendererObj;
        return fontRenderer.getStringWidth(text);
    }
    
    @Override
    public float getPreferredHeight() {
        return 8; // Minecraft 字体高度
    }
    
    @Override
    public int getPriority() {
        return priority;
    }
    
    @Override
    public boolean shouldDisplay() {
        String text = getInfoText();
        return text != null && !text.isEmpty();
    }
    
    /**
     * 根据类型获取信息文本
     */
    private String getInfoText() {
        if (infoProvider == null) {
            return "";
        }
        
        switch (type) {
            case COORDINATES:
                // 显示玩家名称而不是坐标
                return net.minecraft.client.Minecraft.getMinecraft().thePlayer != null 
                    ? net.minecraft.client.Minecraft.getMinecraft().thePlayer.getName() 
                    : "";
            case HEALTH:
                return infoProvider.getHealth();
            case HUNGER:
                return infoProvider.getHunger();
            case TIME:
                return infoProvider.getGameTime();
            case TARGET:
                return infoProvider.getTargetInfo();
            default:
                return "";
        }
    }
    
    public InfoType getType() {
        return type;
    }
    
    public void setColor(int color) {
        this.color = color;
    }
    
    public int getColor() {
        return color;
    }
}
