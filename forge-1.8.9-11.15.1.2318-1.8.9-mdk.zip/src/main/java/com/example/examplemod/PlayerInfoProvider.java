package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

/**
 * 玩家信息提供者 - 提供游戏中的各种信息
 */
public class PlayerInfoProvider {
    private Minecraft mc;
    
    public PlayerInfoProvider() {
        this.mc = Minecraft.getMinecraft();
    }
    
    /**
     * 获取玩家坐标
     */
    public String getCoordinates() {
        if (mc.thePlayer == null) {
            return "";
        }
        
        return formatCoordinates(
            mc.thePlayer.posX,
            mc.thePlayer.posY,
            mc.thePlayer.posZ
        );
    }
    
    /**
     * 获取生命值信息
     */
    public String getHealth() {
        if (mc.thePlayer == null) {
            return "";
        }
        
        return formatHealth(
            mc.thePlayer.getHealth(),
            mc.thePlayer.getMaxHealth()
        );
    }
    
    /**
     * 获取饥饿度信息
     */
    public String getHunger() {
        if (mc.thePlayer == null) {
            return "";
        }
        
        int foodLevel = mc.thePlayer.getFoodStats().getFoodLevel();
        return String.format("🍖 %d", foodLevel);
    }
    
    /**
     * 获取游戏时间
     */
    public String getGameTime() {
        if (mc.theWorld == null) {
            return "";
        }
        
        long worldTime = mc.theWorld.getWorldTime();
        return formatTime(worldTime);
    }
    
    /**
     * 获取目标信息
     */
    public String getTargetInfo() {
        if (!hasTarget()) {
            return "";
        }
        
        try {
            // 尝试从 AutoAttack 获取目标
            AutoAttack autoAttack = AutoAttack.getInstance();
            if (autoAttack != null && autoAttack.isEnabled()) {
                // 查找最近的目标
                EntityLivingBase target = findNearestTarget();
                if (target != null) {
                    return String.format("%s %.1f❤", 
                        target.getName(), 
                        target.getHealth());
                }
            }
        } catch (Exception e) {
            // AutoAttack 可能不存在
        }
        
        return "";
    }
    
    /**
     * 是否有目标
     */
    public boolean hasTarget() {
        try {
            AutoAttack autoAttack = AutoAttack.getInstance();
            return autoAttack != null && autoAttack.isEnabled() && findNearestTarget() != null;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 查找最近的目标
     */
    private EntityLivingBase findNearestTarget() {
        if (mc.thePlayer == null || mc.theWorld == null) {
            return null;
        }
        
        EntityLivingBase closestTarget = null;
        double closestDistance = Double.MAX_VALUE;
        
        try {
            AutoAttack autoAttack = AutoAttack.getInstance();
            double range = autoAttack.getAttackRange();
            
            for (Object obj : mc.theWorld.loadedEntityList) {
                if (!(obj instanceof EntityLivingBase)) continue;
                EntityLivingBase entity = (EntityLivingBase) obj;
                
                if (entity == mc.thePlayer) continue;
                if (!entity.isEntityAlive()) continue;
                
                double distance = mc.thePlayer.getDistanceToEntity(entity);
                if (distance <= range && distance < closestDistance) {
                    closestTarget = entity;
                    closestDistance = distance;
                }
            }
        } catch (Exception e) {
            // 忽略错误
        }
        
        return closestTarget;
    }
    
    /**
     * 格式化坐标
     */
    private String formatCoordinates(double x, double y, double z) {
        return String.format("%.0f, %.0f, %.0f", x, y, z);
    }
    
    /**
     * 格式化生命值
     */
    private String formatHealth(float health, float maxHealth) {
        return String.format("❤ %.1f/%.1f", health, maxHealth);
    }
    
    /**
     * 格式化时间
     */
    private String formatTime(long worldTime) {
        // Minecraft 时间：0 = 6:00, 6000 = 12:00, 12000 = 18:00, 18000 = 0:00
        long time = worldTime % 24000;
        int hours = (int) ((time / 1000 + 6) % 24);
        int minutes = (int) ((time % 1000) * 60 / 1000);
        
        return String.format("%02d:%02d", hours, minutes);
    }
}
