package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

/**
 * 文本内容 - 在灵动岛中显示文本
 */
public class TextContent implements IslandContent {
    private String text;
    private int color;
    private boolean shadow;
    private int priority;
    
    public TextContent(String text, int color, int priority) {
        this.text = text;
        this.color = color;
        this.shadow = true;
        this.priority = priority;
    }
    
    public TextContent(String text, int color, boolean shadow, int priority) {
        this.text = text;
        this.color = color;
        this.shadow = shadow;
        this.priority = priority;
    }
    
    @Override
    public void render(float x, float y, float maxWidth, float maxHeight) {
        if (text == null || text.isEmpty()) {
            return;
        }
        
        FontRenderer fontRenderer = Minecraft.getMinecraft().fontRendererObj;
        
        if (shadow) {
            fontRenderer.drawStringWithShadow(text, x, y, color);
        } else {
            fontRenderer.drawString(text, (int) x, (int) y, color);
        }
    }
    
    @Override
    public float getPreferredWidth() {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        
        FontRenderer fontRenderer = Minecraft.getMinecraft().fontRendererObj;
        return fontRenderer.getStringWidth(text);
    }
    
    @Override
    public float getPreferredHeight() {
        return 8; // Minecraft 字体高度
    }
    
    @Override
    public int getPriority() {
        return priority;
    }
    
    @Override
    public boolean shouldDisplay() {
        return text != null && !text.isEmpty();
    }
    
    public void setText(String text) {
        this.text = text;
    }
    
    public String getText() {
        return text;
    }
    
    public void setColor(int color) {
        this.color = color;
    }
    
    public int getColor() {
        return color;
    }
}
