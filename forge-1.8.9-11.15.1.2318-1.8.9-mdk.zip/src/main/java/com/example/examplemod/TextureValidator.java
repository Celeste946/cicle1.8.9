package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

/**
 * 纹理验证工具 - 帮助调试纹理加载问题
 */
public class TextureValidator {
    
    /**
     * 验证纹理是否可以加载
     * @param texture 纹理资源位置
     * @return 是否成功加载
     */
    public static boolean validateTexture(ResourceLocation texture) {
        if (texture == null) {
            System.err.println("[TextureValidator] 纹理为 null");
            return false;
        }
        
        try {
            System.out.println("[TextureValidator] 验证纹理: " + texture.toString());
            System.out.println("[TextureValidator] 域: " + texture.getResourceDomain());
            System.out.println("[TextureValidator] 路径: " + texture.getResourcePath());
            
            // 尝试绑定纹理
            Minecraft.getMinecraft().getTextureManager().bindTexture(texture);
            
            System.out.println("[TextureValidator] ✓ 纹理加载成功");
            return true;
        } catch (Exception e) {
            System.err.println("[TextureValidator] ✗ 纹理加载失败: " + e.getMessage());
            System.err.println("[TextureValidator] 预期路径: src/main/resources/assets/" 
                + texture.getResourceDomain() + "/textures/" + texture.getResourcePath());
            return false;
        }
    }
    
    /**
     * 列出常见的纹理路径问题
     */
    public static void printCommonIssues() {
        System.out.println("[TextureValidator] 常见纹理问题：");
        System.out.println("  1. 路径区分大小写（Windows 不区分，但打包后会区分）");
        System.out.println("  2. ResourceLocation 不需要包含 'textures/' 前缀");
        System.out.println("  3. 不需要包含 '.png' 扩展名");
        System.out.println("  4. 示例：new ResourceLocation(\"examplemod\", \"gui/icon\")");
        System.out.println("  5. 对应文件：src/main/resources/assets/examplemod/textures/gui/icon.png");
    }
}
